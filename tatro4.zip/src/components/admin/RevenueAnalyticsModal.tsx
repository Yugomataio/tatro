'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { TrendingUp, TrendingDown, DollarSign, Users, Package, Calendar, BarChart3, PieChart } from 'lucide-react'
import { useAuth } from '@/contexts/AuthContext'

interface ChartData {
  date: string
  revenue: number
  transactions: number
}

interface TypeData {
  type: string
  revenue: number
  transactions: number
  items: Array<{
    name: string
    revenue: number
    transactions: number
  }>
}

interface CustomerData {
  user: {
    name: string
    email: string
    avatar?: string
  }
  totalSpent: number
  transactionCount: number
}

interface AnalyticsData {
  chartData: ChartData[]
  typeData: TypeData[]
  topCustomers: CustomerData[]
  overallStats: {
    totalRevenue: number
    totalTransactions: number
    averageTransaction: number
    revenueGrowth: number
  }
  previousStats: {
    totalRevenue: number
    totalTransactions: number
  }
}

interface RevenueAnalyticsModalProps {
  isOpen: boolean
  onClose: () => void
}

export default function RevenueAnalyticsModal({ isOpen, onClose }: RevenueAnalyticsModalProps) {
  const [analytics, setAnalytics] = useState<AnalyticsData | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [period, setPeriod] = useState('30')
  const { user } = useAuth()

  useEffect(() => {
    if (isOpen) {
      fetchAnalytics()
    }
  }, [isOpen, period])

  const fetchAnalytics = async () => {
    try {
      setLoading(true)
      const token = localStorage.getItem('adventure_guild_token')
      if (!token) return

      const params = new URLSearchParams({ period })
      const response = await fetch(`/api/admin/analytics?${params}`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'x-user-data': JSON.stringify(user),
        },
      })

      if (response.ok) {
        const data = await response.json()
        setAnalytics(data)
      } else {
        const errorData = await response.json()
        setError(errorData.error || 'Failed to fetch analytics')
      }
    } catch (error) {
      console.error('Error fetching analytics:', error)
      setError('An error occurred while fetching analytics')
    } finally {
      setLoading(false)
    }
  }

  const getTypeBadgeColor = (type: string) => {
    const colors: { [key: string]: string } = {
      'TOOLS': 'bg-blue-100 text-blue-800',
      'EQUIPMENT': 'bg-green-100 text-green-800',
      'SERVICES': 'bg-purple-100 text-purple-800',
      'EDUCATION': 'bg-yellow-100 text-yellow-800',
      'TRANSPORTATION': 'bg-red-100 text-red-800',
      'HOUSING': 'bg-indigo-100 text-indigo-800',
      'FOOD': 'bg-orange-100 text-orange-800',
      'MISCELLANEOUS': 'bg-gray-100 text-gray-800'
    }
    return colors[type] || 'bg-gray-100 text-gray-800'
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0
    }).format(amount)
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <Card className="w-full max-w-7xl max-h-[90vh] overflow-hidden">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <BarChart3 className="h-5 w-5" />
            <span>Revenue Analytics</span>
          </CardTitle>
          <CardDescription>
            Comprehensive revenue analysis and business insights
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {/* Period Selector */}
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-2">
              <Calendar className="h-4 w-4" />
              <span className="text-sm font-medium">Time Period:</span>
            </div>
            <Select value={period} onValueChange={setPeriod}>
              <SelectTrigger className="w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7">Last 7 days</SelectItem>
                <SelectItem value="30">Last 30 days</SelectItem>
                <SelectItem value="90">Last 90 days</SelectItem>
                <SelectItem value="365">Last year</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {loading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
              <p className="mt-2 text-muted-foreground">Loading analytics...</p>
            </div>
          ) : analytics ? (
            <>
              {/* Key Metrics */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-2xl font-bold">{analytics.overallStats.totalRevenue} CC</div>
                        <div className="text-sm text-muted-foreground">Total Revenue</div>
                        <div className={`flex items-center space-x-1 text-xs ${
                          analytics.overallStats.revenueGrowth >= 0 ? 'text-green-600' : 'text-red-600'
                        }`}>
                          {analytics.overallStats.revenueGrowth >= 0 ? (
                            <TrendingUp className="h-3 w-3" />
                          ) : (
                            <TrendingDown className="h-3 w-3" />
                          )}
                          <span>{Math.abs(analytics.overallStats.revenueGrowth).toFixed(1)}%</span>
                        </div>
                      </div>
                      <DollarSign className="h-8 w-8 text-green-500" />
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-2xl font-bold">{analytics.overallStats.totalTransactions}</div>
                        <div className="text-sm text-muted-foreground">Transactions</div>
                        <div className="text-xs text-gray-500">
                          Previous: {analytics.previousStats.totalTransactions}
                        </div>
                      </div>
                      <BarChart3 className="h-8 w-8 text-blue-500" />
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-2xl font-bold">{analytics.overallStats.averageTransaction.toFixed(1)} CC</div>
                        <div className="text-sm text-muted-foreground">Average Order</div>
                      </div>
                      <Package className="h-8 w-8 text-purple-500" />
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-2xl font-bold">{analytics.topCustomers.length}</div>
                        <div className="text-sm text-muted-foreground">Top Customers</div>
                      </div>
                      <Users className="h-8 w-8 text-orange-500" />
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Revenue by Type */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <PieChart className="h-5 w-5" />
                    <span>Revenue by Category</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {analytics.typeData
                      .sort((a, b) => b.revenue - a.revenue)
                      .map((type) => (
                        <div key={type.type} className="border rounded-lg p-4">
                          <div className="flex items-center justify-between mb-2">
                            <Badge className={getTypeBadgeColor(type.type)}>
                              {type.type}
                            </Badge>
                            <span className="text-lg font-bold">{type.revenue} CC</span>
                          </div>
                          <div className="text-sm text-muted-foreground">
                            {type.transactions} transactions
                          </div>
                          <div className="mt-2 space-y-1">
                            {type.items
                              .sort((a, b) => b.revenue - a.revenue)
                              .slice(0, 3)
                              .map((item, index) => (
                                <div key={index} className="flex justify-between text-xs">
                                  <span className="truncate">{item.name}</span>
                                  <span>{item.revenue} CC</span>
                                </div>
                              ))}
                          </div>
                        </div>
                      ))}
                  </div>
                </CardContent>
              </Card>

              {/* Top Customers */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Users className="h-5 w-5" />
                    <span>Top Customers</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Customer</TableHead>
                        <TableHead>Total Spent</TableHead>
                        <TableHead>Transactions</TableHead>
                        <TableHead>Average Order</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {analytics.topCustomers.map((customer, index) => (
                        <TableRow key={index}>
                          <TableCell>
                            <div className="flex items-center space-x-3">
                              <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
                                {customer.user.avatar ? (
                                  <img src={customer.user.avatar} alt={customer.user.name} className="w-8 h-8 rounded-full" />
                                ) : (
                                  <span className="text-sm font-medium">{customer.user.name?.charAt(0) || customer.user.email.charAt(0)}</span>
                                )}
                              </div>
                              <div>
                                <div className="font-medium">{customer.user.name || 'Unknown'}</div>
                                <div className="text-sm text-gray-500">{customer.user.email}</div>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center space-x-1">
                              <DollarSign className="h-4 w-4 text-green-500" />
                              <span className="font-medium">{customer.totalSpent} CC</span>
                            </div>
                          </TableCell>
                          <TableCell>{customer.transactionCount}</TableCell>
                          <TableCell>
                            {(customer.totalSpent / customer.transactionCount).toFixed(1)} CC
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </>
          ) : null}

          {/* Action Buttons */}
          <div className="flex justify-end space-x-2">
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}