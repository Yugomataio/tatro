'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Coins, 
  Bell, 
  Settings, 
  TrendingUp, 
  Users, 
  Target,
  ShoppingCart,
  RefreshCw,
  Save,
  AlertTriangle
} from 'lucide-react'

interface SystemStats {
  totalUsers: number
  totalQuests: number
  totalShopItems: number
  totalPosts: number
  totalCredits: number
  activeUsers: number
}

interface CurrencySettings {
  exchangeRate: number
  taxRate: number
  minPurchaseAmount: number
  maxPurchaseAmount: number
  ccValue: number
  dynamicPricing: boolean
}

interface NotificationSettings {
  emailNotifications: boolean
  pushNotifications: boolean
  questReminders: boolean
  friendRequests: boolean
  systemUpdates: boolean
}

interface GeneralSettings {
  siteName: string
  siteDescription: string
  maintenanceMode: boolean
  allowRegistrations: boolean
}

export default function SystemManagement() {
  const [systemStats, setSystemStats] = useState<SystemStats>({
    totalUsers: 0,
    totalQuests: 0,
    totalShopItems: 0,
    totalPosts: 0,
    totalCredits: 0,
    activeUsers: 0,
  })
  const [currencySettings, setCurrencySettings] = useState<CurrencySettings>({
    exchangeRate: 1.0,
    taxRate: 0.05,
    minPurchaseAmount: 1,
    maxPurchaseAmount: 10000,
    ccValue: 1.0,
    dynamicPricing: false,
  })
  const [notificationSettings, setNotificationSettings] = useState<NotificationSettings>({
    emailNotifications: true,
    pushNotifications: true,
    questReminders: true,
    friendRequests: true,
    systemUpdates: true,
  })
  const [generalSettings, setGeneralSettings] = useState<GeneralSettings>({
    siteName: 'Adventure Guild',
    siteDescription: 'A platform for adventurers to connect, quest, and grow',
    maintenanceMode: false,
    allowRegistrations: true,
  })
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState('overview')
  const [isSettingsDialogOpen, setIsSettingsDialogOpen] = useState(false)
  const [selectedSetting, setSelectedSetting] = useState<'currency' | 'notifications' | 'general'>('general')

  useEffect(() => {
    fetchSystemStats()
    fetchSystemSettings()
    fetchCCConfiguration()
  }, [])

  const fetchCCConfiguration = async () => {
    try {
      const response = await fetch('/api/cc-configuration')
      if (response.ok) {
        const data = await response.json()
        setCurrencySettings(prev => ({
          ...prev,
          ccValue: data.currentValue,
          dynamicPricing: data.dynamicPricing
        }))
      }
    } catch (error) {
      console.error('Error fetching CC configuration:', error)
    }
  }

  const fetchSystemSettings = async () => {
    try {
      const response = await fetch('/api/admin/settings')
      if (response.ok) {
        const data = await response.json()
        setCurrencySettings(data.currency)
        setNotificationSettings(data.notifications)
        setGeneralSettings(data.general)
      }
    } catch (error) {
      console.error('Error fetching system settings:', error)
    }
  }

  const fetchSystemStats = async () => {
    try {
      setLoading(true)
      const response = await fetch('/api/admin/stats')
      if (response.ok) {
        const data = await response.json()
        setSystemStats({
          totalUsers: data.totals.users,
          totalQuests: data.totals.quests,
          totalShopItems: data.totals.shopItems,
          totalPosts: data.totals.posts,
          totalCredits: data.totals.credits,
          activeUsers: data.active.users,
        })
      }
    } catch (error) {
      console.error('Error fetching system stats:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSaveSettings = async () => {
    try {
      const response = await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          settingType: selectedSetting,
          ...(selectedSetting === 'currency' && { ...currencySettings }),
          ...(selectedSetting === 'notifications' && { ...notificationSettings }),
          ...(selectedSetting === 'general' && { ...generalSettings }),
        }),
      })

      if (response.ok) {
        setIsSettingsDialogOpen(false)
      }
    } catch (error) {
      console.error('Error saving settings:', error)
    }
  }

  const handleSaveCCConfiguration = async () => {
    try {
      const response = await fetch('/api/cc-configuration', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          currentValue: currencySettings.ccValue,
          dynamicPricing: currencySettings.dynamicPricing,
        }),
      })

      if (response.ok) {
        // Refresh the configuration
        fetchCCConfiguration()
      }
    } catch (error) {
      console.error('Error saving CC configuration:', error)
    }
  }

  const handleSimulateDynamicPricing = async () => {
    try {
      const response = await fetch('/api/cc-configuration/dynamic?simulate=true')
      if (response.ok) {
        const data = await response.json()
        fetchCCConfiguration() // Refresh to show the new value
      }
    } catch (error) {
      console.error('Error simulating dynamic pricing:', error)
    }
  }

  const openSettingsDialog = (settingType: 'currency' | 'notifications' | 'general') => {
    setSelectedSetting(settingType)
    setIsSettingsDialogOpen(true)
  }

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat().format(num)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">System Management</h2>
          <p className="text-muted-foreground">
            Monitor system performance and manage settings
          </p>
        </div>
        <Button onClick={fetchSystemStats} disabled={loading}>
          <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
          Refresh Stats
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="overview">
            <TrendingUp className="h-4 w-4 mr-2" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="currency">
            <Coins className="h-4 w-4 mr-2" />
            Currency
          </TabsTrigger>
          <TabsTrigger value="notifications">
            <Bell className="h-4 w-4 mr-2" />
            Notifications
          </TabsTrigger>
          <TabsTrigger value="general">
            <Settings className="h-4 w-4 mr-2" />
            General
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Users</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatNumber(systemStats.totalUsers)}</div>
                <p className="text-xs text-muted-foreground">
                  {formatNumber(systemStats.activeUsers)} active now
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Quests</CardTitle>
                <Target className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatNumber(systemStats.totalQuests)}</div>
                <p className="text-xs text-muted-foreground">
                  Active quests in system
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Shop Items</CardTitle>
                <ShoppingCart className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatNumber(systemStats.totalShopItems)}</div>
                <p className="text-xs text-muted-foreground">
                  Items available
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Posts</CardTitle>
                <Bell className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatNumber(systemStats.totalPosts)}</div>
                <p className="text-xs text-muted-foreground">
                  Social feed posts
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Credits</CardTitle>
                <Coins className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatNumber(systemStats.totalCredits)}</div>
                <p className="text-xs text-muted-foreground">
                  CC in circulation
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">System Health</CardTitle>
                <AlertTriangle className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  <Badge variant="default">Healthy</Badge>
                </div>
                <p className="text-xs text-muted-foreground">
                  All systems operational
                </p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="currency" className="space-y-6">
          {/* CC Configuration Card */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Coins className="h-5 w-5" />
                <span>CC Value Configuration</span>
              </CardTitle>
              <CardDescription>
                Configure the current value of Company Credits (CC). Dynamic pricing values will override manual entries.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <Label>Current CC Value</Label>
                    <div className="flex items-center space-x-2">
                      <Input
                        type="number"
                        step="0.01"
                        min="0"
                        value={currencySettings.ccValue}
                        onChange={(e) => setCurrencySettings({
                          ...currencySettings,
                          ccValue: parseFloat(e.target.value) || 1.0
                        })}
                      />
                      <span className="text-sm text-muted-foreground">CC = 1 base unit</span>
                    </div>
                  </div>
                  <div>
                    <Label>Dynamic Pricing</Label>
                    <div className="flex items-center space-x-2">
                      <select
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                        value={currencySettings.dynamicPricing ? 'enabled' : 'disabled'}
                        onChange={(e) => setCurrencySettings({
                          ...currencySettings,
                          dynamicPricing: e.target.value === 'enabled'
                        })}
                      >
                        <option value="enabled">Enabled</option>
                        <option value="disabled">Disabled</option>
                      </select>
                    </div>
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <h4 className="font-semibold mb-2">CC Configuration Info</h4>
                    <p className="text-sm text-muted-foreground mb-2">
                      This value determines how much 1 CC is worth in the base currency unit.
                    </p>
                    <p className="text-sm text-muted-foreground mb-2">
                      When dynamic pricing is enabled, external market data will automatically update this value.
                    </p>
                    <div className="flex items-center space-x-2">
                      <Badge variant={currencySettings.dynamicPricing ? "default" : "secondary"}>
                        {currencySettings.dynamicPricing ? "Dynamic" : "Manual"}
                      </Badge>
                      <Badge variant="outline">
                        {currencySettings.ccValue.toFixed(2)} CC/base
                      </Badge>
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex justify-end space-x-2">
                {currencySettings.dynamicPricing && (
                  <Button variant="outline" onClick={handleSimulateDynamicPricing}>
                    <RefreshCw className="h-4 w-4 mr-2" />
                    Simulate Update
                  </Button>
                )}
                <Button onClick={handleSaveCCConfiguration}>
                  <Save className="h-4 w-4 mr-2" />
                  Save CC Configuration
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Currency Settings Card */}
          <Card>
            <CardHeader>
              <CardTitle>Currency Management</CardTitle>
              <CardDescription>
                Manage Company Credits (CC) system settings
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <Label>Exchange Rate (CC to USD)</Label>
                    <div className="flex items-center space-x-2">
                      <Input
                        type="number"
                        step="0.01"
                        value={currencySettings.exchangeRate}
                        onChange={(e) => setCurrencySettings({
                          ...currencySettings,
                          exchangeRate: parseFloat(e.target.value) || 1.0
                        })}
                      />
                      <span className="text-sm text-muted-foreground">CC = $1</span>
                    </div>
                  </div>
                  <div>
                    <Label>Tax Rate</Label>
                    <div className="flex items-center space-x-2">
                      <Input
                        type="number"
                        step="0.01"
                        min="0"
                        max="1"
                        value={currencySettings.taxRate}
                        onChange={(e) => setCurrencySettings({
                          ...currencySettings,
                          taxRate: parseFloat(e.target.value) || 0
                        })}
                      />
                      <span className="text-sm text-muted-foreground">
                        {(currencySettings.taxRate * 100).toFixed(0)}%
                      </span>
                    </div>
                  </div>
                </div>
                <div className="space-y-4">
                  <div>
                    <Label>Minimum Purchase Amount</Label>
                    <div className="flex items-center space-x-2">
                      <Input
                        type="number"
                        min="1"
                        value={currencySettings.minPurchaseAmount}
                        onChange={(e) => setCurrencySettings({
                          ...currencySettings,
                          minPurchaseAmount: parseInt(e.target.value) || 1
                        })}
                      />
                      <span className="text-sm text-muted-foreground">CC</span>
                    </div>
                  </div>
                  <div>
                    <Label>Maximum Purchase Amount</Label>
                    <div className="flex items-center space-x-2">
                      <Input
                        type="number"
                        min="1"
                        value={currencySettings.maxPurchaseAmount}
                        onChange={(e) => setCurrencySettings({
                          ...currencySettings,
                          maxPurchaseAmount: parseInt(e.target.value) || 10000
                        })}
                      />
                      <span className="text-sm text-muted-foreground">CC</span>
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex justify-end">
                <Button onClick={() => openSettingsDialog('currency')}>
                  <Save className="h-4 w-4 mr-2" />
                  Save Settings
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Notification Settings</CardTitle>
              <CardDescription>
                Configure system-wide notification preferences
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Email Notifications</Label>
                    <p className="text-sm text-muted-foreground">
                      Send notifications via email
                    </p>
                  </div>
                  <Select
                    value={notificationSettings.emailNotifications ? 'enabled' : 'disabled'}
                    onValueChange={(value) => setNotificationSettings({
                      ...notificationSettings,
                      emailNotifications: value === 'enabled'
                    })}
                  >
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="enabled">Enabled</SelectItem>
                      <SelectItem value="disabled">Disabled</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label>Push Notifications</Label>
                    <p className="text-sm text-muted-foreground">
                      Send push notifications to mobile devices
                    </p>
                  </div>
                  <Select
                    value={notificationSettings.pushNotifications ? 'enabled' : 'disabled'}
                    onValueChange={(value) => setNotificationSettings({
                      ...notificationSettings,
                      pushNotifications: value === 'enabled'
                    })}
                  >
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="enabled">Enabled</SelectItem>
                      <SelectItem value="disabled">Disabled</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label>Quest Reminders</Label>
                    <p className="text-sm text-muted-foreground">
                      Remind users about active quests
                    </p>
                  </div>
                  <Select
                    value={notificationSettings.questReminders ? 'enabled' : 'disabled'}
                    onValueChange={(value) => setNotificationSettings({
                      ...notificationSettings,
                      questReminders: value === 'enabled'
                    })}
                  >
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="enabled">Enabled</SelectItem>
                      <SelectItem value="disabled">Disabled</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label>Friend Requests</Label>
                    <p className="text-sm text-muted-foreground">
                      Notify users about new friend requests
                    </p>
                  </div>
                  <Select
                    value={notificationSettings.friendRequests ? 'enabled' : 'disabled'}
                    onValueChange={(value) => setNotificationSettings({
                      ...notificationSettings,
                      friendRequests: value === 'enabled'
                    })}
                  >
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="enabled">Enabled</SelectItem>
                      <SelectItem value="disabled">Disabled</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label>System Updates</Label>
                    <p className="text-sm text-muted-foreground">
                      Notify users about system updates
                    </p>
                  </div>
                  <Select
                    value={notificationSettings.systemUpdates ? 'enabled' : 'disabled'}
                    onValueChange={(value) => setNotificationSettings({
                      ...notificationSettings,
                      systemUpdates: value === 'enabled'
                    })}
                  >
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="enabled">Enabled</SelectItem>
                      <SelectItem value="disabled">Disabled</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="flex justify-end">
                <Button onClick={() => openSettingsDialog('notifications')}>
                  <Save className="h-4 w-4 mr-2" />
                  Save Settings
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="general" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>General Settings</CardTitle>
              <CardDescription>
                System-wide configuration options
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div>
                  <Label>Site Name</Label>
                  <Input
                    value={generalSettings.siteName}
                    onChange={(e) => setGeneralSettings({
                      ...generalSettings,
                      siteName: e.target.value
                    })}
                  />
                </div>
                <div>
                  <Label>Site Description</Label>
                  <Textarea
                    value={generalSettings.siteDescription}
                    onChange={(e) => setGeneralSettings({
                      ...generalSettings,
                      siteDescription: e.target.value
                    })}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Maintenance Mode</Label>
                    <p className="text-sm text-muted-foreground">
                      Temporarily disable the site for maintenance
                    </p>
                  </div>
                  <Select
                    value={generalSettings.maintenanceMode ? 'enabled' : 'disabled'}
                    onValueChange={(value) => setGeneralSettings({
                      ...generalSettings,
                      maintenanceMode: value === 'enabled'
                    })}
                  >
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="enabled">Enabled</SelectItem>
                      <SelectItem value="disabled">Disabled</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Allow Registrations</Label>
                    <p className="text-sm text-muted-foreground">
                      Allow new users to register
                    </p>
                  </div>
                  <Select
                    value={generalSettings.allowRegistrations ? 'enabled' : 'disabled'}
                    onValueChange={(value) => setGeneralSettings({
                      ...generalSettings,
                      allowRegistrations: value === 'enabled'
                    })}
                  >
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="enabled">Enabled</SelectItem>
                      <SelectItem value="disabled">Disabled</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Max Active Quests per User</Label>
                  <Input type="number" defaultValue="10" />
                </div>
              </div>
              <div className="flex justify-end">
                <Button onClick={() => openSettingsDialog('general')}>
                  <Save className="h-4 w-4 mr-2" />
                  Save Settings
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Settings Confirmation Dialog */}
      <Dialog open={isSettingsDialogOpen} onOpenChange={setIsSettingsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Settings Update</DialogTitle>
            <DialogDescription>
              Are you sure you want to save these settings? This may affect system behavior.
            </DialogDescription>
          </DialogHeader>
          <div className="flex justify-end space-x-2">
            <Button variant="outline" onClick={() => setIsSettingsDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSaveSettings}>
              Save Settings
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}