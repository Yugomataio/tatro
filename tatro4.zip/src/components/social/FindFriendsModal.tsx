"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Search, UserPlus, UserCheck, Clock, X } from "lucide-react"

interface Friend {
  id: string
  name: string
  email: string
  avatar?: string
  rank: string
  level: number
  friendshipStatus: string
}

interface FindFriendsModalProps {
  isOpen: boolean
  onClose: () => void
  onSuccess: () => void
  user: any
}

export default function FindFriendsModal({ isOpen, onClose, onSuccess, user }: FindFriendsModalProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [searchResults, setSearchResults] = useState<Friend[]>([])
  const [loading, setLoading] = useState(false)
  const [actionLoading, setActionLoading] = useState<string | null>(null)
  const [error, setError] = useState("")

  useEffect(() => {
    if (isOpen && searchQuery.length >= 2) {
      searchUsers()
    } else {
      setSearchResults([])
    }
  }, [searchQuery, isOpen])

  const searchUsers = async () => {
    setLoading(true)
    setError("")

    try {
      const token = localStorage.getItem('adventure_guild_token')
      if (!token) {
        setError("Authentication required")
        return
      }

      const response = await fetch(`/api/users/search?q=${encodeURIComponent(searchQuery)}&currentUserId=${user.id}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      const data = await response.json()

      if (response.ok) {
        setSearchResults(data.users || [])
      } else {
        setError(data.error || "Failed to search users")
      }
    } catch (error) {
      console.error('Error searching users:', error)
      setError("Failed to search users")
    } finally {
      setLoading(false)
    }
  }

  const handleFriendRequest = async (friendId: string) => {
    setActionLoading(friendId)
    setError("")

    try {
      const token = localStorage.getItem('adventure_guild_token')
      if (!token) {
        setError("Authentication required")
        return
      }

      const response = await fetch('/api/friends', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          action: 'request',
          fromUserId: user.id,
          toUserId: friendId,
        })
      })

      const data = await response.json()

      if (response.ok) {
        // Update the search results to show pending status
        setSearchResults(prev => 
          prev.map(friend => 
            friend.id === friendId 
              ? { ...friend, friendshipStatus: 'PENDING' }
              : friend
          )
        )
        onSuccess()
      } else {
        setError(data.error || "Failed to send friend request")
      }
    } catch (error) {
      console.error('Error sending friend request:', error)
      setError("Failed to send friend request")
    } finally {
      setActionLoading(null)
    }
  }

  const getFriendshipButton = (friend: Friend) => {
    switch (friend.friendshipStatus) {
      case 'NONE':
        return (
          <Button
            size="sm"
            onClick={() => handleFriendRequest(friend.id)}
            disabled={actionLoading === friend.id}
          >
            {actionLoading === friend.id ? (
              <Clock className="h-4 w-4 animate-spin" />
            ) : (
              <UserPlus className="h-4 w-4 mr-1" />
            )}
            Add Friend
          </Button>
        )
      case 'PENDING':
        return (
          <Button size="sm" variant="outline" disabled>
            <Clock className="h-4 w-4 mr-1" />
            Pending
          </Button>
        )
      case 'ACCEPTED':
        return (
          <Button size="sm" variant="outline" disabled>
            <UserCheck className="h-4 w-4 mr-1" />
            Friends
          </Button>
        )
      case 'BLOCKED':
        return (
          <Button size="sm" variant="destructive" disabled>
            <X className="h-4 w-4 mr-1" />
            Blocked
          </Button>
        )
      default:
        return null
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px] max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Find Friends</DialogTitle>
          <DialogDescription>
            Search for other guild members to connect with.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="search">Search Users</Label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                id="search"
                type="text"
                placeholder="Search by name or email..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          {error && (
            <div className="text-sm text-red-600 bg-red-50 p-3 rounded-md">
              {error}
            </div>
          )}

          {searchQuery.length >= 2 && (
            <div className="space-y-2">
              <Label>Search Results</Label>
              <ScrollArea className="h-[400px] border rounded-md">
                {loading ? (
                  <div className="flex items-center justify-center h-32">
                    <Clock className="h-6 w-6 animate-spin text-muted-foreground" />
                  </div>
                ) : searchResults.length === 0 ? (
                  <div className="flex items-center justify-center h-32 text-muted-foreground">
                    No users found
                  </div>
                ) : (
                  <div className="space-y-2 p-4">
                    {searchResults.map((friend) => (
                      <div key={friend.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex items-center space-x-3">
                          <Avatar>
                            <AvatarImage src={friend.avatar} alt={friend.name} />
                            <AvatarFallback>{friend.name.charAt(0)}</AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium">{friend.name}</p>
                            <p className="text-sm text-muted-foreground">{friend.email}</p>
                            <div className="flex items-center gap-2 mt-1">
                              <Badge variant="outline" className="text-xs">
                                {friend.rank}
                              </Badge>
                              <span className="text-xs text-muted-foreground">
                                Level {friend.level}
                              </span>
                            </div>
                          </div>
                        </div>
                        {getFriendshipButton(friend)}
                      </div>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </div>
          )}

          {searchQuery.length < 2 && searchQuery.length > 0 && (
            <div className="text-center text-muted-foreground py-8">
              <Search className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>Type at least 2 characters to search for users</p>
            </div>
          )}

          {searchQuery.length === 0 && (
            <div className="text-center text-muted-foreground py-8">
              <Search className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>Search for other guild members by name or email</p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}