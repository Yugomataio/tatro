'use client'

import { useState } from 'react'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Coins, CreditCard } from 'lucide-react'

interface BuyCreditsModalProps {
  isOpen: boolean
  onClose: () => void
  onBuyCredits: (amount: number) => void
  currentCredits: number
}

const CREDIT_PACKAGES = [
  { amount: 100, bonus: 0, price: 1.00 },
  { amount: 500, bonus: 25, price: 5.00 },
  { amount: 1000, bonus: 75, price: 10.00 },
  { amount: 2500, bonus: 250, price: 25.00 },
  { amount: 5000, bonus: 600, price: 50.00 },
]

export default function BuyCreditsModal({ isOpen, onClose, onBuyCredits, currentCredits }: BuyCreditsModalProps) {
  const [selectedAmount, setSelectedAmount] = useState<number>(100)
  const [customAmount, setCustomAmount] = useState<string>('')
  const [isProcessing, setIsProcessing] = useState(false)

  const handlePackageSelect = (amount: number) => {
    setSelectedAmount(amount)
    setCustomAmount('')
  }

  const handleCustomAmountChange = (value: string) => {
    setCustomAmount(value)
    setSelectedAmount(0)
  }

  const getPackageForAmount = (amount: number) => {
    return CREDIT_PACKAGES.find(pkg => pkg.amount === amount)
  }

  const getCurrentPackage = () => {
    if (customAmount) {
      const amount = parseInt(customAmount)
      return {
        amount: amount || 0,
        bonus: 0,
        price: ((amount || 0) / 100).toFixed(2)
      }
    }
    return getPackageForAmount(selectedAmount) || CREDIT_PACKAGES[0]
  }

  const handleBuy = async () => {
    const currentPkg = getCurrentPackage()
    if (currentPkg.amount <= 0) return

    setIsProcessing(true)
    try {
      await onBuyCredits(currentPkg.amount)
    } finally {
      setIsProcessing(false)
    }
  }

  const currentPkg = getCurrentPackage()
  const totalCredits = currentPkg.amount + currentPkg.bonus

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Coins className="h-5 w-5 text-yellow-500" />
            <span>Buy Company Credits (CC)</span>
          </DialogTitle>
          <DialogDescription>
            Purchase credits to use in the Adventure Guild marketplace
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Current Balance */}
          <div className="text-center p-4 bg-muted rounded-lg">
            <p className="text-sm text-muted-foreground">Current Balance</p>
            <p className="text-2xl font-bold text-yellow-600">{currentCredits} CC</p>
          </div>

          {/* Credit Packages */}
          <div className="space-y-3">
            <Label className="text-sm font-medium">Choose Package</Label>
            <div className="grid grid-cols-1 gap-2">
              {CREDIT_PACKAGES.map((pkg) => (
                <Button
                  key={pkg.amount}
                  variant={selectedAmount === pkg.amount ? "default" : "outline"}
                  className="justify-start h-auto p-3"
                  onClick={() => handlePackageSelect(pkg.amount)}
                >
                  <div className="flex items-center justify-between w-full">
                    <div className="text-left">
                      <div className="font-semibold">{pkg.amount.toLocaleString()} CC</div>
                      {pkg.bonus > 0 && (
                        <div className="text-xs text-green-600">
                          +{pkg.bonus} bonus credits
                        </div>
                      )}
                    </div>
                    <div className="text-right">
                      <div className="font-semibold">${pkg.price.toFixed(2)}</div>
                      <div className="text-xs text-muted-foreground">
                        ${(pkg.price / (pkg.amount + pkg.bonus) * 100).toFixed(3)}/CC
                      </div>
                    </div>
                  </div>
                </Button>
              ))}
            </div>
          </div>

          {/* Custom Amount */}
          <div className="space-y-2">
            <Label className="text-sm font-medium">Or enter custom amount</Label>
            <div className="flex space-x-2">
              <Input
                type="number"
                placeholder="Custom amount"
                value={customAmount}
                onChange={(e) => handleCustomAmountChange(e.target.value)}
                min="1"
                max="10000"
              />
              <span className="flex items-center text-sm text-muted-foreground">CC</span>
            </div>
          </div>

          {/* Order Summary */}
          <div className="border rounded-lg p-4 space-y-2">
            <div className="flex justify-between text-sm">
              <span>Credits:</span>
              <span>{currentPkg.amount.toLocaleString()} CC</span>
            </div>
            {currentPkg.bonus > 0 && (
              <div className="flex justify-between text-sm text-green-600">
                <span>Bonus Credits:</span>
                <span>+{currentPkg.bonus.toLocaleString()} CC</span>
              </div>
            )}
            <div className="border-t pt-2 flex justify-between font-semibold">
              <span>Total Credits:</span>
              <span>{totalCredits.toLocaleString()} CC</span>
            </div>
            <div className="flex justify-between text-lg font-bold">
              <span>Price:</span>
              <span>${currentPkg.price}</span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex space-x-2">
            <Button variant="outline" onClick={onClose} className="flex-1">
              Cancel
            </Button>
            <Button 
              onClick={handleBuy} 
              disabled={currentPkg.amount <= 0 || isProcessing}
              className="flex-1"
            >
              {isProcessing ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Processing...
                </>
              ) : (
                <>
                  <CreditCard className="h-4 w-4 mr-2" />
                  Buy Now
                </>
              )}
            </Button>
          </div>

          {/* Security Note */}
          <div className="text-xs text-muted-foreground text-center">
            <p>Secure payment processing. All transactions are encrypted.</p>
            <p>5% processing fee applies to all purchases.</p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}