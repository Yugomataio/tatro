"use client"

import { useState, useEffect, useRef } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Separator } from "@/components/ui/separator"
import { useAuth } from "@/contexts/AuthContext"
import ProfileCustomizationModal from "./ProfileCustomizationModal"
import { 
  Award, 
  BookOpen, 
  Shield, 
  Star, 
  Target, 
  Calendar,
  Eye,
  EyeOff,
  MapPin,
  Zap,
  Crown,
  Music,
  Play,
  Pause,
  Edit,
  Video,
  Settings,
  Type,
  Layout
} from "lucide-react"

interface Skill {
  id: string
  name: string
  level: number
  description: string
  category: string
}

interface Ability {
  id: string
  name: string
  description: string
  category: string // NATURAL_TALENT, FAST_LEARNING, SKILLED_AREA
  discoveredAt: string
  proficiency: number // 1-100
}

interface ProfileCustomization {
  id: string
  backgroundImage?: string
  profileSong?: string
  songTitle?: string
  songArtist?: string
  profileVideo?: string
  videoTitle?: string
  themeColor?: string
  customCss?: string
  layoutStyle: string // DEFAULT, CREATIVE, MINIMAL, BOLD
  fontFamily?: string
  fontSize?: string
  textColor?: string
  backgroundColor?: string
  showMusicPlayer: boolean
  showVideoProfile: boolean
  animationsEnabled: boolean
}

interface Credential {
  id: string
  title: string
  description: string
  issuedBy: string
  issuedDate: string
  imageUrl?: string
}

interface QuestHistoryItem {
  id: string
  title: string
  description: string
  status: string
  completedAt?: string
  difficulty: string
  reward: number
  xpReward: number
  isHidden: boolean
}

export default function UserProfileTab() {
  const { user } = useAuth()
  const [skills, setSkills] = useState<Skill[]>([])
  const [abilities, setAbilities] = useState<Ability[]>([])
  const [credentials, setCredentials] = useState<Credential[]>([])
  const [questHistory, setQuestHistory] = useState<QuestHistoryItem[]>([])
  const [profileCustomization, setProfileCustomization] = useState<ProfileCustomization | null>(null)
  const [loading, setLoading] = useState(true)
  const [showCustomizationModal, setShowCustomizationModal] = useState(false)
  const [videoPlaying, setVideoPlaying] = useState(false)
  const [musicPlaying, setMusicPlaying] = useState(false)
  const audioRef = useRef<HTMLAudioElement>(null)

  // Autoplay music when profile loads and customization is available
  useEffect(() => {
    if (profileCustomization?.profileSong && profileCustomization.showMusicPlayer && audioRef.current) {
      // Try to autoplay music handle potential browser restrictions
      const playPromise = audioRef.current.play()
      if (playPromise !== undefined) {
        playPromise.then(() => {
          setMusicPlaying(true)
        }).catch((error) => {
          console.log('Autoplay prevented:', error)
          setMusicPlaying(false)
        })
      }
    }
  }, [profileCustomization])

  useEffect(() => {
    if (user) {
      fetchProfileData()
    }
  }, [user])

  const fetchProfileData = async () => {
    if (!user) return
    
    try {
      const token = localStorage.getItem('adventure_guild_token')
      if (!token) return

      const headers = {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      }

      // Fetch skills
      const skillsResponse = await fetch(`/api/users/${user.id}/skills`, { headers })
      const skillsData = await skillsResponse.json()
      setSkills(skillsData.skills || [])

      // Fetch abilities
      const abilitiesResponse = await fetch(`/api/users/${user.id}/abilities`, { headers })
      const abilitiesData = await abilitiesResponse.json()
      setAbilities(abilitiesData.abilities || [])

      // Fetch credentials
      const credentialsResponse = await fetch(`/api/users/${user.id}/credentials`, { headers })
      const credentialsData = await credentialsResponse.json()
      setCredentials(credentialsData.credentials || [])

      // Fetch profile customization
      const customizationResponse = await fetch(`/api/users/${user.id}/customization`, { headers })
      const customizationData = await customizationResponse.json()
      setProfileCustomization(customizationData.customization || null)

      // Fetch quest history
      const questHistoryResponse = await fetch(`/api/users/${user.id}/quest-history`, { headers })
      const questHistoryData = await questHistoryResponse.json()
      setQuestHistory(questHistoryData.questHistory || [])
    } catch (error) {
      console.error('Error fetching profile data:', error)
    } finally {
      setLoading(false)
    }
  }

  const toggleQuestVisibility = async (questId: string) => {
    try {
      const token = localStorage.getItem('adventure_guild_token')
      if (!token) return

      const response = await fetch(`/api/users/${user.id}/quest-history/${questId}/toggle-visibility`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        setQuestHistory(prev => prev.map(quest => 
          quest.id === questId ? { ...quest, isHidden: !quest.isHidden } : quest
        ))
      }
    } catch (error) {
      console.error('Error toggling quest visibility:', error)
    }
  }

  const getSkillIcon = (category: string) => {
    switch (category.toLowerCase()) {
      case 'combat':
        return <Shield className="h-4 w-4" />
      case 'magic':
        return <Zap className="h-4 w-4" />
      case 'crafting':
        return <BookOpen className="h-4 w-4" />
      case 'exploration':
        return <MapPin className="h-4 w-4" />
      default:
        return <Star className="h-4 w-4" />
    }
  }

  const getAbilityIcon = (category: string) => {
    switch (category.toLowerCase()) {
      case 'natural_talent':
        return <Star className="h-4 w-4" />
      case 'fast_learning':
        return <Target className="h-4 w-4" />
      case 'skilled_area':
        return <Award className="h-4 w-4" />
      default:
        return <Star className="h-4 w-4" />
    }
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty.toLowerCase()) {
      case 'easy':
        return 'bg-green-100 text-green-800'
      case 'medium':
        return 'bg-yellow-100 text-yellow-800'
      case 'hard':
        return 'bg-red-100 text-red-800'
      case 'expert':
        return 'bg-purple-100 text-purple-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    )
  }

  return (
    <div 
      className={`space-y-6 ${
        profileCustomization?.fontSize === 'small' ? 'font-size-small' :
        profileCustomization?.fontSize === 'medium' ? 'font-size-medium' :
        profileCustomization?.fontSize === 'large' ? 'font-size-large' :
        profileCustomization?.fontSize === 'x-large' ? 'font-size-x-large' : ''
      } ${
        profileCustomization?.animationsEnabled ? 'animations-enabled' : 'animations-disabled'
      }`}
      style={{
        fontFamily: profileCustomization?.fontFamily || undefined,
        color: profileCustomization?.textColor || undefined,
        backgroundColor: profileCustomization?.backgroundColor || undefined,
        '--theme-color': profileCustomization?.themeColor || undefined,
      } as React.CSSProperties}
      data-theme-color={profileCustomization?.themeColor ? 'true' : undefined}
    >
      {/* Apply custom CSS if provided */}
      {profileCustomization?.customCss && (
        <style dangerouslySetInnerHTML={{ __html: profileCustomization.customCss }} />
      )}
      
      {/* Profile Header with Customization */}
      <Card className={`relative overflow-hidden ${
        profileCustomization?.layoutStyle === 'CREATIVE' ? 'layout-creative' :
        profileCustomization?.layoutStyle === 'MINIMAL' ? 'layout-minimal' :
        profileCustomization?.layoutStyle === 'BOLD' ? 'layout-bold' : ''
      }`}>
        {profileCustomization?.backgroundImage && (
          <div 
            className="absolute inset-0 bg-cover bg-center opacity-20"
            style={{ backgroundImage: `url(${profileCustomization.backgroundImage})` }}
          />
        )}
        <CardHeader className="relative z-10">
          <div className="flex items-center space-x-4">
            {/* Profile Avatar or Video */}
            <div className="relative">
              {profileCustomization?.profileVideo && profileCustomization.showVideoProfile ? (
                <div className="relative w-16 h-16 rounded-full overflow-hidden">
                  <video 
                    src={profileCustomization.profileVideo}
                    className="w-full h-full object-cover"
                    controls={false}
                    muted
                    loop
                    autoPlay={videoPlaying}
                    onClick={() => setVideoPlaying(!videoPlaying)}
                  />
                  <div className="absolute inset-0 flex items-center justify-center bg-black/30 cursor-pointer">
                    <Button 
                      variant="ghost" 
                      size="sm"
                      className="w-8 h-8 p-0 bg-white/20 hover:bg-white/30"
                      onClick={() => setVideoPlaying(!videoPlaying)}
                    >
                      {videoPlaying ? (
                        <Pause className="h-4 w-4 text-white" />
                      ) : (
                        <Play className="h-4 w-4 text-white" />
                      )}
                    </Button>
                  </div>
                </div>
              ) : (
                <Avatar className="h-16 w-16">
                  <AvatarImage src={user?.avatar} alt={user?.name} />
                  <AvatarFallback className="text-lg">{user?.name?.charAt(0) || 'U'}</AvatarFallback>
                </Avatar>
              )}
              {profileCustomization?.profileVideo && (
                <div className="absolute -bottom-1 -right-1">
                  <Video className="h-4 w-4 text-primary bg-background rounded-full p-0.5" />
                </div>
              )}
            </div>
            
            <div className="flex-1">
              <h2 className="text-2xl font-bold">{user?.name}</h2>
              <p className="text-muted-foreground">{user?.rank}</p>
              <div className="flex items-center space-x-2 mt-1">
                <Badge variant="secondary">Level {user?.level}</Badge>
                <Badge variant="outline">{user?.experience} XP</Badge>
              </div>
            </div>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setShowCustomizationModal(true)}
            >
              <Edit className="h-4 w-4 mr-2" />
              Customize Profile
            </Button>
          </div>
          
          {/* Profile Music Player */}
          {profileCustomization?.profileSong && profileCustomization.showMusicPlayer && (
            <div className="mt-4 p-3 bg-muted/50 rounded-lg">
              <div className="flex items-center space-x-3">
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 bg-primary/10 rounded flex items-center justify-center">
                    <Music className="h-6 w-6 text-primary" />
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">
                    {profileCustomization.songTitle || "Profile Song"}
                  </p>
                  <p className="text-xs text-muted-foreground truncate">
                    {profileCustomization.songArtist || "Unknown Artist"}
                  </p>
                </div>
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => {
                    if (audioRef.current) {
                      if (musicPlaying) {
                        audioRef.current.pause()
                      } else {
                        audioRef.current.play().catch(console.error)
                      }
                    }
                  }}
                >
                  {musicPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                </Button>
              </div>
              {/* Hidden audio element */}
              <audio 
                ref={audioRef}
                src={profileCustomization.profileSong}
                loop
                onPlay={() => setMusicPlaying(true)}
                onPause={() => setMusicPlaying(false)}
                onEnded={() => setMusicPlaying(false)}
              />
            </div>
          )}
        </CardHeader>
      </Card>

      {/* Skills Section */}
      <Card className={`${
        profileCustomization?.layoutStyle === 'CREATIVE' ? 'layout-creative' :
        profileCustomization?.layoutStyle === 'MINIMAL' ? 'layout-minimal' :
        profileCustomization?.layoutStyle === 'BOLD' ? 'layout-bold' : ''
      }`}
      style={{
        fontFamily: profileCustomization?.fontFamily || undefined,
        color: profileCustomization?.textColor || undefined,
        backgroundColor: profileCustomization?.backgroundColor || undefined,
      } as React.CSSProperties}>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Star className="h-5 w-5" />
            <span>Skills</span>
          </CardTitle>
          <CardDescription>Your trained abilities and expertise</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {skills.map((skill) => (
              <div key={skill.id} className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    {getSkillIcon(skill.category)}
                    <h3 className="font-semibold">{skill.name}</h3>
                  </div>
                  <Badge variant="outline">Level {skill.level}</Badge>
                </div>
                <p className="text-sm text-muted-foreground mb-2">{skill.description}</p>
                <Badge variant="secondary" className="text-xs">{skill.category}</Badge>
              </div>
            ))}
            {skills.length === 0 && (
              <div className="col-span-full text-center py-8 text-muted-foreground">
                No skills available. Start training to develop your abilities!
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Natural Abilities Section */}
      <Card className={`${
        profileCustomization?.layoutStyle === 'CREATIVE' ? 'layout-creative' :
        profileCustomization?.layoutStyle === 'MINIMAL' ? 'layout-minimal' :
        profileCustomization?.layoutStyle === 'BOLD' ? 'layout-bold' : ''
      }`}
      style={{
        fontFamily: profileCustomization?.fontFamily || undefined,
        color: profileCustomization?.textColor || undefined,
        backgroundColor: profileCustomization?.backgroundColor || undefined,
      } as React.CSSProperties}>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Star className="h-5 w-5" />
            <span>Natural Abilities</span>
          </CardTitle>
          <CardDescription>Your innate talents and areas where you learn quickly</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {abilities.map((ability) => (
              <div key={ability.id} className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    {getAbilityIcon(ability.category)}
                    <h3 className="font-semibold">{ability.name}</h3>
                  </div>
                  <Badge variant="outline">{ability.category.replace('_', ' ').toLowerCase()}</Badge>
                </div>
                <p className="text-sm text-muted-foreground mb-3">{ability.description}</p>
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <span>Proficiency</span>
                    <span>{ability.proficiency}%</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div 
                      className="bg-primary h-2 rounded-full" 
                      style={{ width: `${ability.proficiency}%` }}
                    ></div>
                  </div>
                </div>
                <div className="flex items-center space-x-2 text-xs text-muted-foreground mt-2">
                  <Calendar className="h-3 w-3" />
                  <span>Discovered {new Date(ability.discoveredAt).toLocaleDateString()}</span>
                </div>
              </div>
            ))}
            {abilities.length === 0 && (
              <div className="col-span-full text-center py-8 text-muted-foreground">
                No natural abilities identified yet. As you participate in activities, your innate talents will be discovered!
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Credentials Section */}
      <Card className={`${
        profileCustomization?.layoutStyle === 'CREATIVE' ? 'layout-creative' :
        profileCustomization?.layoutStyle === 'MINIMAL' ? 'layout-minimal' :
        profileCustomization?.layoutStyle === 'BOLD' ? 'layout-bold' : ''
      }`}
      style={{
        fontFamily: profileCustomization?.fontFamily || undefined,
        color: profileCustomization?.textColor || undefined,
        backgroundColor: profileCustomization?.backgroundColor || undefined,
      } as React.CSSProperties}>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Award className="h-5 w-5" />
            <span>Credentials</span>
          </CardTitle>
          <CardDescription>Certifications and achievements you've earned</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {credentials.map((credential) => (
              <div key={credential.id} className="border rounded-lg p-4">
                <div className="flex items-start space-x-3">
                  {credential.imageUrl && (
                    <img 
                      src={credential.imageUrl} 
                      alt={credential.title}
                      className="w-12 h-12 rounded object-cover"
                    />
                  )}
                  <div className="flex-1">
                    <h3 className="font-semibold">{credential.title}</h3>
                    <p className="text-sm text-muted-foreground mb-2">{credential.description}</p>
                    <div className="flex items-center justify-between text-xs text-muted-foreground">
                      <span>Issued by {credential.issuedBy}</span>
                      <span>{new Date(credential.issuedDate).toLocaleDateString()}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
            {credentials.length === 0 && (
              <div className="col-span-full text-center py-8 text-muted-foreground">
                No credentials earned yet. Complete special challenges to earn credentials!
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Quest History Section */}
      <Card className={`${
        profileCustomization?.layoutStyle === 'CREATIVE' ? 'layout-creative' :
        profileCustomization?.layoutStyle === 'MINIMAL' ? 'layout-minimal' :
        profileCustomization?.layoutStyle === 'BOLD' ? 'layout-bold' : ''
      }`}
      style={{
        fontFamily: profileCustomization?.fontFamily || undefined,
        color: profileCustomization?.textColor || undefined,
        backgroundColor: profileCustomization?.backgroundColor || undefined,
      } as React.CSSProperties}>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Calendar className="h-5 w-5" />
            <span>Quest History</span>
          </CardTitle>
          <CardDescription>Your completed and ongoing quests</CardDescription>
        </CardHeader>
        <CardContent>
          <ScrollArea className="max-h-96">
            <div className="space-y-4">
              {questHistory
                .filter(quest => !quest.isHidden)
                .map((quest) => (
                <div key={quest.id} className="border rounded-lg p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <h3 className="font-semibold">{quest.title}</h3>
                        <Badge className={getDifficultyColor(quest.difficulty)}>
                          {quest.difficulty}
                        </Badge>
                        <Badge variant={quest.status === 'completed' ? 'default' : 'secondary'}>
                          {quest.status}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">{quest.description}</p>
                      <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                        <span>Reward: {quest.reward} CC</span>
                        <span>XP: {quest.xpReward}</span>
                        {quest.completedAt && (
                          <span>Completed: {new Date(quest.completedAt).toLocaleDateString()}</span>
                        )}
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => toggleQuestVisibility(quest.id)}
                      className="ml-2"
                    >
                      <EyeOff className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
              {questHistory.filter(quest => !quest.isHidden).length === 0 && (
                <div className="text-center py-8 text-muted-foreground">
                  No visible quest history. Complete quests to see them here!
                </div>
              )}
            </div>
          </ScrollArea>
          
          {/* Hidden Quests Section */}
          {questHistory.some(quest => quest.isHidden) && (
            <>
              <Separator className="my-4" />
              <div className="space-y-2">
                <h4 className="text-sm font-semibold text-muted-foreground">Hidden Quests</h4>
                {questHistory
                  .filter(quest => quest.isHidden)
                  .map((quest) => (
                  <div key={quest.id} className="border rounded-lg p-3 bg-muted/50">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <span className="text-sm font-medium">{quest.title}</span>
                        <Badge variant="outline" className="text-xs">{quest.difficulty}</Badge>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => toggleQuestVisibility(quest.id)}
                      >
                        <Eye className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  ))}
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {/* Active Customizations Summary */}
      {profileCustomization && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Settings className="h-5 w-5" />
              <span>Active Customizations</span>
            </CardTitle>
            <CardDescription>
              Your current profile customization settings
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {profileCustomization.themeColor && (
                <div className="flex items-center space-x-2">
                  <div 
                    className="w-4 h-4 rounded-full border"
                    style={{ backgroundColor: profileCustomization.themeColor }}
                  />
                  <span className="text-sm">Theme Color</span>
                </div>
              )}
              
              {profileCustomization.fontFamily && (
                <div className="flex items-center space-x-2">
                  <Type className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">{profileCustomization.fontFamily.split(',')[0]}</span>
                </div>
              )}
              
              {profileCustomization.fontSize && (
                <div className="flex items-center space-x-2">
                  <span className="text-sm font-medium">Size:</span>
                  <span className="text-sm">{profileCustomization.fontSize}</span>
                </div>
              )}
              
              {profileCustomization.layoutStyle && profileCustomization.layoutStyle !== 'DEFAULT' && (
                <div className="flex items-center space-x-2">
                  <Layout className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">{profileCustomization.layoutStyle}</span>
                </div>
              )}
              
              {profileCustomization.showMusicPlayer && profileCustomization.songTitle && (
                <div className="flex items-center space-x-2">
                  <Music className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">{profileCustomization.songTitle}</span>
                </div>
              )}
              
              {profileCustomization.animationsEnabled && (
                <div className="flex items-center space-x-2">
                  <Zap className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">Animations Enabled</span>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Profile Customization Modal */}
      <ProfileCustomizationModal
        isOpen={showCustomizationModal}
        onClose={() => setShowCustomizationModal(false)}
        currentCustomization={profileCustomization}
      />
    </div>
  )
}