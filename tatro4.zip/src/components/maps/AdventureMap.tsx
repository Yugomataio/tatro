'use client'

import { useState, useEffect, useRef } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { useAuth } from '@/contexts/AuthContext'
import { 
  Map, 
  Navigation, 
  ZoomIn, 
  ZoomOut, 
  Target, 
  ShoppingCart,
  Crown,
  Star,
  Coins,
  Filter,
  Loader2
} from 'lucide-react'
import { Loader } from '@googlemaps/js-api-loader'

interface MapLocation {
  id: string
  name: string
  type: 'quest' | 'shop' | 'landmark'
  latitude: number
  longitude: number
  description?: string
  difficulty?: 'EASY' | 'MEDIUM' | 'HARD' | 'EXPERT'
  reward?: number
  price?: number
  creator?: {
    id: string
    name: string
    avatar?: string
  }
}

export default function AdventureMap() {
  const { user } = useAuth()
  const [locations, setLocations] = useState<MapLocation[]>([])
  const [selectedLocation, setSelectedLocation] = useState<MapLocation | null>(null)
  const [filter, setFilter] = useState<'all' | 'quest' | 'shop' | 'landmark'>('all')
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null)
  const [map, setMap] = useState<google.maps.Map | null>(null)
  const [markers, setMarkers] = useState<google.maps.Marker[]>([])
  const [loading, setLoading] = useState(true)
  const [mapError, setMapError] = useState<string | null>(null)
  const mapRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const initializeMap = async () => {
      try {
        // Check if Google Maps API key is available
        const apiKey = process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY
        if (!apiKey) {
          setMapError('Google Maps API key is not configured')
          setLoading(false)
          return
        }

        // Initialize Google Maps
        const loader = new Loader({
          apiKey: apiKey,
          version: 'weekly',
          libraries: ['places']
        })

        const google = await loader.load()
        
        if (mapRef.current) {
          const mapInstance = new google.maps.Map(mapRef.current, {
            center: { lat: 40.7128, lng: -74.0060 }, // New York City
            zoom: 12,
            styles: [
              {
                featureType: 'all',
                elementType: 'geometry.fill',
                stylers: [{ weight: '2.00' }]
              },
              {
                featureType: 'all',
                elementType: 'geometry.stroke',
                stylers: [{ color: '#9c9c9c' }]
              },
              {
                featureType: 'all',
                elementType: 'labels.text',
                stylers: [{ visibility: 'on' }]
              }
            ]
          })

          setMap(mapInstance)
          fetchMapLocations(mapInstance)
          getUserLocation(mapInstance)
        }
      } catch (error) {
        console.error('Error initializing map:', error)
        setMapError('Failed to load Google Maps. Please check your internet connection.')
        setLoading(false)
      }
    }

    initializeMap()
  }, [])

  const fetchMapLocations = async (mapInstance: google.maps.Map) => {
    try {
      const response = await fetch('/api/map')
      const data = await response.json()
      
      const mapLocations: MapLocation[] = [
        ...(data.quests || []).map((quest: any) => ({
          id: quest.id,
          name: quest.title,
          type: 'quest' as const,
          latitude: quest.latitude || 40.7128,
          longitude: quest.longitude || -74.0060,
          description: quest.description,
          difficulty: quest.difficulty,
          reward: quest.reward,
          creator: quest.creator,
        })),
        ...(data.shopItems || []).map((item: any) => ({
          id: item.id,
          name: item.name,
          type: 'shop' as const,
          latitude: item.latitude || 40.7128,
          longitude: item.longitude || -74.0060,
          description: item.description,
          price: item.price,
          creator: item.creator,
        })),
        ...(data.landmarks || []).map((landmark: any) => ({
          id: landmark.id,
          name: landmark.name,
          type: 'landmark' as const,
          latitude: landmark.latitude || 40.7128,
          longitude: landmark.longitude || -74.0060,
          description: landmark.description,
        })),
      ]

      setLocations(mapLocations)
      addMarkersToMap(mapInstance, mapLocations)
      setLoading(false)
    } catch (error) {
      console.error('Error fetching map locations:', error)
      setLoading(false)
    }
  }

  const addMarkersToMap = (mapInstance: google.maps.Map, locations: MapLocation[]) => {
    // Clear existing markers
    markers.forEach(marker => marker.setMap(null))
    const newMarkers: google.maps.Marker[] = []

    locations.forEach(location => {
      const marker = new google.maps.Marker({
        position: { lat: location.latitude, lng: location.longitude },
        map: mapInstance,
        title: location.name,
        icon: {
          url: getMarkerIcon(location.type),
          scaledSize: new google.maps.Size(32, 32),
        },
      })

      marker.addListener('click', () => {
        setSelectedLocation(location)
        mapInstance.panTo({ lat: location.latitude, lng: location.longitude })
      })

      newMarkers.push(marker)
    })

    setMarkers(newMarkers)
  }

  const getMarkerIcon = (type: string) => {
    switch (type) {
      case 'quest':
        return 'data:image/svg+xml;base64,' + btoa(`
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="#ef4444">
            <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/>
          </svg>
        `)
      case 'shop':
        return 'data:image/svg+xml;base64,' + btoa(`
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="#3b82f6">
            <path d="M7 18c-1.1 0-1.99.9-1.99 2S5.9 22 7 22s2-.9 2-2-.9-2-2-2zM1 2v2h2l3.6 7.59-1.35 2.45c-.16.28-.25.61-.25.96 0 1.1.9 2 2 2h12v-2H7.42c-.14 0-.25-.11-.25-.25l.03-.12.9-1.63h7.45c.75 0 1.41-.41 1.75-1.03l3.58-6.49c.08-.14.12-.31.12-.48 0-.55-.45-1-1-1H5.21l-.94-2H1zm16 16c-1.1 0-1.99.9-1.99 2s.89 2 1.99 2 2-.9 2-2-.9-2-2-2z"/>
          </svg>
        `)
      case 'landmark':
        return 'data:image/svg+xml;base64,' + btoa(`
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="#10b981">
            <path d="M12 2l-5.5 9h11z M12 5.84L13.93 9h-3.87z M17.5 13c-2.49 0-4.5 2.01-4.5 4.5s2.01 4.5 4.5 4.5 4.5-2.01 4.5-4.5-2.01-4.5-4.5-4.5z M6.5 13c-2.49 0-4.5 2.01-4.5 4.5s2.01 4.5 4.5 4.5 4.5-2.01 4.5-4.5-2.01-4.5-4.5-4.5z"/>
          </svg>
        `)
      default:
        return 'data:image/svg+xml;base64,' + btoa(`
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="#6b7280">
            <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/>
          </svg>
        `)
    }
  }

  const getUserLocation = (mapInstance: google.maps.Map) => {
    // Use user's profile location if available, otherwise default to New York City
    let location = { lat: 40.7128, lng: -74.0060 } // Default to NYC
    
    if (user?.latitude && user?.longitude) {
      location = {
        lat: user.latitude,
        lng: user.longitude
      }
    } else if (user?.location) {
      // Simple geocoding for common locations (in a real app, you'd use a proper geocoding service)
      const locationMap: Record<string, { lat: number; lng: number }> = {
        'new york': { lat: 40.7128, lng: -74.0060 },
        'los angeles': { lat: 34.0522, lng: -118.2437 },
        'chicago': { lat: 41.8781, lng: -87.6298 },
        'houston': { lat: 29.7604, lng: -95.3698 },
        'phoenix': { lat: 33.4484, lng: -112.0740 },
        'philadelphia': { lat: 39.9526, lng: -75.1652 },
        'san antonio': { lat: 29.4241, lng: -98.4936 },
        'san diego': { lat: 32.7157, lng: -117.1611 },
        'dallas': { lat: 32.7767, lng: -96.7970 },
        'san jose': { lat: 37.3382, lng: -121.8863 },
        'austin': { lat: 30.2672, lng: -97.7431 },
        'jacksonville': { lat: 30.3322, lng: -81.6557 },
        'fort worth': { lat: 32.7555, lng: -97.3308 },
        'columbus': { lat: 39.9612, lng: -82.9988 },
        'san francisco': { lat: 37.7749, lng: -122.4194 },
        'charlotte': { lat: 35.2271, lng: -80.8431 },
        'indianapolis': { lat: 39.7684, lng: -86.1581 },
        'seattle': { lat: 47.6062, lng: -122.3321 },
        'denver': { lat: 39.7392, lng: -104.9903 },
        'washington': { lat: 38.9072, lng: -77.0369 },
        'boston': { lat: 42.3601, lng: -71.0589 },
        'el paso': { lat: 31.7619, lng: -106.4850 },
        'detroit': { lat: 42.3314, lng: -83.0458 },
        'nashville': { lat: 36.1627, lng: -86.7816 },
        'portland': { lat: 45.5152, lng: -122.6784 },
        'memphis': { lat: 35.1495, lng: -90.0490 },
        'oklahoma city': { lat: 35.4676, lng: -97.5164 },
        'las vegas': { lat: 36.1699, lng: -115.1398 },
        'louisville': { lat: 38.2527, lng: -85.7585 },
        'baltimore': { lat: 39.2904, lng: -76.6122 },
        'milwaukee': { lat: 43.0389, lng: -87.9065 },
        'albuquerque': { lat: 35.0844, lng: -106.6504 },
        'tucson': { lat: 32.2226, lng: -110.9747 },
        'fresno': { lat: 36.7378, lng: -119.7871 },
        'sacramento': { lat: 38.5816, lng: -121.4944 },
        'kansas city': { lat: 39.0997, lng: -94.5786 },
        'mesa': { lat: 33.4152, lng: -111.8315 },
        'atlanta': { lat: 33.7490, lng: -84.3880 },
        'omaha': { lat: 41.2565, lng: -95.9345 },
        'miami': { lat: 25.7617, lng: -80.1918 },
        'orlando': { lat: 28.5383, lng: -81.3792 },
        'tampa': { lat: 27.9506, lng: -82.4572 },
        'minneapolis': { lat: 44.9778, lng: -93.2650 },
        'cleveland': { lat: 41.4993, lng: -81.6944 },
        'new orleans': { lat: 29.9511, lng: -90.0715 },
        'pittsburgh': { lat: 40.4406, lng: -79.9959 },
        'cincinnati': { lat: 39.1031, lng: -84.5120 },
        'riverside': { lat: 33.9533, lng: -117.3962 },
        'toledo': { lat: 41.6639, lng: -83.5552 },
        'aurora': { lat: 39.7294, lng: -104.8319 },
        'bakersfield': { lat: 35.3733, lng: -119.0187 },
        'tulsa': { lat: 36.1540, lng: -95.9928 },
        'anaheim': { lat: 33.8366, lng: -117.9143 },
        'honolulu': { lat: 21.3069, lng: -157.8583 },
        'anchorage': { lat: 61.2181, lng: -149.9003 },
        'london': { lat: 51.5074, lng: -0.1278 },
        'paris': { lat: 48.8566, lng: 2.3522 },
        'tokyo': { lat: 35.6762, lng: 139.6503 },
        'sydney': { lat: -33.8688, lng: 151.2093 },
        'toronto': { lat: 43.6532, lng: -79.3832 },
        'vancouver': { lat: 49.2827, lng: -123.1207 },
        'montreal': { lat: 45.5017, lng: -73.5673 },
        'berlin': { lat: 52.5200, lng: 13.4050 },
        'rome': { lat: 41.9028, lng: 12.4964 },
        'madrid': { lat: 40.4168, lng: -3.7038 },
        'amsterdam': { lat: 52.3676, lng: 4.9041 },
        'vienna': { lat: 48.2082, lng: 16.3738 },
        'prague': { lat: 50.0755, lng: 14.4378 },
        'warsaw': { lat: 52.2297, lng: 21.0122 },
        'budapest': { lat: 47.4979, lng: 19.0402 },
        'munich': { lat: 48.1351, lng: 11.5820 },
        'stockholm': { lat: 59.3293, lng: 18.0686 },
        'oslo': { lat: 59.9139, lng: 10.7522 },
        'copenhagen': { lat: 55.6761, lng: 12.5683 },
        'helsinki': { lat: 60.1699, lng: 24.9384 },
        'dublin': { lat: 53.3498, lng: -6.2603 },
        'brussels': { lat: 50.8503, lng: 4.3517 },
        'zurich': { lat: 47.3769, lng: 8.5417 },
        'geneva': { lat: 46.2044, lng: 6.1432 },
        'barcelona': { lat: 41.3851, lng: 2.1734 },
        'lisbon': { lat: 38.7223, lng: -9.1393 },
        'porto': { lat: 41.1579, lng: -8.6291 },
        'athens': { lat: 37.9838, lng: 23.7275 },
        'istanbul': { lat: 41.0082, lng: 28.9784 },
        'moscow': { lat: 55.7558, lng: 37.6173 },
        'st. petersburg': { lat: 59.9343, lng: 30.3351 },
        'kiev': { lat: 50.4501, lng: 30.5234 },
        'minsk': { lat: 53.9045, lng: 27.5615 },
        'riga': { lat: 56.9496, lng: 24.1052 },
        'vilnius': { lat: 54.6872, lng: 25.2797 },
        'tallinn': { lat: 59.4370, lng: 24.7536 },
        'helsinki': { lat: 60.1699, lng: 24.9384 }
      }
      
      const userLocationLower = user.location.toLowerCase()
      for (const [city, coords] of Object.entries(locationMap)) {
        if (userLocationLower.includes(city)) {
          location = coords
          break
        }
      }
    }
    
    setUserLocation(location)
    
    // Add user location marker
    new google.maps.Marker({
      position: location,
      map: mapInstance,
      title: 'Your Location',
      icon: {
        url: 'data:image/svg+xml;base64,' + btoa(`
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="#3b82f6">
            <circle cx="12" cy="12" r="8"/>
          </svg>
        `),
        scaledSize: new google.maps.Size(24, 24),
      },
    })
    
    mapInstance.setCenter(location)
  }

  const filteredLocations = locations.filter(location => 
    filter === 'all' || location.type === filter
  )

  useEffect(() => {
    if (map) {
      addMarkersToMap(map, filteredLocations)
    }
  }, [filter, locations])

  const getLocationIcon = (type: string) => {
    switch (type) {
      case 'quest':
        return <Target className="h-6 w-6 text-red-500" />
      case 'shop':
        return <ShoppingCart className="h-6 w-6 text-blue-500" />
      case 'landmark':
        return <Map className="h-6 w-6 text-green-500" />
      default:
        return <Map className="h-6 w-6 text-gray-500" />
    }
  }

  const getDifficultyBadgeColor = (difficulty?: string) => {
    switch (difficulty) {
      case 'EASY':
        return 'default'
      case 'MEDIUM':
        return 'secondary'
      case 'HARD':
        return 'destructive'
      case 'EXPERT':
        return 'destructive'
      default:
        return 'secondary'
    }
  }

  const formatCoordinates = (lat: number, lng: number) => {
    return `${lat.toFixed(4)}°, ${lng.toFixed(4)}°`
  }

  // Simple map calculation for demo purposes
  const calculateDistance = (lat1: number, lng1: number, lat2: number, lng2: number) => {
    const R = 6371 // Earth's radius in kilometers
    const dLat = (lat2 - lat1) * Math.PI / 180
    const dLng = (lng2 - lng1) * Math.PI / 180
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
              Math.sin(dLng/2) * Math.sin(dLng/2)
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
    return R * c
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Adventure Map</h2>
          <p className="text-muted-foreground">
            Explore the world and discover quests, shops, and landmarks
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <Button
            variant={filter === 'all' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setFilter('all')}
          >
            All
          </Button>
          <Button
            variant={filter === 'quest' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setFilter('quest')}
          >
            <Target className="h-4 w-4 mr-2" />
            Quests
          </Button>
          <Button
            variant={filter === 'shop' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setFilter('shop')}
          >
            <ShoppingCart className="h-4 w-4 mr-2" />
            Shops
          </Button>
          <Button
            variant={filter === 'landmark' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setFilter('landmark')}
          >
            <Map className="h-4 w-4 mr-2" />
            Landmarks
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Map Area */}
        <div className="lg:col-span-2">
          <Card className="h-[600px]">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>World Map</CardTitle>
                <div className="flex items-center space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => map?.setZoom(map.getZoom() - 1)}
                  >
                    <ZoomOut className="h-4 w-4" />
                  </Button>
                  <span className="text-sm">Zoom: {map?.getZoom() || 12}</span>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => map?.setZoom(map.getZoom() + 1)}
                  >
                    <ZoomIn className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="h-[500px] relative">
              {loading ? (
                <div className="flex items-center justify-center h-full">
                  <Loader2 className="h-8 w-8 animate-spin" />
                </div>
              ) : !map ? (
                <div className="flex flex-col items-center justify-center h-full bg-muted/20 rounded-lg p-6">
                  <Map className="h-16 w-16 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Map Unavailable</h3>
                  <p className="text-muted-foreground text-center mb-4">
                    {mapError || 'The map is currently unavailable. This could be due to missing API keys or network issues.'}
                  </p>
                  <div className="space-y-2 text-sm text-muted-foreground">
                    <p>• Check your internet connection</p>
                    <p>• Ensure Google Maps API is properly configured</p>
                    <p>• Try refreshing the page</p>
                  </div>
                </div>
              ) : (
                <div 
                  ref={mapRef} 
                  className="w-full h-full rounded-lg"
                />
              )}
              
              {/* Map controls overlay */}
              <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm rounded-lg p-2 shadow-lg">
                <div className="text-xs space-y-1">
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                    <span>Your Location</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Target className="h-3 w-3 text-red-500" />
                    <span>Quests</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <ShoppingCart className="h-3 w-3 text-blue-500" />
                    <span>Shops</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Map className="h-3 w-3 text-green-500" />
                    <span>Landmarks</span>
                  </div>
                </div>
              </div>

              {/* Coordinates display */}
              <div className="absolute bottom-4 left-4 bg-white/90 backdrop-blur-sm rounded-lg p-2 shadow-lg">
                <div className="text-xs">
                  {userLocation ? (
                    <div>Your Position: {formatCoordinates(userLocation.lat, userLocation.lng)}</div>
                  ) : (
                    <div>Location not set</div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Location Details */}
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Location Details</CardTitle>
              <CardDescription>
                Click on a location to see details
              </CardDescription>
            </CardHeader>
            <CardContent>
              {selectedLocation ? (
                <div className="space-y-4">
                  <div className="flex items-center space-x-3">
                    {getLocationIcon(selectedLocation.type)}
                    <div>
                      <h3 className="font-medium">{selectedLocation.name}</h3>
                      <p className="text-sm text-muted-foreground">
                        {formatCoordinates(selectedLocation.latitude, selectedLocation.longitude)}
                      </p>
                    </div>
                  </div>

                  {selectedLocation.description && (
                    <p className="text-sm">{selectedLocation.description}</p>
                  )}

                  {selectedLocation.type === 'quest' && selectedLocation.difficulty && (
                    <div className="flex items-center space-x-2">
                      <Badge variant={getDifficultyBadgeColor(selectedLocation.difficulty)}>
                        {selectedLocation.difficulty}
                      </Badge>
                      {selectedLocation.reward && (
                        <div className="flex items-center space-x-1">
                          <Coins className="h-4 w-4 text-yellow-500" />
                          <span className="text-sm font-medium">{selectedLocation.reward} CC</span>
                        </div>
                      )}
                    </div>
                  )}

                  {selectedLocation.creator && (
                    <div className="flex items-center space-x-2">
                      <Avatar className="h-6 w-6">
                        <AvatarImage src={selectedLocation.creator.avatar} alt={selectedLocation.creator.name} />
                        <AvatarFallback>{selectedLocation.creator.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <span className="text-sm">Created by {selectedLocation.creator.name}</span>
                    </div>
                  )}

                  {userLocation && (
                    <div className="flex items-center space-x-2 text-sm">
                      <Navigation className="h-4 w-4 text-blue-500" />
                      <span>
                        {calculateDistance(
                          userLocation.lat,
                          userLocation.lng,
                          selectedLocation.latitude,
                          selectedLocation.longitude
                        ).toFixed(2)} km away
                      </span>
                    </div>
                  )}

                  <Button className="w-full">
                    <Navigation className="h-4 w-4 mr-2" />
                    Get Directions
                  </Button>
                </div>
              ) : (
                <div className="text-center text-muted-foreground">
                  <Map className="h-12 w-12 mx-auto mb-2 opacity-50" />
                  <p>Select a location on the map to view details</p>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle> Nearby Locations</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {filteredLocations.slice(0, 5).map((location) => (
                  <div
                    key={location.id}
                    className="flex items-center space-x-3 p-2 rounded-lg hover:bg-muted cursor-pointer"
                    onClick={() => {
                      setSelectedLocation(location)
                      map?.panTo({ lat: location.latitude, lng: location.longitude })
                    }}
                  >
                    {getLocationIcon(location.type)}
                    <div className="flex-1">
                      <p className="text-sm font-medium">{location.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {userLocation ? 
                          `${calculateDistance(
                            userLocation.lat,
                            userLocation.lng,
                            location.latitude,
                            location.longitude
                          ).toFixed(1)} km away` : 
                          formatCoordinates(location.latitude, location.longitude)
                        }
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}