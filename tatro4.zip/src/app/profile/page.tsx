'use client'

import { useState, useEffect, useRef } from 'react'
import { useAuth } from '@/contexts/AuthContext'
import PasswordChangeModal from '@/components/auth/PasswordChangeModal'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Separator } from '@/components/ui/separator'
import { Alert, AlertDescription } from '@/components/ui/alert'
import UserProfileTab from '@/components/profile/UserProfileTab'
import { 
  User, 
  Mail, 
  Calendar, 
  Star, 
  Coins, 
  Target, 
  ShoppingCart,
  Heart,
  MessageCircle,
  Share2,
  Edit,
  Settings,
  Crown,
  TrendingUp,
  Award,
  Shield,
  Key,
  MapPin,
  Music,
  Play,
  Pause,
  Video
} from 'lucide-react'

interface ProfileCustomization {
  id: string
  backgroundImage?: string
  profileSong?: string
  songTitle?: string
  songArtist?: string
  profileVideo?: string
  videoTitle?: string
  themeColor?: string
  customCss?: string
  layoutStyle: string // DEFAULT, CREATIVE, MINIMAL, BOLD
  fontFamily?: string
  fontSize?: string
  textColor?: string
  backgroundColor?: string
  showMusicPlayer: boolean
  showVideoProfile: boolean
  animationsEnabled: boolean
}

interface UserProfile {
  id: string
  email: string
  name?: string
  avatar?: string
  bio?: string
  role: 'USER' | 'MODERATOR' | 'ADMIN'
  rank: string
  level: number
  experience: number
  credits: number
  showLocation: boolean
  createdAt: string
  updatedAt: string
}

interface FeedPost {
  id: string
  content: string
  type: 'STATUS' | 'QUEST_COMPLETION' | 'ACHIEVEMENT' | 'SHOP_PURCHASE'
  imageUrl?: string
  createdAt: string
  user: {
    id: string
    name: string
    avatar?: string
  }
  likes: number
  comments: number
  isLiked: boolean
}

interface UserStats {
  totalQuests: number
  completedQuests: number
  totalPurchases: number
  friendsCount: number
  totalPosts: number
}

export default function ProfilePage() {
  const { user, updateUser, changePassword } = useAuth()
  const [isEditing, setIsEditing] = useState(false)
  const [newPost, setNewPost] = useState('')
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null)
  const [feedPosts, setFeedPosts] = useState<FeedPost[]>([])
  const [userStats, setUserStats] = useState<UserStats>({
    totalQuests: 0,
    completedQuests: 0,
    totalPurchases: 0,
    friendsCount: 0,
    totalPosts: 0,
  })
  const [editForm, setEditForm] = useState({
    name: '',
    bio: '',
  })
  const [showPasswordChangeModal, setShowPasswordChangeModal] = useState(false)
  const [passwordChangeError, setPasswordChangeError] = useState('')
  const [passwordChangeSuccess, setPasswordChangeSuccess] = useState('')
  const [profileCustomization, setProfileCustomization] = useState<ProfileCustomization | null>(null)
  const [videoPlaying, setVideoPlaying] = useState(false)
  const [musicPlaying, setMusicPlaying] = useState(false)
  const audioRef = useRef<HTMLAudioElement>(null)
  const videoRef = useRef<HTMLVideoElement>(null)

  useEffect(() => {
    if (user) {
      fetchUserProfile()
      fetchFeedPosts()
      fetchUserStats()
      fetchProfileCustomization()
    }
  }, [user])

  // Autoplay music when profile loads and customization is available
  useEffect(() => {
    console.log('Autoplay effect triggered:', {
      hasSong: !!profileCustomization?.profileSong,
      showMusic: profileCustomization?.showMusicPlayer,
      hasVideo: !!profileCustomization?.profileVideo,
      showVideo: profileCustomization?.showVideoProfile,
      audioReady: !!audioRef.current,
      videoReady: !!videoRef.current
    })
    
    if (profileCustomization?.profileSong && profileCustomization.showMusicPlayer && audioRef.current) {
      console.log('Attempting audio autoplay...')
      // Try to autoplay music handle potential browser restrictions
      const playPromise = audioRef.current.play()
      if (playPromise !== undefined) {
        playPromise.then(() => {
          console.log('Audio autoplay successful')
          setMusicPlaying(true)
        }).catch((error) => {
          console.log('Audio autoplay prevented:', error)
          setMusicPlaying(false)
        })
      }
    }
    
    if (profileCustomization?.profileVideo && profileCustomization.showVideoProfile && videoRef.current) {
      console.log('Attempting video autoplay...')
      // Try to autoplay video (muted videos can usually autoplay)
      videoRef.current.play().then(() => {
        console.log('Video autoplay successful')
        setVideoPlaying(true)
      }).catch((error) => {
        console.log('Video autoplay prevented:', error)
        setVideoPlaying(false)
      })
    }
  }, [profileCustomization])

  const fetchUserProfile = async () => {
    if (!user) return
    
    try {
      // In a real implementation, you would fetch this from an API
      setUserProfile({
        id: user.id,
        email: user.email,
        name: user.name || '',
        avatar: user.avatar,
        bio: user.bio || '',
        role: user.role,
        rank: user.rank,
        level: user.level,
        experience: user.experience,
        credits: user.credits,
        showLocation: user.showLocation ?? true,
        createdAt: user.createdAt,
        updatedAt: user.updatedAt,
      })
      setEditForm({
        name: user.name || '',
        bio: user.bio || '',
      })
    } catch (error) {
      console.error('Error fetching user profile:', error)
    }
  }

  const fetchFeedPosts = async () => {
    if (!user) return
    
    try {
      // In a real implementation, you would fetch this from an API
      const mockPosts: FeedPost[] = [
        {
          id: '1',
          content: 'Just completed the Dragon Slayer quest! It was challenging but so rewarding!',
          type: 'QUEST_COMPLETION',
          createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
          user: {
            id: user.id,
            name: user.name || 'User',
            avatar: user.avatar,
          },
          likes: 15,
          comments: 3,
          isLiked: false,
        },
        {
          id: '2',
          content: 'Reached level 20! Thanks to everyone who helped me along the way.',
          type: 'ACHIEVEMENT',
          createdAt: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(),
          user: {
            id: user.id,
            name: user.name || 'User',
            avatar: user.avatar,
          },
          likes: 23,
          comments: 8,
          isLiked: true,
        },
        {
          id: '3',
          content: 'Just bought a new magic sword from the guild shop. Can\'t wait to try it out!',
          type: 'SHOP_PURCHASE',
          createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
          user: {
            id: user.id,
            name: user.name || 'User',
            avatar: user.avatar,
          },
          likes: 8,
          comments: 2,
          isLiked: false,
        },
      ]
      setFeedPosts(mockPosts)
    } catch (error) {
      console.error('Error fetching feed posts:', error)
    }
  }

  const fetchUserStats = async () => {
    if (!user) return
    
    try {
      // In a real implementation, you would fetch this from an API
      setUserStats({
        totalQuests: 15,
        completedQuests: 12,
        totalPurchases: 8,
        friendsCount: 24,
        totalPosts: 23,
      })
    } catch (error) {
      console.error('Error fetching user stats:', error)
    }
  }

  const fetchProfileCustomization = async () => {
    if (!user) return
    
    try {
      const token = localStorage.getItem('adventure_guild_token')
      if (!token) return

      const response = await fetch(`/api/users/${user.id}/customization`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        const data = await response.json()
        setProfileCustomization(data.customization || null)
      }
    } catch (error) {
      console.error('Error fetching profile customization:', error)
    }
  }

  const handleSaveProfile = async () => {
    if (!user) return
    
    try {
      // In a real implementation, you would save this to an API
      updateUser({
        name: editForm.name,
        bio: editForm.bio,
      })
      setIsEditing(false)
      fetchUserProfile()
    } catch (error) {
      console.error('Error saving profile:', error)
    }
  }

  const handleCreatePost = async () => {
    if (!newPost.trim()) return
    
    try {
      // In a real implementation, you would create this via an API
      const newPostObj: FeedPost = {
        id: Date.now().toString(),
        content: newPost,
        type: 'STATUS',
        createdAt: new Date().toISOString(),
        user: {
          id: user!.id,
          name: user!.name || 'User',
          avatar: user!.avatar,
        },
        likes: 0,
        comments: 0,
        isLiked: false,
      }
      
      setFeedPosts([newPostObj, ...feedPosts])
      setNewPost('')
    } catch (error) {
      console.error('Error creating post:', error)
    }
  }

  const handleLikePost = (postId: string) => {
    setFeedPosts(posts =>
      posts.map(post =>
        post.id === postId
          ? {
              ...post,
              likes: post.isLiked ? post.likes - 1 : post.likes + 1,
              isLiked: !post.isLiked,
            }
          : post
      )
    )
  }

  const getPostTypeIcon = (type: string) => {
    switch (type) {
      case 'QUEST_COMPLETION':
        return <Target className="h-4 w-4" />
      case 'ACHIEVEMENT':
        return <Award className="h-4 w-4" />
      case 'SHOP_PURCHASE':
        return <ShoppingCart className="h-4 w-4" />
      default:
        return <MessageCircle className="h-4 w-4" />
    }
  }

  const getPostTypeColor = (type: string) => {
    switch (type) {
      case 'QUEST_COMPLETION':
        return 'text-green-600'
      case 'ACHIEVEMENT':
        return 'text-yellow-600'
      case 'SHOP_PURCHASE':
        return 'text-blue-600'
      default:
        return 'text-gray-600'
    }
  }

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000)
    
    if (diffInSeconds < 60) return 'just now'
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m ago`
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h ago`
    return `${Math.floor(diffInSeconds / 86400)}d ago`
  }

  if (!user) {
    return <div>Please log in to view your profile.</div>
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
      <div className="container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Sidebar - Profile Info */}
          <div className="lg:col-span-1 space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Profile</CardTitle>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setIsEditing(!isEditing)}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex flex-col items-center space-y-4">
                  {/* Profile Avatar or Video */}
                  <div className="relative">
                    {profileCustomization?.profileVideo && profileCustomization.showVideoProfile ? (
                      <div className="relative w-24 h-24 rounded-full overflow-hidden">
                        <video 
                          ref={videoRef}
                          src={profileCustomization.profileVideo}
                          className="w-full h-full object-cover"
                          controls={false}
                          muted
                          loop
                          onPlay={() => setVideoPlaying(true)}
                          onPause={() => setVideoPlaying(false)}
                          onLoadedData={() => {
                            console.log('Video loaded successfully')
                            // Try to autoplay when video is loaded
                            if (profileCustomization?.showVideoProfile && videoRef.current) {
                              videoRef.current.play().then(() => {
                                setVideoPlaying(true)
                                console.log('Video autoplay successful')
                              }).catch((error) => {
                                console.log('Video autoplay failed:', error)
                                setVideoPlaying(false)
                              })
                            }
                          }}
                          onError={(e) => {
                            console.error('Video loading error:', e)
                          }}
                          onClick={() => {
                            if (videoRef.current) {
                              if (videoPlaying) {
                                videoRef.current.pause()
                              } else {
                                videoRef.current.play().then(() => {
                                  setVideoPlaying(true)
                                }).catch((error) => {
                                  console.error('Video play error:', error)
                                })
                              }
                            }
                          }}
                        />
                        <div className="absolute inset-0 flex items-center justify-center bg-black/30 cursor-pointer">
                          <Button 
                            variant="ghost" 
                            size="sm"
                            className="w-8 h-8 p-0 bg-white/20 hover:bg-white/30"
                            onClick={() => {
                              if (videoRef.current) {
                                if (videoPlaying) {
                                  videoRef.current.pause()
                                } else {
                                  videoRef.current.play()
                                }
                              }
                            }}
                          >
                            {videoPlaying ? (
                              <Pause className="h-4 w-4 text-white" />
                            ) : (
                              <Play className="h-4 w-4 text-white" />
                            )}
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <Avatar className="h-24 w-24">
                        <AvatarImage src={userProfile?.avatar} alt={userProfile?.name} />
                        <AvatarFallback className="text-lg">
                          {userProfile?.name?.charAt(0) || userProfile?.email.charAt(0)}
                        </AvatarFallback>
                      </Avatar>
                    )}
                    {profileCustomization?.profileVideo && (
                      <div className="absolute -bottom-1 -right-1">
                        <Video className="h-4 w-4 text-primary bg-background rounded-full p-0.5" />
                      </div>
                    )}
                  </div>
                  
                  {/* Profile Music Player */}
                  {profileCustomization?.profileSong && profileCustomization.showMusicPlayer && (
                    <div className="w-full p-3 bg-muted/50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="flex-shrink-0">
                          <div className="w-12 h-12 bg-primary/10 rounded flex items-center justify-center">
                            <Music className="h-6 w-6 text-primary" />
                          </div>
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">
                            {profileCustomization.songTitle || "Profile Song"}
                          </p>
                          <p className="text-xs text-muted-foreground truncate">
                            {profileCustomization.songArtist || "Unknown Artist"}
                          </p>
                        </div>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => {
                            if (audioRef.current) {
                              if (musicPlaying) {
                                audioRef.current.pause()
                              } else {
                                audioRef.current.play().catch(console.error)
                              }
                            }
                          }}
                        >
                          {musicPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                        </Button>
                      </div>
                      {/* Hidden audio element */}
                      <audio 
                        ref={audioRef}
                        src={profileCustomization.profileSong}
                        loop
                        onPlay={() => {
                          console.log('Audio started playing')
                          setMusicPlaying(true)
                        }}
                        onPause={() => {
                          console.log('Audio paused')
                          setMusicPlaying(false)
                        }}
                        onEnded={() => {
                          console.log('Audio ended')
                          setMusicPlaying(false)
                        }}
                        onLoadedData={() => {
                          console.log('Audio loaded successfully')
                          // Try to autoplay when audio is loaded
                          if (profileCustomization?.showMusicPlayer && audioRef.current) {
                            const playPromise = audioRef.current.play()
                            if (playPromise !== undefined) {
                              playPromise.then(() => {
                                setMusicPlaying(true)
                                console.log('Audio autoplay successful')
                              }).catch((error) => {
                                console.log('Audio autoplay prevented:', error)
                                setMusicPlaying(false)
                              })
                            }
                          }
                        }}
                        onError={(e) => {
                          console.error('Audio loading error:', e)
                        }}
                      />
                    </div>
                  )}
                  
                  {isEditing ? (
                    <div className="w-full space-y-3">
                      <Input
                        placeholder="Your name"
                        value={editForm.name}
                        onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                      />
                      <Textarea
                        placeholder="Tell us about yourself..."
                        value={editForm.bio}
                        onChange={(e) => setEditForm({ ...editForm, bio: e.target.value })}
                        rows={3}
                      />
                      <div className="flex space-x-2">
                        <Button onClick={handleSaveProfile} size="sm">
                          Save
                        </Button>
                        <Button
                          variant="outline"
                          onClick={() => setIsEditing(false)}
                          size="sm"
                        >
                          Cancel
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center">
                      <h2 className="text-xl font-bold">{userProfile?.name || 'Adventurer'}</h2>
                      <p className="text-sm text-muted-foreground">{userProfile?.email}</p>
                      {userProfile?.bio && (
                        <p className="text-sm mt-2">{userProfile.bio}</p>
                      )}
                    </div>
                  )}
                </div>

                <Separator />

                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Crown className="h-4 w-4 text-yellow-500" />
                      <span className="text-sm">Rank</span>
                    </div>
                    <Badge variant="secondary">{userProfile?.rank}</Badge>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Star className="h-4 w-4 text-yellow-500" />
                      <span className="text-sm">Level</span>
                    </div>
                    <span className="text-sm font-medium">{userProfile?.level}</span>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <TrendingUp className="h-4 w-4 text-blue-500" />
                      <span className="text-sm">Experience</span>
                    </div>
                    <span className="text-sm font-medium">{userProfile?.experience} XP</span>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Coins className="h-4 w-4 text-yellow-500" />
                      <span className="text-sm">Credits</span>
                    </div>
                    <span className="text-sm font-medium">{userProfile?.credits} CC</span>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Calendar className="h-4 w-4 text-gray-500" />
                      <span className="text-sm">Joined</span>
                    </div>
                    <span className="text-sm text-muted-foreground">
                      {userProfile?.createdAt ? new Date(userProfile.createdAt).toLocaleDateString() : ''}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Statistics</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600">{userStats.totalQuests}</div>
                    <div className="text-sm text-muted-foreground">Total Quests</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">{userStats.completedQuests}</div>
                    <div className="text-sm text-muted-foreground">Completed</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-600">{userStats.totalPurchases}</div>
                    <div className="text-sm text-muted-foreground">Purchases</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-pink-600">{userStats.friendsCount}</div>
                    <div className="text-sm text-muted-foreground">Friends</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content - Tabs */}
          <div className="lg:col-span-2">
            <Tabs defaultValue="feed" className="space-y-6">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="feed">Social Feed</TabsTrigger>
                <TabsTrigger value="profile">Profile Details</TabsTrigger>
                <TabsTrigger value="settings">Settings</TabsTrigger>
              </TabsList>

              {/* Social Feed Tab */}
              <TabsContent value="feed" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Social Feed</CardTitle>
                    <CardDescription>
                      Share your adventures and see what your friends are up to
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                <div className="space-y-4">
                  <div className="flex space-x-3">
                    <Avatar className="h-10 w-10">
                      <AvatarImage src={user.avatar} alt={user.name} />
                      <AvatarFallback>{user.name?.charAt(0) || 'U'}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <Textarea
                        placeholder="Share your adventure..."
                        value={newPost}
                        onChange={(e) => setNewPost(e.target.value)}
                        rows={3}
                      />
                      <div className="flex justify-end mt-2">
                        <Button onClick={handleCreatePost} disabled={!newPost.trim()}>
                          Post
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="space-y-4">
              {feedPosts.map((post) => (
                <Card key={post.id}>
                  <CardContent className="pt-6">
                    <div className="space-y-4">
                      <div className="flex items-start space-x-3">
                        <Avatar className="h-10 w-10">
                          <AvatarImage src={post.user.avatar} alt={post.user.name} />
                          <AvatarFallback>{post.user.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="flex items-center space-x-2">
                            <h4 className="font-medium">{post.user.name}</h4>
                            <Badge variant="outline" className="text-xs">
                              {getPostTypeIcon(post.type)}
                              <span className={`ml-1 ${getPostTypeColor(post.type)}`}>
                                {post.type.replace('_', ' ')}
                              </span>
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground">
                            {formatTimeAgo(post.createdAt)}
                          </p>
                        </div>
                      </div>
                      
                      <p className="text-sm">{post.content}</p>
                      
                      {post.imageUrl && (
                        <div className="mt-2">
                          <img
                            src={post.imageUrl}
                            alt="Post attachment"
                            className="rounded-md max-w-full h-auto"
                          />
                        </div>
                      )}
                      
                      <div className="flex items-center space-x-4 pt-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleLikePost(post.id)}
                          className={post.isLiked ? 'text-red-500' : ''}
                        >
                          <Heart className={`h-4 w-4 mr-1 ${post.isLiked ? 'fill-current' : ''}`} />
                          {post.likes}
                        </Button>
                        <Button variant="ghost" size="sm">
                          <MessageCircle className="h-4 w-4 mr-1" />
                          {post.comments}
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Share2 className="h-4 w-4 mr-1" />
                          Share
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Profile Details Tab */}
          <TabsContent value="profile" className="space-y-6">
            <UserProfileTab />
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Settings className="h-5 w-5" />
                  <span>Account Settings</span>
                </CardTitle>
                <CardDescription>
                  Manage your account settings and security
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Password Change Section */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Shield className="h-4 w-4 text-blue-500" />
                      <span className="font-medium">Password & Security</span>
                    </div>
                    <Button 
                      variant="outline" 
                      onClick={() => setShowPasswordChangeModal(true)}
                    >
                      <Key className="h-4 w-4 mr-2" />
                      Change Password
                    </Button>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Update your password regularly to keep your account secure.
                  </p>
                </div>

                <Separator />

                {/* Account Information */}
                <div className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <User className="h-4 w-4 text-gray-500" />
                    <span className="font-medium">Account Information</span>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium text-gray-700">Email</label>
                      <p className="text-sm text-gray-600">{userProfile?.email}</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-700">Account Status</label>
                      <Badge variant="secondary">Active</Badge>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-700">Member Since</label>
                      <p className="text-sm text-gray-600">
                        {userProfile?.createdAt ? new Date(userProfile.createdAt).toLocaleDateString() : ''}
                      </p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-700">Role</label>
                      <Badge variant={userProfile?.role === 'ADMIN' ? 'default' : 'secondary'}>
                        {userProfile?.role}
                      </Badge>
                    </div>
                  </div>
                </div>

                <Separator />

                {/* Privacy Settings */}
                <div className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <MapPin className="h-4 w-4 text-blue-500" />
                    <span className="font-medium">Location Privacy</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium">Show my location on map</p>
                      <p className="text-xs text-muted-foreground">
                        Allow other users to see your location on the Adventure Map
                      </p>
                    </div>
                    <Button
                      variant={userProfile?.showLocation ? "default" : "outline"}
                      size="sm"
                      onClick={() => {
                        if (userProfile) {
                          updateUser({ showLocation: !userProfile.showLocation })
                          setUserProfile({
                            ...userProfile,
                            showLocation: !userProfile.showLocation
                          })
                        }
                      }}
                    >
                      {userProfile?.showLocation ? "Visible" : "Hidden"}
                    </Button>
                  </div>
                </div>

                {passwordChangeError && (
                  <Alert variant="destructive">
                    <AlertDescription>{passwordChangeError}</AlertDescription>
                  </Alert>
                )}

                {passwordChangeSuccess && (
                  <Alert>
                    <AlertDescription>{passwordChangeSuccess}</AlertDescription>
                  </Alert>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
          </div>
        </div>
      </div>

      {/* Password Change Modal */}
      <PasswordChangeModal
        isOpen={showPasswordChangeModal}
        onClose={() => {
          setShowPasswordChangeModal(false)
          setPasswordChangeError('')
          setPasswordChangeSuccess('')
        }}
        isForced={false}
      />
    </div>
  )
}