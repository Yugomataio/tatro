import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin } from '@/lib/auth'

export async function GET(request: NextRequest) {
  try {
    // Check if user is admin
    requireAdmin(request)
    
    const { searchParams } = new URL(request.url)
    const contentType = searchParams.get('type') // 'quests', 'shop', 'posts'
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '10')
    const status = searchParams.get('status') || ''

    const skip = (page - 1) * limit

    let data: any = {}
    let total = 0

    if (contentType === 'quests') {
      const where: any = {}
      if (status) {
        where.status = status
      }

      const quests = await db.quest.findMany({
        where,
        include: {
          creator: {
            select: {
              id: true,
              name: true,
              avatar: true,
            },
          },
          _count: {
            select: {
              participants: true,
              submissions: true,
            },
          },
        },
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
      })

      total = await db.quest.count({ where })
      data = { quests }
    } else if (contentType === 'shop') {
      const shopItems = await db.shopItem.findMany({
        include: {
          creator: {
            select: {
              id: true,
              name: true,
              avatar: true,
            },
          },
          _count: {
            select: {
              purchases: true,
            },
          },
        },
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
      })

      total = await db.shopItem.count({})
      data = { shopItems }
    } else if (contentType === 'posts') {
      const where: any = {}
      if (status) {
        where.type = status
      }

      const posts = await db.feedPost.findMany({
        where,
        include: {
          user: {
            select: {
              id: true,
              name: true,
              avatar: true,
            },
          },
        },
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
      })

      total = await db.feedPost.count({ where })
      data = { posts }
    } else {
      return NextResponse.json(
        { error: 'Invalid content type' },
        { status: 400 }
      )
    }

    return NextResponse.json({
      ...data,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error('Error fetching admin content:', error)
    return NextResponse.json(
      { error: 'Failed to fetch content' },
      { status: 500 }
    )
  }
}

export async function DELETE(request: NextRequest) {
  try {
    // Check if user is admin
    requireAdmin(request)
    
    const { searchParams } = new URL(request.url)
    const contentType = searchParams.get('type')
    const contentId = searchParams.get('id')

    if (!contentType || !contentId) {
      return NextResponse.json(
        { error: 'Content type and ID are required' },
        { status: 400 }
      )
    }

    if (contentType === 'quests') {
      // Delete quest and related data
      await db.progressSubmission.deleteMany({
        where: { questId: contentId },
      })

      await db.questParticipant.deleteMany({
        where: { questId: contentId },
      })

      await db.quest.delete({
        where: { id: contentId },
      })

      return NextResponse.json({ message: 'Quest deleted successfully' })
    } else if (contentType === 'shop') {
      // Delete shop item and related purchases
      await db.purchase.deleteMany({
        where: { itemId: contentId },
      })

      await db.shopItem.delete({
        where: { id: contentId },
      })

      return NextResponse.json({ message: 'Shop item deleted successfully' })
    } else if (contentType === 'posts') {
      await db.feedPost.delete({
        where: { id: contentId },
      })

      return NextResponse.json({ message: 'Post deleted successfully' })
    } else {
      return NextResponse.json(
        { error: 'Invalid content type' },
        { status: 400 }
      )
    }
  } catch (error) {
    console.error('Error deleting content:', error)
    return NextResponse.json(
      { error: 'Failed to delete content' },
      { status: 500 }
    )
  }
}