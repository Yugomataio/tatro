import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin } from '@/lib/auth'

export async function DELETE(request: NextRequest) {
  try {
    // Check if user is admin
    requireAdmin(request)
    
    const { searchParams } = new URL(request.url)
    const contentType = searchParams.get('type')
    const contentId = searchParams.get('id')
    const reason = searchParams.get('reason') || ''

    if (!contentType || !contentId) {
      return NextResponse.json(
        { error: 'Content type and ID are required' },
        { status: 400 }
      )
    }

    let result
    let message = ''

    switch (contentType) {
      case 'quest':
        // Delete quest and related data
        await db.$transaction(async (tx) => {
          // Delete quest participations
          await tx.questParticipant.deleteMany({
            where: { questId: contentId },
          })

          // Delete progress submissions
          await tx.progressSubmission.deleteMany({
            where: { questId: contentId },
          })

          // Delete the quest
          await tx.quest.delete({
            where: { id: contentId },
          })
        })
        message = 'Quest deleted successfully'
        break

      case 'shop-item':
        // Delete shop item and related purchases
        await db.$transaction(async (tx) => {
          // Delete purchases
          await tx.purchase.deleteMany({
            where: { itemId: contentId },
          })

          // Delete the shop item
          await tx.shopItem.delete({
            where: { id: contentId },
          })
        })
        message = 'Shop item deleted successfully'
        break

      case 'feed-post':
        // Delete feed post
        await db.feedPost.delete({
          where: { id: contentId },
        })
        message = 'Feed post deleted successfully'
        break

      case 'progress-submission':
        // Delete progress submission
        await tx.progressSubmission.delete({
          where: { id: contentId },
        })
        message = 'Progress submission deleted successfully'
        break

      default:
        return NextResponse.json(
          { error: 'Invalid content type' },
          { status: 400 }
        )
    }

    // Log the moderation action (you could create a moderation log table)
    console.log(`Content moderation: ${contentType} ${contentId} removed. Reason: ${reason}`)

    return NextResponse.json({ message })
  } catch (error) {
    console.error('Error moderating content:', error)
    return NextResponse.json(
      { error: 'Failed to moderate content' },
      { status: 500 }
    )
  }
}