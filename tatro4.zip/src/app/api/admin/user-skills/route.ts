import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin } from '@/lib/auth'
import { z } from 'zod'

const addUserSkillSchema = z.object({
  skillId: z.string(),
  level: z.number().min(1).default(1),
  experience: z.number().min(0).default(0),
})

const updateUserSkillSchema = z.object({
  level: z.number().min(1).optional(),
  experience: z.number().min(0).optional(),
})

export async function GET(request: NextRequest) {
  try {
    // Check if user is admin
    requireAdmin(request)
    
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      )
    }

    const userSkills = await db.userSkill.findMany({
      where: { userId },
      include: {
        skill: {
          select: {
            id: true,
            name: true,
            description: true,
            category: true,
          },
        },
      },
      orderBy: { level: 'desc' },
    })

    return NextResponse.json({ userSkills })
  } catch (error) {
    console.error('Error fetching user skills:', error)
    return NextResponse.json(
      { error: 'Failed to fetch user skills' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    // Check if user is admin
    requireAdmin(request)
    
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const body = await request.json()
    const validatedData = addUserSkillSchema.parse(body)

    if (!userId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      )
    }

    // Check if user and skill exist
    const [user, skill] = await Promise.all([
      db.user.findUnique({
        where: { id: userId },
      }),
      db.skill.findUnique({
        where: { id: validatedData.skillId },
      }),
    ])

    if (!user || !skill) {
      return NextResponse.json(
        { error: 'User or skill not found' },
        { status: 404 }
      )
    }

    // Check if user already has this skill
    const existingUserSkill = await db.userSkill.findUnique({
      where: {
        userId_skillId: {
          userId,
          skillId: validatedData.skillId,
        },
      },
    })

    if (existingUserSkill) {
      return NextResponse.json(
        { error: 'User already has this skill' },
        { status: 400 }
      )
    }

    const userSkill = await db.userSkill.create({
      data: {
        userId,
        skillId: validatedData.skillId,
        level: validatedData.level,
        experience: validatedData.experience,
      },
      include: {
        skill: {
          select: {
            id: true,
            name: true,
            description: true,
            category: true,
          },
        },
      },
    })

    return NextResponse.json(userSkill, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Validation failed', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Error adding user skill:', error)
    return NextResponse.json(
      { error: 'Failed to add user skill' },
      { status: 500 }
    )
  }
}

export async function PUT(request: NextRequest) {
  try {
    // Check if user is admin
    requireAdmin(request)
    
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const skillId = searchParams.get('skillId')
    const body = await request.json()
    const validatedData = updateUserSkillSchema.parse(body)

    if (!userId || !skillId) {
      return NextResponse.json(
        { error: 'User ID and Skill ID are required' },
        { status: 400 }
      )
    }

    // Check if user skill exists
    const existingUserSkill = await db.userSkill.findUnique({
      where: {
        userId_skillId: {
          userId,
          skillId,
        },
      },
    })

    if (!existingUserSkill) {
      return NextResponse.json(
        { error: 'User skill not found' },
        { status: 404 }
      )
    }

    const userSkill = await db.userSkill.update({
      where: {
        userId_skillId: {
          userId,
          skillId,
        },
      },
      data: validatedData,
      include: {
        skill: {
          select: {
            id: true,
            name: true,
            description: true,
            category: true,
          },
        },
      },
    })

    return NextResponse.json(userSkill)
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Validation failed', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Error updating user skill:', error)
    return NextResponse.json(
      { error: 'Failed to update user skill' },
      { status: 500 }
    )
  }
}

export async function DELETE(request: NextRequest) {
  try {
    // Check if user is admin
    requireAdmin(request)
    
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const skillId = searchParams.get('skillId')

    if (!userId || !skillId) {
      return NextResponse.json(
        { error: 'User ID and Skill ID are required' },
        { status: 400 }
      )
    }

    // Check if user skill exists
    const existingUserSkill = await db.userSkill.findUnique({
      where: {
        userId_skillId: {
          userId,
          skillId,
        },
      },
    })

    if (!existingUserSkill) {
      return NextResponse.json(
        { error: 'User skill not found' },
        { status: 404 }
      )
    }

    await db.userSkill.delete({
      where: {
        userId_skillId: {
          userId,
          skillId,
        },
      },
    })

    return NextResponse.json({ message: 'User skill removed successfully' })
  } catch (error) {
    console.error('Error removing user skill:', error)
    return NextResponse.json(
      { error: 'Failed to remove user skill' },
      { status: 500 }
    )
  }
}