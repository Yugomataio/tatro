import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/admin/payment-settings - Retrieve payment settings
export async function GET(request: NextRequest) {
  try {
    const authHeader = request.headers.get('authorization')
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json({ error: 'No valid token provided' }, { status: 401 })
    }

    const token = authHeader.substring(7)
    
    // Get user data from the request to verify admin role
    const userHeader = request.headers.get('x-user-data')
    if (!userHeader) {
      return NextResponse.json({ error: 'User data not provided' }, { status: 400 })
    }

    let userData
    try {
      userData = JSON.parse(userHeader)
    } catch (error) {
      return NextResponse.json({ error: 'Invalid user data' }, { status: 400 })
    }

    if (userData.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Unauthorized: Admin access required' }, { status: 403 })
    }

    // Get payment settings from database
    let paymentSettings = await db.paymentSettings.findFirst()
    
    // If no settings exist, create default ones
    if (!paymentSettings) {
      paymentSettings = await db.paymentSettings.create({
        data: {
          routingNumber: '',
          accountNumber: '',
          accountHolderName: '',
          bankName: '',
          isActive: false,
        }
      })
    }

    return NextResponse.json({ paymentSettings })
  } catch (error) {
    console.error('Error fetching payment settings:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

// POST /api/admin/payment-settings - Update payment settings
export async function POST(request: NextRequest) {
  try {
    const authHeader = request.headers.get('authorization')
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json({ error: 'No valid token provided' }, { status: 401 })
    }

    const token = authHeader.substring(7)
    
    // Get user data from the request to verify admin role
    const userHeader = request.headers.get('x-user-data')
    if (!userHeader) {
      return NextResponse.json({ error: 'User data not provided' }, { status: 400 })
    }

    let userData
    try {
      userData = JSON.parse(userHeader)
    } catch (error) {
      return NextResponse.json({ error: 'Invalid user data' }, { status: 400 })
    }

    if (userData.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Unauthorized: Admin access required' }, { status: 403 })
    }

    const { routingNumber, accountNumber, accountHolderName, bankName, isActive } = await request.json()

    // Validate required fields
    if (!routingNumber || !accountNumber || !accountHolderName || !bankName) {
      return NextResponse.json({ error: 'All fields are required' }, { status: 400 })
    }

    // Check if payment settings exist
    let existingSettings = await db.paymentSettings.findFirst()
    
    let paymentSettings
    if (existingSettings) {
      // Update existing settings
      paymentSettings = await db.paymentSettings.update({
        where: { id: existingSettings.id },
        data: {
          routingNumber,
          accountNumber,
          accountHolderName,
          bankName,
          isActive: isActive !== undefined ? isActive : existingSettings.isActive,
        }
      })
    } else {
      // Create new settings
      paymentSettings = await db.paymentSettings.create({
        data: {
          routingNumber,
          accountNumber,
          accountHolderName,
          bankName,
          isActive: isActive !== undefined ? isActive : true,
        }
      })
    }

    return NextResponse.json({ paymentSettings })
  } catch (error) {
    console.error('Error updating payment settings:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}