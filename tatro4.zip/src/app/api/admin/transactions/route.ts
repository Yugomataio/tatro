import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/admin/transactions - Get all transactions with pagination and filters
export async function GET(request: NextRequest) {
  try {
    const authHeader = request.headers.get('authorization')
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json({ error: 'No valid token provided' }, { status: 401 })
    }

    const userHeader = request.headers.get('x-user-data')
    if (!userHeader) {
      return NextResponse.json({ error: 'User data not provided' }, { status: 400 })
    }

    let userData
    try {
      userData = JSON.parse(userHeader)
    } catch (error) {
      return NextResponse.json({ error: 'Invalid user data' }, { status: 400 })
    }

    if (userData.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Unauthorized: Admin access required' }, { status: 403 })
    }

    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '10')
    const startDate = searchParams.get('startDate') || ''
    const endDate = searchParams.get('endDate') || ''
    const minAmount = searchParams.get('minAmount') || ''

    const skip = (page - 1) * limit

    // Build where clause for purchases
    const where: any = {}
    
    // Date filtering
    if (startDate || endDate) {
      where.createdAt = {}
      if (startDate) {
        where.createdAt.gte = new Date(startDate)
      }
      if (endDate) {
        where.createdAt.lte = new Date(endDate)
      }
    }

    // Amount filtering
    if (minAmount) {
      where.totalPrice = {
        gte: parseInt(minAmount)
      }
    }

    const [purchases, total] = await Promise.all([
      db.purchase.findMany({
        where,
        include: {
          user: {
            select: {
              id: true,
              name: true,
              email: true,
              avatar: true
            }
          },
          item: {
            select: {
              id: true,
              name: true,
              type: true,
              price: true
            }
          }
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit
      }),
      db.purchase.count({ where })
    ])

    // Calculate revenue statistics
    const stats = await db.purchase.aggregate({
      where,
      _sum: {
        totalPrice: true
      },
      _count: {
        _all: true
      },
      _avg: {
        totalPrice: true
      }
    })

    return NextResponse.json({
      transactions: purchases,
      stats: {
        totalRevenue: stats._sum.totalPrice || 0,
        totalTransactions: stats._count._all,
        averageTransaction: stats._avg.totalPrice || 0
      },
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    })
  } catch (error) {
    console.error('Error fetching transactions:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}