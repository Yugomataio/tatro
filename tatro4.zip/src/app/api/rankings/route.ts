import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { z } from 'zod'

const createRankingSchema = z.object({
  userId: z.string(),
  category: z.string(),
  rank: z.number().min(1),
  score: z.number().min(0),
  period: z.enum(['weekly', 'monthly', 'all_time']),
})

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '10')
    const category = searchParams.get('category') || ''
    const period = searchParams.get('period') || 'all_time'
    const userId = searchParams.get('userId') || ''

    const skip = (page - 1) * limit

    const where: any = { period }
    
    if (category) {
      where.category = category
    }
    
    if (userId) {
      where.userId = userId
    }

    const rankings = await db.ranking.findMany({
      where,
      include: {
        user: {
          select: {
            id: true,
            name: true,
            avatar: true,
            rank: true,
            level: true,
          },
        },
      },
      skip,
      take: limit,
      orderBy: [
        { rank: 'asc' },
        { score: 'desc' },
      ],
    })

    const total = await db.ranking.count({ where })

    return NextResponse.json({
      rankings,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error('Error fetching rankings:', error)
    return NextResponse.json(
      { error: 'Failed to fetch rankings' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const validatedData = createRankingSchema.parse(body)

    // Check if user exists
    const user = await db.user.findUnique({
      where: { id: validatedData.userId },
    })

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      )
    }

    // Check if ranking already exists for this user, category, and period
    const existingRanking = await db.ranking.findUnique({
      where: {
        userId_category_period: {
          userId: validatedData.userId,
          category: validatedData.category,
          period: validatedData.period,
        },
      },
    })

    if (existingRanking) {
      // Update existing ranking
      const ranking = await db.ranking.update({
        where: { id: existingRanking.id },
        data: {
          rank: validatedData.rank,
          score: validatedData.score,
        },
        include: {
          user: {
            select: {
              id: true,
              name: true,
              avatar: true,
              rank: true,
              level: true,
            },
          },
        },
      })

      return NextResponse.json(ranking)
    } else {
      // Create new ranking
      const ranking = await db.ranking.create({
        data: {
          userId: validatedData.userId,
          category: validatedData.category,
          rank: validatedData.rank,
          score: validatedData.score,
          period: validatedData.period,
        },
        include: {
          user: {
            select: {
              id: true,
              name: true,
              avatar: true,
              rank: true,
              level: true,
            },
          },
        },
      })

      return NextResponse.json(ranking, { status: 201 })
    }
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Validation failed', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Error creating/updating ranking:', error)
    return NextResponse.json(
      { error: 'Failed to create/update ranking' },
      { status: 500 }
    )
  }
}