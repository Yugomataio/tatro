import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth } from '@/lib/auth'

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const decoded = requireAuth(request)
    const userId = params.id

    // Users can only view their own quest history or admins can view any user's quest history
    if (decoded.userId !== userId && decoded.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 403 })
    }

    // Check if user exists
    const user = await db.user.findUnique({
      where: { id: userId }
    })

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    // Get user quest history
    const questParticipants = await db.questParticipant.findMany({
      where: { userId },
      include: {
        quest: true
      },
      orderBy: {
        joinedAt: 'desc'
      }
    })

    const questHistory = questParticipants.map(participant => ({
      id: participant.quest.id,
      title: participant.quest.title,
      description: participant.quest.description,
      status: participant.status,
      completedAt: participant.completedAt?.toISOString(),
      difficulty: participant.quest.difficulty,
      reward: participant.quest.reward,
      xpReward: participant.quest.xpReward,
      isHidden: participant.isHidden
    }))

    return NextResponse.json({ questHistory })
  } catch (error) {
    console.error('Error fetching user quest history:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}