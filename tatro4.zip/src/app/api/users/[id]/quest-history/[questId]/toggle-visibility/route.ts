import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth } from '@/lib/auth'

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string, questId: string } }
) {
  try {
    const decoded = requireAuth(request)
    const userId = params.id
    const questId = params.questId

    // Users can only toggle their own quest visibility or admins can toggle any user's quest visibility
    if (decoded.userId !== userId && decoded.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 403 })
    }

    // Check if user exists
    const user = await db.user.findUnique({
      where: { id: userId }
    })

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    // Find the quest participant record
    const questParticipant = await db.questParticipant.findUnique({
      where: {
        userId_questId: {
          userId: userId,
          questId: questId
        }
      }
    })

    if (!questParticipant) {
      return NextResponse.json({ error: 'Quest participation not found' }, { status: 404 })
    }

    // Toggle the isHidden status
    const updatedParticipant = await db.questParticipant.update({
      where: {
        userId_questId: {
          userId: userId,
          questId: questId
        }
      },
      data: {
        isHidden: !questParticipant.isHidden
      }
    })

    return NextResponse.json({ 
      success: true, 
      isHidden: updatedParticipant.isHidden 
    })
  } catch (error) {
    console.error('Error toggling quest visibility:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}