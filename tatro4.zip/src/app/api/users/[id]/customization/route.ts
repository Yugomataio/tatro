import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth } from '@/lib/auth'

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const decoded = requireAuth(request)
    const userId = params.id

    // Users can only view their own customization or admins can view any user's customization
    if (decoded.userId !== userId && decoded.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 403 })
    }

    // Check if user exists
    const user = await db.user.findUnique({
      where: { id: userId }
    })

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    // Get profile customization
    let customization = await db.profileCustomization.findUnique({
      where: { userId }
    })

    // If no customization exists, create a default one
    if (!customization) {
      customization = await db.profileCustomization.create({
        data: {
          userId,
          layoutStyle: 'DEFAULT'
        }
      })
    }

    return NextResponse.json({ customization })
  } catch (error) {
    console.error('Error fetching profile customization:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const decoded = requireAuth(request)
    const userId = params.id
    const { 
      backgroundImage, 
      profileSong, 
      songTitle, 
      songArtist, 
      profileVideo,
      videoTitle,
      themeColor, 
      customCss, 
      layoutStyle,
      fontFamily,
      fontSize,
      textColor,
      backgroundColor,
      showMusicPlayer,
      showVideoProfile,
      animationsEnabled
    } = await request.json()

    // Users can only update their own customization or admins can update any user's customization
    if (decoded.userId !== userId && decoded.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 403 })
    }

    // Check if user exists
    const user = await db.user.findUnique({
      where: { id: userId }
    })

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    // Update or create profile customization
    let customization = await db.profileCustomization.upsert({
      where: { userId },
      update: {
        backgroundImage,
        profileSong,
        songTitle,
        songArtist,
        profileVideo,
        videoTitle,
        themeColor,
        customCss,
        layoutStyle,
        fontFamily,
        fontSize,
        textColor,
        backgroundColor,
        showMusicPlayer,
        showVideoProfile,
        animationsEnabled
      },
      create: {
        userId,
        backgroundImage,
        profileSong,
        songTitle,
        songArtist,
        profileVideo,
        videoTitle,
        themeColor,
        customCss,
        layoutStyle: layoutStyle || 'DEFAULT',
        fontFamily,
        fontSize,
        textColor,
        backgroundColor,
        showMusicPlayer: showMusicPlayer || false,
        showVideoProfile: showVideoProfile || false,
        animationsEnabled: animationsEnabled !== undefined ? animationsEnabled : true
      }
    })

    return NextResponse.json({ customization })
  } catch (error) {
    console.error('Error updating profile customization:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}