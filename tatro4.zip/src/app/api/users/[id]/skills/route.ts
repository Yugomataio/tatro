import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth } from '@/lib/auth'

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const decoded = requireAuth(request)
    const userId = params.id

    // Users can only view their own skills or admins can view any user's skills
    if (decoded.userId !== userId && decoded.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 403 })
    }

    // Check if user exists
    const user = await db.user.findUnique({
      where: { id: userId }
    })

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    // Get user skills
    const skills = await db.userSkill.findMany({
      where: { userId },
      include: {
        skill: true
      },
      orderBy: {
        level: 'desc'
      }
    })

    const formattedSkills = skills.map(userSkill => ({
      id: userSkill.skill.id,
      name: userSkill.skill.name,
      level: userSkill.level,
      description: userSkill.skill.description,
      category: userSkill.skill.category
    }))

    return NextResponse.json({ skills: formattedSkills })
  } catch (error) {
    console.error('Error fetching user skills:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}