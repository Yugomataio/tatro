import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth } from '@/lib/auth'

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const decoded = requireAuth(request)
    const userId = params.id

    // Check if user exists and user is authorized to view this account
    const user = await db.user.findUnique({
      where: { id: userId }
    })

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    // Users can only view their own account info
    if (decoded.userId !== userId && decoded.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 403 })
    }

    // Get account information
    const account = {
      id: user.id,
      accountNumber: `AG-${user.id.substring(0, 8).toUpperCase()}-${user.id.substring(8, 12).toUpperCase()}`,
      email: user.email,
      name: user.name || '',
      bio: user.bio || '',
      location: user.location || '',
      rank: user.rank,
      level: user.level,
      experience: user.experience,
      credits: user.credits,
      createdAt: user.createdAt.toISOString(),
      lastLogin: user.updatedAt.toISOString(), // Using updatedAt as last login for now
      isVerified: true, // Could be enhanced with email verification system
      twoFactorEnabled: false // Could be enhanced with 2FA system
    }

    return NextResponse.json({ account })
  } catch (error) {
    console.error('Error fetching account info:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const decoded = requireAuth(request)
    const userId = params.id
    const { name, bio, location } = await request.json()

    // Users can only update their own account info
    if (decoded.userId !== userId && decoded.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 403 })
    }

    // Check if user exists
    const user = await db.user.findUnique({
      where: { id: userId }
    })

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    // Update user information
    const updatedUser = await db.user.update({
      where: { id: userId },
      data: {
        name: name || user.name,
        bio: bio || user.bio,
        location: location || user.location
      }
    })

    const account = {
      id: updatedUser.id,
      accountNumber: `AG-${updatedUser.id.substring(0, 8).toUpperCase()}-${updatedUser.id.substring(8, 12).toUpperCase()}`,
      email: updatedUser.email,
      name: updatedUser.name || '',
      bio: updatedUser.bio || '',
      location: updatedUser.location || '',
      rank: updatedUser.rank,
      level: updatedUser.level,
      experience: updatedUser.experience,
      credits: updatedUser.credits,
      createdAt: updatedUser.createdAt.toISOString(),
      lastLogin: updatedUser.updatedAt.toISOString(),
      isVerified: true,
      twoFactorEnabled: false
    }

    return NextResponse.json({ account })
  } catch (error) {
    console.error('Error updating account info:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}