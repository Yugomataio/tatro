import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { z } from 'zod'

const createSkillSchema = z.object({
  name: z.string().min(1),
  description: z.string().optional(),
  category: z.string().optional(),
})

const createUserSkillSchema = z.object({
  userId: z.string(),
  skillId: z.string(),
  level: z.number().min(1).default(1),
  experience: z.number().min(0).default(0),
})

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '10')
    const userId = searchParams.get('userId') || ''
    const category = searchParams.get('category') || ''

    const skip = (page - 1) * limit

    if (userId) {
      // Get user's skills
      const where: any = { userId }
      
      const userSkills = await db.userSkill.findMany({
        where,
        include: {
          skill: {
            select: {
              id: true,
              name: true,
              description: true,
              category: true,
            },
          },
        },
        skip,
        take: limit,
        orderBy: { level: 'desc' },
      })

      const total = await db.userSkill.count({ where })

      return NextResponse.json({
        userSkills,
        pagination: {
          page,
          limit,
          total,
          pages: Math.ceil(total / limit),
        },
      })
    } else {
      // Get all skills
      const where: any = {}
      
      if (category) {
        where.category = category
      }

      const skills = await db.skill.findMany({
        where,
        skip,
        take: limit,
        orderBy: { name: 'asc' },
      })

      const total = await db.skill.count({ where })

      return NextResponse.json({
        skills,
        pagination: {
          page,
          limit,
          total,
          pages: Math.ceil(total / limit),
        },
      })
    }
  } catch (error) {
    console.error('Error fetching skills:', error)
    return NextResponse.json(
      { error: 'Failed to fetch skills' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { userId, skillId, ...skillData } = body

    if (userId && skillId) {
      // Create user skill
      const validatedData = createUserSkillSchema.parse(body)

      // Check if user and skill exist
      const [user, skill] = await Promise.all([
        db.user.findUnique({
          where: { id: validatedData.userId },
        }),
        db.skill.findUnique({
          where: { id: validatedData.skillId },
        }),
      ])

      if (!user || !skill) {
        return NextResponse.json(
          { error: 'User or skill not found' },
          { status: 404 }
        )
      }

      // Check if user already has this skill
      const existingUserSkill = await db.userSkill.findUnique({
        where: {
          userId_skillId: {
            userId: validatedData.userId,
            skillId: validatedData.skillId,
          },
        },
      })

      if (existingUserSkill) {
        return NextResponse.json(
          { error: 'User already has this skill' },
          { status: 400 }
        )
      }

      const userSkill = await db.userSkill.create({
        data: {
          userId: validatedData.userId,
          skillId: validatedData.skillId,
          level: validatedData.level,
          experience: validatedData.experience,
        },
        include: {
          skill: {
            select: {
              id: true,
              name: true,
              description: true,
              category: true,
            },
          },
        },
      })

      return NextResponse.json(userSkill, { status: 201 })
    } else {
      // Create new skill
      const validatedData = createSkillSchema.parse(body)

      // Check if skill already exists
      const existingSkill = await db.skill.findUnique({
        where: { name: validatedData.name },
      })

      if (existingSkill) {
        return NextResponse.json(
          { error: 'Skill with this name already exists' },
          { status: 400 }
        )
      }

      const skill = await db.skill.create({
        data: {
          name: validatedData.name,
          description: validatedData.description,
          category: validatedData.category,
        },
      })

      return NextResponse.json(skill, { status: 201 })
    }
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Validation failed', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Error creating skill/user skill:', error)
    return NextResponse.json(
      { error: 'Failed to create skill/user skill' },
      { status: 500 }
    )
  }
}