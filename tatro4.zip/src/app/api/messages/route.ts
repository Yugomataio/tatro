import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { z } from 'zod'

const sendMessageSchema = z.object({
  senderId: z.string(),
  receiverId: z.string(),
  content: z.string().min(1),
})

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const otherUserId = searchParams.get('otherUserId')
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '20')

    if (!userId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      )
    }

    const skip = (page - 1) * limit

    if (otherUserId) {
      // Get conversation between two users
      const messages = await db.message.findMany({
        where: {
          OR: [
            { senderId: userId, receiverId: otherUserId },
            { senderId: otherUserId, receiverId: userId },
          ],
        },
        include: {
          sender: {
            select: {
              id: true,
              name: true,
              avatar: true,
            },
          },
          receiver: {
            select: {
              id: true,
              name: true,
              avatar: true,
            },
          },
        },
        skip,
        take: limit,
        orderBy: { createdAt: 'asc' },
      })

      // Mark messages as read
      await db.message.updateMany({
        where: {
          senderId: otherUserId,
          receiverId: userId,
          read: false,
        },
        data: { read: true },
      })

      const total = await db.message.count({
        where: {
          OR: [
            { senderId: userId, receiverId: otherUserId },
            { senderId: otherUserId, receiverId: userId },
          ],
        },
      })

      return NextResponse.json({
        messages,
        pagination: {
          page,
          limit,
          total,
          pages: Math.ceil(total / limit),
        },
      })
    } else {
      // Get all conversations for the user
      const messages = await db.message.findMany({
        where: {
          OR: [
            { senderId: userId },
            { receiverId: userId },
          ],
        },
        include: {
          sender: {
            select: {
              id: true,
              name: true,
              avatar: true,
            },
          },
          receiver: {
            select: {
              id: true,
              name: true,
              avatar: true,
            },
          },
        },
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
      })

      // Get unique conversations
      const conversations = new Map()
      messages.forEach(message => {
        const otherUserId = message.senderId === userId ? message.receiverId : message.senderId
        const otherUser = message.senderId === userId ? message.receiver : message.sender
        
        if (!conversations.has(otherUserId)) {
          conversations.set(otherUserId, {
            user: otherUser,
            lastMessage: message,
            unreadCount: message.senderId === userId ? 0 : (message.read ? 0 : 1),
          })
        } else {
          const conversation = conversations.get(otherUserId)
          if (message.senderId !== userId && !message.read) {
            conversation.unreadCount += 1
          }
          if (new Date(message.createdAt) > new Date(conversation.lastMessage.createdAt)) {
            conversation.lastMessage = message
          }
        }
      })

      const total = conversations.size

      return NextResponse.json({
        conversations: Array.from(conversations.values()),
        pagination: {
          page,
          limit,
          total,
          pages: Math.ceil(total / limit),
        },
      })
    }
  } catch (error) {
    console.error('Error fetching messages:', error)
    return NextResponse.json(
      { error: 'Failed to fetch messages' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const validatedData = sendMessageSchema.parse(body)

    // Check if users exist
    const [sender, receiver] = await Promise.all([
      db.user.findUnique({
        where: { id: validatedData.senderId },
      }),
      db.user.findUnique({
        where: { id: validatedData.receiverId },
      }),
    ])

    if (!sender || !receiver) {
      return NextResponse.json(
        { error: 'One or both users not found' },
        { status: 404 }
      )
    }

    // Check if users are friends
    const friendship = await db.friendship.findFirst({
      where: {
        OR: [
          { user1Id: validatedData.senderId, user2Id: validatedData.receiverId },
          { user1Id: validatedData.receiverId, user2Id: validatedData.senderId },
        ],
        status: 'ACCEPTED',
      },
    })

    if (!friendship) {
      return NextResponse.json(
        { error: 'Users must be friends to send messages' },
        { status: 403 }
      )
    }

    // Create message
    const message = await db.message.create({
      data: {
        senderId: validatedData.senderId,
        receiverId: validatedData.receiverId,
        content: validatedData.content,
      },
      include: {
        sender: {
          select: {
            id: true,
            name: true,
            avatar: true,
          },
        },
        receiver: {
          select: {
            id: true,
            name: true,
            avatar: true,
          },
        },
      },
    })

    return NextResponse.json(message, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Validation failed', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Error sending message:', error)
    return NextResponse.json(
      { error: 'Failed to send message' },
      { status: 500 }
    )
  }
}