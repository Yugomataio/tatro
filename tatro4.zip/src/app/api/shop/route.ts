import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { z } from 'zod'

const createShopItemSchema = z.object({
  name: z.string().min(1),
  description: z.string().min(1),
  price: z.number().min(0),
  type: z.enum(['TOOLS', 'EQUIPMENT', 'SERVICES', 'EDUCATION', 'TRANSPORTATION', 'HOUSING', 'FOOD', 'MISCELLANEOUS']),
  imageUrl: z.string().optional(),
  stock: z.number().min(-1).default(-1),
  location: z.string().optional(),
  latitude: z.number().optional(),
  longitude: z.number().optional(),
  createdBy: z.string(),
})

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '10')
    const type = searchParams.get('type') || ''
    const search = searchParams.get('search') || ''

    const skip = (page - 1) * limit

    const where: any = {}
    
    if (type) {
      where.type = type
    }
    
    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } },
      ]
    }

    const shopItems = await db.shopItem.findMany({
      where,
      include: {
        creator: {
          select: {
            id: true,
            name: true,
            avatar: true,
          },
        },
        _count: {
          select: {
            purchases: true,
          },
        },
      },
      skip,
      take: limit,
      orderBy: { createdAt: 'desc' },
    })

    const total = await db.shopItem.count({ where })

    return NextResponse.json({
      shopItems,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error('Error fetching shop items:', error)
    return NextResponse.json(
      { error: 'Failed to fetch shop items' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const validatedData = createShopItemSchema.parse(body)

    const shopItem = await db.shopItem.create({
      data: {
        name: validatedData.name,
        description: validatedData.description,
        price: validatedData.price,
        type: validatedData.type,
        imageUrl: validatedData.imageUrl,
        stock: validatedData.stock,
        location: validatedData.location,
        latitude: validatedData.latitude,
        longitude: validatedData.longitude,
        createdBy: validatedData.createdBy,
      },
      include: {
        creator: {
          select: {
            id: true,
            name: true,
            avatar: true,
          },
        },
      },
    })

    return NextResponse.json(shopItem, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Validation failed', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Error creating shop item:', error)
    return NextResponse.json(
      { error: 'Failed to create shop item' },
      { status: 500 }
    )
  }
}