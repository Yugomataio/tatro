import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { z } from 'zod'

const leavePartySchema = z.object({
  userId: z.string(),
})

export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const body = await request.json()
    const validatedData = leavePartySchema.parse(body)

    // Check if party exists
    const party = await db.party.findUnique({
      where: { id: params.id },
    })

    if (!party) {
      return NextResponse.json(
        { error: 'Party not found' },
        { status: 404 }
      )
    }

    // Check if user is a member
    const member = await db.partyMember.findUnique({
      where: {
        partyId_userId: {
          partyId: params.id,
          userId: validatedData.userId,
        },
      },
    })

    if (!member) {
      return NextResponse.json(
        { error: 'User is not a member of this party' },
        { status: 400 }
      )
    }

    // If user is the leader, check if there are other members
    if (party.leaderId === validatedData.userId) {
      const otherMembers = await db.partyMember.findMany({
        where: {
          partyId: params.id,
          userId: { not: validatedData.userId },
        },
      })

      if (otherMembers.length > 0) {
        return NextResponse.json(
          { error: 'Party leader cannot leave while there are other members. Transfer leadership first.' },
          { status: 400 }
        )
      }
    }

    // Remove user from party
    await db.partyMember.delete({
      where: {
        partyId_userId: {
          partyId: params.id,
          userId: validatedData.userId,
        },
      },
    })

    // If leader left and no members left, disband the party
    if (party.leaderId === validatedData.userId) {
      await db.party.update({
        where: { id: params.id },
        data: { status: 'DISBANDED' },
      })
    }

    return NextResponse.json({ message: 'Successfully left the party' })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Validation failed', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Error leaving party:', error)
    return NextResponse.json(
      { error: 'Failed to leave party' },
      { status: 500 }
    )
  }
}