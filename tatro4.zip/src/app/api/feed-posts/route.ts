import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { z } from 'zod'

const createFeedPostSchema = z.object({
  userId: z.string(),
  content: z.string().min(1),
  imageUrl: z.string().optional(),
})

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '10')
    const userId = searchParams.get('userId') || ''
    const friendsOnly = searchParams.get('friendsOnly') === 'true'

    const skip = (page - 1) * limit

    let where: any = {}
    
    if (userId && friendsOnly) {
      // Get user's friends
      const friendships = await db.friendship.findMany({
        where: {
          OR: [
            { user1Id: userId, status: 'ACCEPTED' },
            { user2Id: userId, status: 'ACCEPTED' },
          ],
        },
      })

      const friendIds = friendships.map(f => 
        f.user1Id === userId ? f.user2Id : f.user1Id
      )

      where.userId = {
        in: [...friendIds, userId], // Include user's own posts
      }
    } else if (userId) {
      where.userId = userId
    }

    const feedPosts = await db.feedPost.findMany({
      where,
      include: {
        user: {
          select: {
            id: true,
            name: true,
            avatar: true,
            rank: true,
            level: true,
          },
        },
      },
      skip,
      take: limit,
      orderBy: { createdAt: 'desc' },
    })

    const total = await db.feedPost.count({ where })

    return NextResponse.json({
      feedPosts,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error('Error fetching feed posts:', error)
    return NextResponse.json(
      { error: 'Failed to fetch feed posts' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const validatedData = createFeedPostSchema.parse(body)

    // Check if user exists
    const user = await db.user.findUnique({
      where: { id: validatedData.userId },
    })

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      )
    }

    const feedPost = await db.feedPost.create({
      data: {
        userId: validatedData.userId,
        content: validatedData.content,
        imageUrl: validatedData.imageUrl,
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            avatar: true,
            rank: true,
            level: true,
          },
        },
      },
    })

    return NextResponse.json(feedPost, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Validation failed', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Error creating feed post:', error)
    return NextResponse.json(
      { error: 'Failed to create feed post' },
      { status: 500 }
    )
  }
}