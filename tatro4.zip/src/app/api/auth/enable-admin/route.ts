import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

const ADMIN_PASSWORD = 'TheCompany24'
const ADMIN_EMAIL = 'yugomatio@yahoo.com'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { password, userData } = body

    if (!password) {
      return NextResponse.json({ error: 'Password is required' }, { status: 400 })
    }

    if (password !== ADMIN_PASSWORD) {
      return NextResponse.json({ error: 'Invalid admin password' }, { status: 401 })
    }

    // Get the token from the Authorization header
    const authHeader = request.headers.get('authorization')
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json({ error: 'No valid token provided' }, { status: 401 })
    }

    const token = authHeader.substring(7)
    
    if (!userData) {
      return NextResponse.json({ error: 'User data not provided' }, { status: 400 })
    }

    // Check if the user's email matches the admin email
    if (userData.email !== ADMIN_EMAIL) {
      return NextResponse.json({ error: 'Unauthorized: Not the designated admin user' }, { status: 403 })
    }

    // Update the user's role to ADMIN in the database
    const updatedUser = await db.user.update({
      where: { id: userData.id },
      data: { role: 'ADMIN' },
    })

    // Return the updated user data
    const userResponse = {
      id: updatedUser.id,
      email: updatedUser.email,
      name: updatedUser.name,
      role: updatedUser.role,
      rank: updatedUser.rank,
      level: updatedUser.level,
      experience: updatedUser.experience,
      credits: updatedUser.credits,
      createdAt: updatedUser.createdAt.toISOString(),
      updatedAt: updatedUser.updatedAt.toISOString(),
    }

    return NextResponse.json({ user: userResponse })
  } catch (error) {
    console.error('Error enabling admin:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}