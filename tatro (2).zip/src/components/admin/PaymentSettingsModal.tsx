'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Switch } from '@/components/ui/switch'
import { CreditCard, Building2, User, DollarSign } from 'lucide-react'
import { useAuth } from '@/contexts/AuthContext'

interface PaymentSettings {
  id: string
  routingNumber: string
  accountNumber: string
  accountHolderName: string
  bankName: string
  isActive: boolean
}

interface PaymentSettingsModalProps {
  isOpen: boolean
  onClose: () => void
}

export default function PaymentSettingsModal({ isOpen, onClose }: PaymentSettingsModalProps) {
  const [paymentSettings, setPaymentSettings] = useState<PaymentSettings>({
    id: '',
    routingNumber: '',
    accountNumber: '',
    accountHolderName: '',
    bankName: '',
    isActive: false,
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const { user } = useAuth()

  useEffect(() => {
    if (isOpen) {
      fetchPaymentSettings()
    }
  }, [isOpen])

  const fetchPaymentSettings = async () => {
    try {
      const token = localStorage.getItem('adventure_guild_token')
      if (!token) return

      const response = await fetch('/api/admin/payment-settings', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'x-user-data': JSON.stringify(user),
        },
      })

      if (response.ok) {
        const data = await response.json()
        setPaymentSettings(data.paymentSettings)
      }
    } catch (error) {
      console.error('Error fetching payment settings:', error)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')
    setSuccess('')

    try {
      const token = localStorage.getItem('adventure_guild_token')
      if (!token) {
        setError('No authentication token found')
        return
      }

      const response = await fetch('/api/admin/payment-settings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
          'x-user-data': JSON.stringify(user),
        },
        body: JSON.stringify(paymentSettings),
      })

      const data = await response.json()

      if (!response.ok) {
        setError(data.error || 'Failed to update payment settings')
        return
      }

      setSuccess('Payment settings updated successfully!')
      setPaymentSettings(data.paymentSettings)
      
      // Close modal after 2 seconds
      setTimeout(() => {
        onClose()
        setSuccess('')
      }, 2000)
    } catch (error) {
      console.error('Error updating payment settings:', error)
      setError('An error occurred while updating payment settings')
    } finally {
      setLoading(false)
    }
  }

  const handleInputChange = (field: keyof PaymentSettings, value: string | boolean) => {
    setPaymentSettings(prev => ({
      ...prev,
      [field]: value
    }))
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <Card className="w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <CreditCard className="h-5 w-5" />
            <span>Payment Settings</span>
          </CardTitle>
          <CardDescription>
            Configure your bank account information to receive payments from CC purchases
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {success && (
              <Alert className="border-green-200 bg-green-50">
                <AlertDescription className="text-green-700">{success}</AlertDescription>
              </Alert>
            )}

            <div className="space-y-2">
              <Label htmlFor="bankName" className="flex items-center space-x-2">
                <Building2 className="h-4 w-4" />
                <span>Bank Name</span>
              </Label>
              <Input
                id="bankName"
                value={paymentSettings.bankName}
                onChange={(e) => handleInputChange('bankName', e.target.value)}
                placeholder="Enter bank name"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="accountHolderName" className="flex items-center space-x-2">
                <User className="h-4 w-4" />
                <span>Account Holder Name</span>
              </Label>
              <Input
                id="accountHolderName"
                value={paymentSettings.accountHolderName}
                onChange={(e) => handleInputChange('accountHolderName', e.target.value)}
                placeholder="Enter account holder name"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="routingNumber" className="flex items-center space-x-2">
                <CreditCard className="h-4 w-4" />
                <span>Routing Number</span>
              </Label>
              <Input
                id="routingNumber"
                value={paymentSettings.routingNumber}
                onChange={(e) => handleInputChange('routingNumber', e.target.value)}
                placeholder="Enter routing number"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="accountNumber" className="flex items-center space-x-2">
                <DollarSign className="h-4 w-4" />
                <span>Account Number</span>
              </Label>
              <Input
                id="accountNumber"
                value={paymentSettings.accountNumber}
                onChange={(e) => handleInputChange('accountNumber', e.target.value)}
                placeholder="Enter account number"
                required
              />
            </div>

            <div className="flex items-center justify-between">
              <Label htmlFor="isActive" className="flex items-center space-x-2">
                <span>Enable Payments</span>
              </Label>
              <Switch
                id="isActive"
                checked={paymentSettings.isActive}
                onCheckedChange={(checked) => handleInputChange('isActive', checked)}
              />
            </div>

            <div className="flex space-x-2">
              <Button type="submit" className="flex-1" disabled={loading}>
                {loading ? 'Saving...' : 'Save Settings'}
              </Button>
              <Button type="button" variant="outline" onClick={onClose}>
                Cancel
              </Button>
            </div>
          </form>

          <div className="mt-6 p-4 bg-blue-50 rounded-lg">
            <h4 className="font-medium text-blue-900 mb-2">Payment Information</h4>
            <ul className="text-sm text-blue-700 space-y-1">
              <li>• All payments from CC purchases will be routed to this account</li>
              <li>• Routing number must be a valid ABA routing number</li>
              <li>• Account number should be your checking or savings account</li>
              <li>• Enable payments only when all information is correct</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}