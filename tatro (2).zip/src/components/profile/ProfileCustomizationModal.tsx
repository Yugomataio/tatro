"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { useToast } from "@/hooks/use-toast"
import { useAuth } from "@/contexts/AuthContext"
import { 
  Upload, 
  Music, 
  Video, 
  Palette, 
  Type, 
  Layout, 
  X,
  Play,
  Pause,
  Download,
  Trash2,
  Plus
} from "lucide-react"

interface ProfileCustomization {
  id: string
  backgroundImage?: string
  profileSong?: string
  songTitle?: string
  songArtist?: string
  profileVideo?: string
  videoTitle?: string
  themeColor?: string
  customCss?: string
  layoutStyle: string // DEFAULT, CREATIVE, MINIMAL, BOLD
  fontFamily?: string
  fontSize?: string
  textColor?: string
  backgroundColor?: string
  showMusicPlayer: boolean
  showVideoProfile: boolean
  animationsEnabled: boolean
}

const colorOptions = [
  { name: "Blue", value: "#3b82f6" },
  { name: "Green", value: "#10b981" },
  { name: "Red", value: "#ef4444" },
  { name: "Purple", value: "#8b5cf6" },
  { name: "Orange", value: "#f97316" },
  { name: "Pink", value: "#ec4899" },
  { name: "Teal", value: "#14b8a6" },
  { name: "Indigo", value: "#6366f1" },
]

const fontOptions = [
  { name: "Inter", value: "Inter, sans-serif" },
  { name: "Roboto", value: "Roboto, sans-serif" },
  { name: "Open Sans", value: "'Open Sans', sans-serif" },
  { name: "Montserrat", value: "Montserrat, sans-serif" },
  { name: "Poppins", value: "Poppins, sans-serif" },
  { name: "Playfair Display", value: "'Playfair Display', serif" },
  { name: "Merriweather", value: "Merriweather, serif" },
  { name: "Source Sans Pro", value: "'Source Sans Pro', sans-serif" },
]

const layoutOptions = [
  { name: "Default", value: "DEFAULT", description: "Standard layout with balanced spacing" },
  { name: "Creative", value: "CREATIVE", description: "Artistic layout with dynamic elements" },
  { name: "Minimal", value: "MINIMAL", description: "Clean and simple design" },
  { name: "Bold", value: "BOLD", description: "Strong visual impact with large elements" },
]

export default function ProfileCustomizationModal({ 
  isOpen, 
  onClose, 
  currentCustomization 
}: { 
  isOpen: boolean; 
  onClose: () => void; 
  currentCustomization: ProfileCustomization | null; 
}) {
  const { user } = useAuth()
  const { toast } = useToast()
  const [customization, setCustomization] = useState<ProfileCustomization>({
    id: "",
    layoutStyle: "DEFAULT",
    showMusicPlayer: false,
    showVideoProfile: false,
    animationsEnabled: true,
    ...currentCustomization
  })
  const [loading, setLoading] = useState(false)
  const [musicPlaying, setMusicPlaying] = useState(false)
  const [videoPlaying, setVideoPlaying] = useState(false)

  useEffect(() => {
    if (currentCustomization) {
      setCustomization({
        id: "",
        layoutStyle: "DEFAULT",
        showMusicPlayer: false,
        showVideoProfile: false,
        animationsEnabled: true,
        ...currentCustomization
      })
    }
  }, [currentCustomization])

  const handleFileUpload = async (file: File, type: 'background' | 'music' | 'video' | 'profile') => {
    const formData = new FormData()
    formData.append('file', file)
    formData.append('type', type)

    try {
      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      })

      if (response.ok) {
        const data = await response.json()
        const url = data.url

        switch (type) {
          case 'background':
            setCustomization(prev => ({ ...prev, backgroundImage: url }))
            break
          case 'music':
            setCustomization(prev => ({ 
              ...prev, 
              profileSong: url,
              showMusicPlayer: true
            }))
            break
          case 'video':
            setCustomization(prev => ({ 
              ...prev, 
              profileVideo: url,
              showVideoProfile: true
            }))
            break
          case 'profile':
            // Update user avatar directly
            if (user) {
              const token = localStorage.getItem('adventure_guild_token')
              const userResponse = await fetch(`/api/users/${user.id}`, {
                method: 'PUT',
                headers: {
                  'Content-Type': 'application/json',
                  'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({ avatar: url })
              })
              
              if (userResponse.ok) {
                // Update the user context or refresh the page
                toast({
                  title: "Profile picture updated",
                  description: "Your profile picture has been updated successfully",
                })
              }
            }
            break
        }

        toast({
          title: "Upload successful",
          description: `${type.charAt(0).toUpperCase() + type.slice(1)} uploaded successfully`,
        })
      } else {
        throw new Error('Upload failed')
      }
    } catch (error) {
      toast({
        title: "Upload failed",
        description: `Failed to upload ${type}`,
        variant: "destructive",
      })
    }
  }

  const saveCustomization = async () => {
    if (!user) return

    setLoading(true)
    try {
      const token = localStorage.getItem('adventure_guild_token')
      const response = await fetch(`/api/users/${user.id}/customization`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(customization)
      })

      if (response.ok) {
        toast({
          title: "Profile updated",
          description: "Your profile customization has been saved",
        })
        onClose()
      } else {
        throw new Error('Failed to save customization')
      }
    } catch (error) {
      toast({
        title: "Save failed",
        description: "Failed to save profile customization",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const removeBackground = () => {
    setCustomization(prev => ({ ...prev, backgroundImage: undefined }))
  }

  const removeMusic = () => {
    setCustomization(prev => ({ 
      ...prev, 
      profileSong: undefined,
      songTitle: undefined,
      songArtist: undefined,
      showMusicPlayer: false
    }))
    setMusicPlaying(false)
  }

  const removeVideo = () => {
    setCustomization(prev => ({ 
      ...prev, 
      profileVideo: undefined,
      videoTitle: undefined,
      showVideoProfile: false
    }))
    setVideoPlaying(false)
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Customize Your Profile</DialogTitle>
          <DialogDescription>
            Personalize your profile with backgrounds, music, videos, and styling options
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="background" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="background">Background</TabsTrigger>
            <TabsTrigger value="media">Media</TabsTrigger>
            <TabsTrigger value="style">Style</TabsTrigger>
            <TabsTrigger value="layout">Layout</TabsTrigger>
          </TabsList>

          <TabsContent value="background" className="space-y-4">
            {/* Profile Picture Section */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Upload className="h-5 w-5" />
                  <span>Profile Picture</span>
                </CardTitle>
                <CardDescription>
                  Upload a custom profile picture
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center space-x-4">
                  <Avatar className="h-20 w-20">
                    <AvatarImage src={user?.avatar} alt={user?.name} />
                    <AvatarFallback className="text-xl">{user?.name?.charAt(0) || 'U'}</AvatarFallback>
                  </Avatar>
                  <div className="space-y-2">
                    <Input
                      type="file"
                      accept="image/*"
                      onChange={(e) => {
                        const file = e.target.files?.[0]
                        if (file) handleFileUpload(file, 'profile')
                      }}
                      className="hidden"
                      id="profile-upload"
                    />
                    <Button asChild>
                      <label htmlFor="profile-upload">Change Profile Picture</label>
                    </Button>
                    <p className="text-sm text-muted-foreground">
                      Recommended: Square image, at least 200x200px
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Upload className="h-5 w-5" />
                  <span>Background Image</span>
                </CardTitle>
                <CardDescription>
                  Upload a custom background image for your profile
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {customization.backgroundImage ? (
                  <div className="space-y-4">
                    <div className="relative">
                      <img 
                        src={customization.backgroundImage} 
                        alt="Profile background"
                        className="w-full h-48 object-cover rounded-lg"
                      />
                      <Button
                        variant="destructive"
                        size="sm"
                        className="absolute top-2 right-2"
                        onClick={removeBackground}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-8 text-center">
                    <Upload className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                    <p className="text-muted-foreground mb-4">
                      Drag and drop your background image here, or click to browse
                    </p>
                    <Input
                      type="file"
                      accept="image/*"
                      onChange={(e) => {
                        const file = e.target.files?.[0]
                        if (file) handleFileUpload(file, 'background')
                      }}
                      className="hidden"
                      id="background-upload"
                    />
                    <Button asChild>
                      <label htmlFor="background-upload">Choose Image</label>
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="media" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Music Section */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Music className="h-5 w-5" />
                    <span>Profile Music</span>
                  </CardTitle>
                  <CardDescription>
                    Add a song that plays on your profile
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {customization.profileSong ? (
                    <div className="space-y-4">
                      <div className="flex items-center space-x-3">
                        <div className="w-12 h-12 bg-primary/10 rounded flex items-center justify-center">
                          <Music className="h-6 w-6 text-primary" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">
                            {customization.songTitle || "Profile Song"}
                          </p>
                          <p className="text-xs text-muted-foreground truncate">
                            {customization.songArtist || "Unknown Artist"}
                          </p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setMusicPlaying(!musicPlaying)}
                          >
                            {musicPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                          </Button>
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={removeMusic}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="song-title">Song Title</Label>
                        <Input
                          id="song-title"
                          value={customization.songTitle || ""}
                          onChange={(e) => setCustomization(prev => ({ 
                            ...prev, 
                            songTitle: e.target.value 
                          }))}
                          placeholder="Enter song title"
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="song-artist">Artist</Label>
                        <Input
                          id="song-artist"
                          value={customization.songArtist || ""}
                          onChange={(e) => setCustomization(prev => ({ 
                            ...prev, 
                            songArtist: e.target.value 
                          }))}
                          placeholder="Enter artist name"
                        />
                      </div>
                    </div>
                  ) : (
                    <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-6 text-center">
                      <Music className="h-8 w-8 mx-auto mb-3 text-muted-foreground" />
                      <p className="text-sm text-muted-foreground mb-3">
                        Upload a song for your profile
                      </p>
                      <Input
                        type="file"
                        accept="audio/*"
                        onChange={(e) => {
                          const file = e.target.files?.[0]
                          if (file) handleFileUpload(file, 'music')
                        }}
                        className="hidden"
                        id="music-upload"
                      />
                      <Button asChild size="sm">
                        <label htmlFor="music-upload">Upload Song</label>
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Video Section */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Video className="h-5 w-5" />
                    <span>Profile Video</span>
                  </CardTitle>
                  <CardDescription>
                    Add a video that plays instead of your profile picture
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {customization.profileVideo ? (
                    <div className="space-y-4">
                      <div className="relative">
                        <video 
                          src={customization.profileVideo}
                          className="w-full h-32 object-cover rounded-lg"
                          controls={false}
                          muted
                          loop
                          autoPlay={videoPlaying}
                        />
                        <div className="absolute inset-0 flex items-center justify-center">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setVideoPlaying(!videoPlaying)}
                            className="bg-black/50 hover:bg-black/70 text-white"
                          >
                            {videoPlaying ? <Pause className="h-6 w-6" /> : <Play className="h-6 w-6" />}
                          </Button>
                        </div>
                        <Button
                          variant="destructive"
                          size="sm"
                          className="absolute top-2 right-2"
                          onClick={removeVideo}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="video-title">Video Title</Label>
                        <Input
                          id="video-title"
                          value={customization.videoTitle || ""}
                          onChange={(e) => setCustomization(prev => ({ 
                            ...prev, 
                            videoTitle: e.target.value 
                          }))}
                          placeholder="Enter video title"
                        />
                      </div>
                    </div>
                  ) : (
                    <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-6 text-center">
                      <Video className="h-8 w-8 mx-auto mb-3 text-muted-foreground" />
                      <p className="text-sm text-muted-foreground mb-3">
                        Upload a video for your profile
                      </p>
                      <Input
                        type="file"
                        accept="video/*"
                        onChange={(e) => {
                          const file = e.target.files?.[0]
                          if (file) handleFileUpload(file, 'video')
                        }}
                        className="hidden"
                        id="video-upload"
                      />
                      <Button asChild size="sm">
                        <label htmlFor="video-upload">Upload Video</label>
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="style" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Palette className="h-5 w-5" />
                    <span>Colors</span>
                  </CardTitle>
                  <CardDescription>
                    Customize your profile color scheme
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Theme Color</Label>
                    <div className="grid grid-cols-4 gap-2">
                      {colorOptions.map((color) => (
                        <button
                          key={color.value}
                          className={`w-12 h-12 rounded-lg border-2 ${
                            customization.themeColor === color.value 
                              ? 'border-primary' 
                              : 'border-muted'
                          }`}
                          style={{ backgroundColor: color.value }}
                          onClick={() => setCustomization(prev => ({ 
                            ...prev, 
                            themeColor: color.value 
                          }))}
                          title={color.name}
                        />
                      ))}
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="text-color">Text Color</Label>
                    <Input
                      id="text-color"
                      type="color"
                      value={customization.textColor || "#000000"}
                      onChange={(e) => setCustomization(prev => ({ 
                        ...prev, 
                        textColor: e.target.value 
                      }))}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="bg-color">Background Color</Label>
                    <Input
                      id="bg-color"
                      type="color"
                      value={customization.backgroundColor || "#ffffff"}
                      onChange={(e) => setCustomization(prev => ({ 
                        ...prev, 
                        backgroundColor: e.target.value 
                      }))}
                    />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Type className="h-5 w-5" />
                    <span>Typography</span>
                  </CardTitle>
                  <CardDescription>
                    Choose fonts and text styling
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Font Family</Label>
                    <Select 
                      value={customization.fontFamily || "Inter, sans-serif"}
                      onValueChange={(value) => setCustomization(prev => ({ 
                        ...prev, 
                        fontFamily: value 
                      }))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select font" />
                      </SelectTrigger>
                      <SelectContent>
                        {fontOptions.map((font) => (
                          <SelectItem key={font.value} value={font.value}>
                            {font.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="font-size">Font Size</Label>
                    <Select 
                      value={customization.fontSize || "medium"}
                      onValueChange={(value) => setCustomization(prev => ({ 
                        ...prev, 
                        fontSize: value 
                      }))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select size" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="small">Small</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="large">Large</SelectItem>
                        <SelectItem value="x-large">Extra Large</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="layout" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Layout className="h-5 w-5" />
                  <span>Layout Options</span>
                </CardTitle>
                <CardDescription>
                  Choose how your profile is organized
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {layoutOptions.map((layout) => (
                    <div
                      key={layout.value}
                      className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                        customization.layoutStyle === layout.value
                          ? 'border-primary bg-primary/5'
                          : 'border-muted hover:border-primary/50'
                      }`}
                      onClick={() => setCustomization(prev => ({ 
                        ...prev, 
                        layoutStyle: layout.value 
                      }))}
                    >
                      <h3 className="font-semibold mb-2">{layout.name}</h3>
                      <p className="text-sm text-muted-foreground">{layout.description}</p>
                    </div>
                  ))}
                </div>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Show Music Player</Label>
                      <p className="text-sm text-muted-foreground">
                        Display music player on your profile
                      </p>
                    </div>
                    <Switch
                      checked={customization.showMusicPlayer}
                      onCheckedChange={(checked) => setCustomization(prev => ({ 
                        ...prev, 
                        showMusicPlayer: checked 
                      }))}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Show Video Profile</Label>
                      <p className="text-sm text-muted-foreground">
                        Display video instead of profile picture
                      </p>
                    </div>
                    <Switch
                      checked={customization.showVideoProfile}
                      onCheckedChange={(checked) => setCustomization(prev => ({ 
                        ...prev, 
                        showVideoProfile: checked 
                      }))}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Enable Animations</Label>
                      <p className="text-sm text-muted-foreground">
                        Add smooth animations to your profile
                      </p>
                    </div>
                    <Switch
                      checked={customization.animationsEnabled}
                      onCheckedChange={(checked) => setCustomization(prev => ({ 
                        ...prev, 
                        animationsEnabled: checked 
                      }))}
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="custom-css">Custom CSS</Label>
                  <Textarea
                    id="custom-css"
                    value={customization.customCss || ""}
                    onChange={(e) => setCustomization(prev => ({ 
                      ...prev, 
                      customCss: e.target.value 
                    }))}
                    placeholder="Enter custom CSS for advanced styling..."
                    rows={4}
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="flex justify-end space-x-2 pt-4 border-t">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={saveCustomization} disabled={loading}>
            {loading ? "Saving..." : "Save Changes"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}