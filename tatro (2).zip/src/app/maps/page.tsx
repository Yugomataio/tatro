'use client'

import AdventureMap from '@/components/maps/AdventureMap'

export default function MapsPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
      <div className="container mx-auto px-4 py-6">
        <AdventureMap />
      </div>
    </div>
  )
}