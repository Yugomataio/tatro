import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { z } from 'zod'

const updateShopItemSchema = z.object({
  name: z.string().min(1).optional(),
  description: z.string().min(1).optional(),
  price: z.number().min(0).optional(),
  type: z.enum(['TOOLS', 'EQUIPMENT', 'SERVICES', 'EDUCATION', 'TRANSPORTATION', 'HOUSING', 'FOOD', 'MISCELLANEOUS']).optional(),
  imageUrl: z.string().optional(),
  stock: z.number().min(-1).optional(),
  location: z.string().optional(),
  latitude: z.number().optional(),
  longitude: z.number().optional(),
})

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const shopItem = await db.shopItem.findUnique({
      where: { id: params.id },
      include: {
        creator: {
          select: {
            id: true,
            name: true,
            avatar: true,
          },
        },
        _count: {
          select: {
            purchases: true,
          },
        },
      },
    })

    if (!shopItem) {
      return NextResponse.json(
        { error: 'Shop item not found' },
        { status: 404 }
      )
    }

    return NextResponse.json(shopItem)
  } catch (error) {
    console.error('Error fetching shop item:', error)
    return NextResponse.json(
      { error: 'Failed to fetch shop item' },
      { status: 500 }
    )
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const body = await request.json()
    const validatedData = updateShopItemSchema.parse(body)

    // Check if shop item exists
    const existingItem = await db.shopItem.findUnique({
      where: { id: params.id },
    })

    if (!existingItem) {
      return NextResponse.json(
        { error: 'Shop item not found' },
        { status: 404 }
      )
    }

    // Update shop item
    const shopItem = await db.shopItem.update({
      where: { id: params.id },
      data: validatedData,
      include: {
        creator: {
          select: {
            id: true,
            name: true,
            avatar: true,
          },
        },
      },
    })

    return NextResponse.json(shopItem)
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Validation failed', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Error updating shop item:', error)
    return NextResponse.json(
      { error: 'Failed to update shop item' },
      { status: 500 }
    )
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    // Check if shop item exists
    const existingItem = await db.shopItem.findUnique({
      where: { id: params.id },
    })

    if (!existingItem) {
      return NextResponse.json(
        { error: 'Shop item not found' },
        { status: 404 }
      )
    }

    // Delete shop item
    await db.shopItem.delete({
      where: { id: params.id },
    })

    return NextResponse.json({ message: 'Shop item deleted successfully' })
  } catch (error) {
    console.error('Error deleting shop item:', error)
    return NextResponse.json(
      { error: 'Failed to delete shop item' },
      { status: 500 }
    )
  }
}