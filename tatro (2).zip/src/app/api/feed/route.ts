import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { z } from 'zod'

const createPostSchema = z.object({
  userId: z.string(),
  content: z.string().min(1),
  type: z.enum(['STATUS', 'QUEST_COMPLETION', 'ACHIEVEMENT', 'SHOP_PURCHASE']).default('STATUS'),
  imageUrl: z.string().optional(),
})

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId') // User whose feed to show
    const currentUserId = searchParams.get('currentUserId') // Current user viewing the feed
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '10')
    const type = searchParams.get('type') || ''

    const skip = (page - 1) * limit

    const where: any = {}
    
    if (type) {
      where.type = type
    }

    // If userId is provided, show only that user's posts
    // Otherwise, show posts from user and their friends
    if (userId) {
      where.userId = userId
    } else if (currentUserId) {
      // Get friend IDs
      const friendships = await db.friendship.findMany({
        where: {
          OR: [
            { user1Id: currentUserId },
            { user2Id: currentUserId },
          ],
          status: 'ACCEPTED',
        },
        select: {
          user1Id: true,
          user2Id: true,
        },
      })

      const friendIds = new Set([
        currentUserId,
        ...friendships.map(f => f.user1Id),
        ...friendships.map(f => f.user2Id),
      ])

      where.userId = {
        in: Array.from(friendIds),
      }
    }

    const posts = await db.feedPost.findMany({
      where,
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
            avatar: true,
            rank: true,
            level: true,
          },
        },
      },
      skip,
      take: limit,
      orderBy: { createdAt: 'desc' },
    })

    const total = await db.feedPost.count({ where })

    return NextResponse.json({
      posts,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error('Error fetching feed posts:', error)
    return NextResponse.json(
      { error: 'Failed to fetch feed posts' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { userId, content, type, imageUrl } = createPostSchema.parse(body)

    // Check if user exists
    const user = await db.user.findUnique({
      where: { id: userId },
    })

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      )
    }

    // Create post
    const post = await db.feedPost.create({
      data: {
        userId,
        content,
        type,
        imageUrl,
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
            avatar: true,
            rank: true,
            level: true,
          },
        },
      },
    })

    return NextResponse.json(post, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Validation failed', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Error creating post:', error)
    return NextResponse.json(
      { error: 'Failed to create post' },
      { status: 500 }
    )
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const postId = searchParams.get('postId')
    const userId = searchParams.get('userId')

    if (!postId || !userId) {
      return NextResponse.json(
        { error: 'Post ID and User ID are required' },
        { status: 400 }
      )
    }

    // Check if post exists and user owns it
    const post = await db.feedPost.findUnique({
      where: { id: postId },
    })

    if (!post) {
      return NextResponse.json(
        { error: 'Post not found' },
        { status: 404 }
      )
    }

    if (post.userId !== userId) {
      return NextResponse.json(
        { error: 'User does not own this post' },
        { status: 403 }
      )
    }

    // Delete post
    await db.feedPost.delete({
      where: { id: postId },
    })

    return NextResponse.json({ message: 'Post deleted successfully' })
  } catch (error) {
    console.error('Error deleting post:', error)
    return NextResponse.json(
      { error: 'Failed to delete post' },
      { status: 500 }
    )
  }
}