import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { z } from 'zod'

const buyCreditsSchema = z.object({
  userId: z.string(),
  amount: z.number().min(1),
  paymentMethod: z.string().optional(),
})

const transferCreditsSchema = z.object({
  fromUserId: z.string(),
  toUserId: z.string(),
  amount: z.number().min(1),
  description: z.string().optional(),
})

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      )
    }

    const user = await db.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        name: true,
        credits: true,
      },
    })

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      )
    }

    // Get user's transaction history (purchases)
    const purchases = await db.purchase.findMany({
      where: { userId },
      include: {
        item: {
          select: {
            id: true,
            name: true,
            type: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
      take: 10,
    })

    return NextResponse.json({
      user,
      purchases,
    })
  } catch (error) {
    console.error('Error fetching currency info:', error)
    return NextResponse.json(
      { error: 'Failed to fetch currency info' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { action, ...data } = body

    if (action === 'buy') {
      const validatedData = buyCreditsSchema.parse(data)

      // Check if user exists
      const user = await db.user.findUnique({
        where: { id: validatedData.userId },
      })

      if (!user) {
        return NextResponse.json(
          { error: 'User not found' },
          { status: 404 }
        )
      }

      // Calculate amount with 5% tax
      const taxAmount = Math.floor(validatedData.amount * 0.05)
      const totalAmount = validatedData.amount + taxAmount
      const creditsToAdd = validatedData.amount

      // Update user credits
      const updatedUser = await db.user.update({
        where: { id: validatedData.userId },
        data: {
          credits: {
            increment: creditsToAdd,
          },
        },
        select: {
          id: true,
          name: true,
          credits: true,
        },
      })

      return NextResponse.json({
        user: updatedUser,
        amount: creditsToAdd,
        tax: taxAmount,
        total: totalAmount,
        message: `Successfully purchased ${creditsToAdd} CC`,
      })
    } else if (action === 'transfer') {
      const validatedData = transferCreditsSchema.parse(data)

      // Check if users exist
      const [fromUser, toUser] = await Promise.all([
        db.user.findUnique({
          where: { id: validatedData.fromUserId },
        }),
        db.user.findUnique({
          where: { id: validatedData.toUserId },
        }),
      ])

      if (!fromUser || !toUser) {
        return NextResponse.json(
          { error: 'One or both users not found' },
          { status: 404 }
        )
      }

      // Check if sender has enough credits
      if (fromUser.credits < validatedData.amount) {
        return NextResponse.json(
          { error: 'Insufficient credits' },
          { status: 400 }
        )
      }

      // Perform transfer in a transaction
      const result = await db.$transaction(async (tx) => {
        const updatedFromUser = await tx.user.update({
          where: { id: validatedData.fromUserId },
          data: {
            credits: {
              decrement: validatedData.amount,
            },
          },
        })

        const updatedToUser = await tx.user.update({
          where: { id: validatedData.toUserId },
          data: {
            credits: {
              increment: validatedData.amount,
            },
          },
        })

        return {
          fromUser: updatedFromUser,
          toUser: updatedToUser,
          amount: validatedData.amount,
        }
      })

      return NextResponse.json({
        ...result,
        message: `Successfully transferred ${validatedData.amount} CC`,
      })
    } else {
      return NextResponse.json(
        { error: 'Invalid action' },
        { status: 400 }
      )
    }
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Validation failed', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Error processing currency transaction:', error)
    return NextResponse.json(
      { error: 'Failed to process currency transaction' },
      { status: 500 }
    )
  }
}