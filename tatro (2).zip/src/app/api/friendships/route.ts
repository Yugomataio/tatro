import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { z } from 'zod'

const createFriendshipSchema = z.object({
  user1Id: z.string(),
  user2Id: z.string(),
})

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '10')
    const userId = searchParams.get('userId') || ''
    const status = searchParams.get('status') || ''

    const skip = (page - 1) * limit

    const where: any = {}
    
    if (userId) {
      where.OR = [
        { user1Id: userId },
        { user2Id: userId },
      ]
    }
    
    if (status) {
      where.status = status
    }

    const friendships = await db.friendship.findMany({
      where,
      include: {
        user1: {
          select: {
            id: true,
            name: true,
            avatar: true,
            rank: true,
            level: true,
          },
        },
        user2: {
          select: {
            id: true,
            name: true,
            avatar: true,
            rank: true,
            level: true,
          },
        },
      },
      skip,
      take: limit,
      orderBy: { createdAt: 'desc' },
    })

    const total = await db.friendship.count({ where })

    return NextResponse.json({
      friendships,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error('Error fetching friendships:', error)
    return NextResponse.json(
      { error: 'Failed to fetch friendships' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const validatedData = createFriendshipSchema.parse(body)

    // Check if friendship already exists
    const existingFriendship = await db.friendship.findFirst({
      where: {
        OR: [
          { user1Id: validatedData.user1Id, user2Id: validatedData.user2Id },
          { user1Id: validatedData.user2Id, user2Id: validatedData.user1Id },
        ],
      },
    })

    if (existingFriendship) {
      return NextResponse.json(
        { error: 'Friendship already exists' },
        { status: 400 }
      )
    }

    // Check if users exist
    const [user1, user2] = await Promise.all([
      db.user.findUnique({
        where: { id: validatedData.user1Id },
      }),
      db.user.findUnique({
        where: { id: validatedData.user2Id },
      }),
    ])

    if (!user1 || !user2) {
      return NextResponse.json(
        { error: 'One or both users not found' },
        { status: 404 }
      )
    }

    const friendship = await db.friendship.create({
      data: {
        user1Id: validatedData.user1Id,
        user2Id: validatedData.user2Id,
        status: 'PENDING',
      },
      include: {
        user1: {
          select: {
            id: true,
            name: true,
            avatar: true,
          },
        },
        user2: {
          select: {
            id: true,
            name: true,
            avatar: true,
          },
        },
      },
    })

    return NextResponse.json(friendship, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Validation failed', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Error creating friendship:', error)
    return NextResponse.json(
      { error: 'Failed to create friendship' },
      { status: 500 }
    )
  }
}