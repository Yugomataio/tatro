import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const userId = params.id

    // Check if user exists
    const user = await db.user.findUnique({
      where: { id: userId }
    })

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    // Get user credentials
    const credentials = await db.userCredential.findMany({
      where: { userId },
      include: {
        credential: true
      },
      orderBy: {
        issuedDate: 'desc'
      }
    })

    const formattedCredentials = credentials.map(userCredential => ({
      id: userCredential.credential.id,
      title: userCredential.credential.title,
      description: userCredential.credential.description,
      issuedBy: userCredential.credential.issuedBy,
      issuedDate: userCredential.issuedDate.toISOString(),
      imageUrl: userCredential.credential.imageUrl
    }))

    return NextResponse.json({ credentials: formattedCredentials })
  } catch (error) {
    console.error('Error fetching user credentials:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}