import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const userId = params.id

    // Check if user exists
    const user = await db.user.findUnique({
      where: { id: userId }
    })

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    // Get user abilities
    const abilities = await db.userAbility.findMany({
      where: { userId },
      include: {
        ability: true
      },
      orderBy: {
        discoveredAt: 'desc'
      }
    })

    const formattedAbilities = abilities.map(userAbility => ({
      id: userAbility.ability.id,
      name: userAbility.ability.name,
      description: userAbility.ability.description,
      category: userAbility.ability.category,
      discoveredAt: userAbility.discoveredAt.toISOString(),
      proficiency: userAbility.proficiency || 50 // Default proficiency if not set
    }))

    return NextResponse.json({ abilities: formattedAbilities })
  } catch (error) {
    console.error('Error fetching user abilities:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}