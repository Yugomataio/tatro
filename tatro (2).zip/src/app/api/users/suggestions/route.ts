import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const currentUserId = searchParams.get('currentUserId') || ''
    const limit = parseInt(searchParams.get('limit') || '5')

    if (!currentUserId) {
      return NextResponse.json(
        { error: 'Current user ID is required' },
        { status: 400 }
      )
    }

    // Get users who are not friends with the current user
    const friendIds = await db.friendship.findMany({
      where: {
        OR: [
          { user1Id: currentUserId },
          { user2Id: currentUserId },
        ],
        status: 'ACCEPTED',
      },
      select: {
        user1Id: true,
        user2Id: true,
      },
    })

    const excludedUserIds = new Set([
      currentUserId,
      ...friendIds.map(f => f.user1Id),
      ...friendIds.map(f => f.user2Id),
    ])

    const suggestions = await db.user.findMany({
      where: {
        id: {
          notIn: Array.from(excludedUserIds),
        },
      },
      select: {
        id: true,
        name: true,
        email: true,
        avatar: true,
        rank: true,
        level: true,
        createdAt: true,
      },
      take: limit,
      orderBy: [
        { level: 'desc' },
        { experience: 'desc' },
        { createdAt: 'desc' },
      ],
    })

    return NextResponse.json({ users: suggestions })
  } catch (error) {
    console.error('Error getting user suggestions:', error)
    return NextResponse.json(
      { error: 'Failed to get user suggestions' },
      { status: 500 }
    )
  }
}