import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { z } from 'zod'

const createProgressSubmissionSchema = z.object({
  questId: z.string(),
  userId: z.string(),
  progress: z.number().min(0).max(100),
  description: z.string().optional(),
  evidence: z.string().optional(),
})

const updateProgressSubmissionSchema = z.object({
  status: z.enum(['PENDING', 'APPROVED', 'REJECTED']),
  feedback: z.string().optional(),
  reviewedBy: z.string().optional(),
})

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '10')
    const questId = searchParams.get('questId') || ''
    const userId = searchParams.get('userId') || ''
    const status = searchParams.get('status') || ''

    const skip = (page - 1) * limit

    const where: any = {}
    
    if (questId) {
      where.questId = questId
    }
    
    if (userId) {
      where.userId = userId
    }
    
    if (status) {
      where.status = status
    }

    const submissions = await db.progressSubmission.findMany({
      where,
      include: {
        quest: {
          select: {
            id: true,
            title: true,
            difficulty: true,
            reward: true,
          },
        },
        user: {
          select: {
            id: true,
            name: true,
            avatar: true,
            rank: true,
          },
        },
      },
      skip,
      take: limit,
      orderBy: { createdAt: 'desc' },
    })

    const total = await db.progressSubmission.count({ where })

    return NextResponse.json({
      submissions,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error('Error fetching progress submissions:', error)
    return NextResponse.json(
      { error: 'Failed to fetch progress submissions' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const validatedData = createProgressSubmissionSchema.parse(body)

    // Check if quest and user exist
    const [quest, user] = await Promise.all([
      db.quest.findUnique({
        where: { id: validatedData.questId },
      }),
      db.user.findUnique({
        where: { id: validatedData.userId },
      }),
    ])

    if (!quest || !user) {
      return NextResponse.json(
        { error: 'Quest or user not found' },
        { status: 404 }
      )
    }

    // Check if user is participating in the quest
    const participation = await db.questParticipant.findUnique({
      where: {
        userId_questId: {
          userId: validatedData.userId,
          questId: validatedData.questId,
        },
      },
    })

    if (!participation) {
      return NextResponse.json(
        { error: 'User is not participating in this quest' },
        { status: 400 }
      )
    }

    const submission = await db.progressSubmission.create({
      data: {
        questId: validatedData.questId,
        userId: validatedData.userId,
        progress: validatedData.progress,
        description: validatedData.description,
        evidence: validatedData.evidence,
        status: 'PENDING',
      },
      include: {
        quest: {
          select: {
            id: true,
            title: true,
            difficulty: true,
            reward: true,
          },
        },
        user: {
          select: {
            id: true,
            name: true,
            avatar: true,
            rank: true,
          },
        },
      },
    })

    return NextResponse.json(submission, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Validation failed', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Error creating progress submission:', error)
    return NextResponse.json(
      { error: 'Failed to create progress submission' },
      { status: 500 }
    )
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json()
    const { searchParams } = new URL(request.url)
    const submissionId = searchParams.get('id')

    if (!submissionId) {
      return NextResponse.json(
        { error: 'Submission ID is required' },
        { status: 400 }
      )
    }

    const validatedData = updateProgressSubmissionSchema.parse(body)

    const submission = await db.progressSubmission.update({
      where: { id: submissionId },
      data: {
        status: validatedData.status,
        feedback: validatedData.feedback,
        reviewedBy: validatedData.reviewedBy,
        reviewedAt: new Date(),
      },
      include: {
        quest: {
          select: {
            id: true,
            title: true,
            difficulty: true,
            reward: true,
          },
        },
        user: {
          select: {
            id: true,
            name: true,
            avatar: true,
            rank: true,
          },
        },
      },
    })

    // If approved, update quest status and user rewards
    if (validatedData.status === 'APPROVED') {
      await db.$transaction(async (tx) => {
        // Update quest status if progress is 100%
        if (submission.progress >= 100) {
          await tx.quest.update({
            where: { id: submission.questId },
            data: { status: 'COMPLETED' },
          })
        }

        // Give user experience and credits based on progress
        const experienceReward = Math.floor((submission.quest.reward * submission.progress) / 100)
        const creditsReward = Math.floor((submission.quest.reward * submission.progress) / 100)

        await tx.user.update({
          where: { id: submission.userId },
          data: {
            experience: {
              increment: experienceReward,
            },
            credits: {
              increment: creditsReward,
            },
          },
        })
      })
    }

    return NextResponse.json(submission)
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Validation failed', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Error updating progress submission:', error)
    return NextResponse.json(
      { error: 'Failed to update progress submission' },
      { status: 500 }
    )
  }
}