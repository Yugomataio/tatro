import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { z } from 'zod'

const friendRequestSchema = z.object({
  fromUserId: z.string(),
  toUserId: z.string(),
})

const updateFriendshipSchema = z.object({
  friendshipId: z.string(),
  status: z.enum(['ACCEPTED', 'BLOCKED']),
})

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const status = searchParams.get('status') || 'ACCEPTED'

    if (!userId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      )
    }

    const friendships = await db.friendship.findMany({
      where: {
        OR: [
          { user1Id: userId },
          { user2Id: userId },
        ],
        status: status as any,
      },
      include: {
        user1: {
          select: {
            id: true,
            name: true,
            email: true,
            avatar: true,
            rank: true,
            level: true,
          },
        },
        user2: {
          select: {
            id: true,
            name: true,
            email: true,
            avatar: true,
            rank: true,
            level: true,
          },
        },
      },
      orderBy: { updatedAt: 'desc' },
    })

    // Format friendships to show the other user
    const formattedFriends = friendships.map(friendship => {
      const isUser1 = friendship.user1Id === userId
      const otherUser = isUser1 ? friendship.user2 : friendship.user1
      
      return {
        id: friendship.id,
        user: otherUser,
        status: friendship.status,
        createdAt: friendship.createdAt,
        updatedAt: friendship.updatedAt,
      }
    })

    return NextResponse.json({ friends: formattedFriends })
  } catch (error) {
    console.error('Error fetching friends:', error)
    return NextResponse.json(
      { error: 'Failed to fetch friends' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const action = body.action // 'request' or 'update'

    if (action === 'request') {
      const { fromUserId, toUserId } = friendRequestSchema.parse(body)
      
      // Check if users exist
      const fromUser = await db.user.findUnique({
        where: { id: fromUserId },
      })

      const toUser = await db.user.findUnique({
        where: { id: toUserId },
      })

      if (!fromUser || !toUser) {
        return NextResponse.json(
          { error: 'One or both users not found' },
          { status: 404 }
        )
      }

      // Check if friendship already exists
      const existingFriendship = await db.friendship.findFirst({
        where: {
          OR: [
            { user1Id: fromUserId, user2Id: toUserId },
            { user1Id: toUserId, user2Id: fromUserId },
          ],
        },
      })

      if (existingFriendship) {
        return NextResponse.json(
          { error: 'Friendship already exists or pending' },
          { status: 400 }
        )
      }

      // Create friend request
      const friendship = await db.friendship.create({
        data: {
          user1Id: fromUserId,
          user2Id: toUserId,
          status: 'PENDING',
        },
        include: {
          user1: {
            select: {
              id: true,
              name: true,
              email: true,
              avatar: true,
            },
          },
          user2: {
            select: {
              id: true,
              name: true,
              email: true,
              avatar: true,
            },
          },
        },
      })

      return NextResponse.json(friendship, { status: 201 })
    } else if (action === 'update') {
      const { friendshipId, status } = updateFriendshipSchema.parse(body)
      
      // Get friendship
      const friendship = await db.friendship.findUnique({
        where: { id: friendshipId },
      })

      if (!friendship) {
        return NextResponse.json(
          { error: 'Friendship not found' },
          { status: 404 }
        )
      }

      // Update friendship
      const updatedFriendship = await db.friendship.update({
        where: { id: friendshipId },
        data: {
          status,
          updatedAt: new Date(),
        },
        include: {
          user1: {
            select: {
              id: true,
              name: true,
              email: true,
              avatar: true,
            },
          },
          user2: {
            select: {
              id: true,
              name: true,
              email: true,
              avatar: true,
            },
          },
        },
      })

      return NextResponse.json(updatedFriendship)
    } else {
      return NextResponse.json(
        { error: 'Invalid action' },
        { status: 400 }
      )
    }
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Validation failed', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Error processing friendship request:', error)
    return NextResponse.json(
      { error: 'Failed to process friendship request' },
      { status: 500 }
    )
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const friendshipId = searchParams.get('friendshipId')
    const userId = searchParams.get('userId')

    if (!friendshipId || !userId) {
      return NextResponse.json(
        { error: 'Friendship ID and User ID are required' },
        { status: 400 }
      )
    }

    // Check if friendship exists and user is part of it
    const friendship = await db.friendship.findUnique({
      where: { id: friendshipId },
    })

    if (!friendship) {
      return NextResponse.json(
        { error: 'Friendship not found' },
        { status: 404 }
      )
    }

    if (friendship.user1Id !== userId && friendship.user2Id !== userId) {
      return NextResponse.json(
        { error: 'User is not part of this friendship' },
        { status: 403 }
      )
    }

    // Delete friendship
    await db.friendship.delete({
      where: { id: friendshipId },
    })

    return NextResponse.json({ message: 'Friendship removed successfully' })
  } catch (error) {
    console.error('Error removing friendship:', error)
    return NextResponse.json(
      { error: 'Failed to remove friendship' },
      { status: 500 }
    )
  }
}