import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { z } from 'zod'

const createPurchaseSchema = z.object({
  userId: z.string(),
  itemId: z.string(),
  quantity: z.number().min(1).default(1),
})

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '10')
    const userId = searchParams.get('userId') || ''

    const skip = (page - 1) * limit

    const where: any = {}
    
    if (userId) {
      where.userId = userId
    }

    const purchases = await db.purchase.findMany({
      where,
      include: {
        user: {
          select: {
            id: true,
            name: true,
            avatar: true,
          },
        },
        item: {
          select: {
            id: true,
            name: true,
            price: true,
            type: true,
            imageUrl: true,
          },
        },
      },
      skip,
      take: limit,
      orderBy: { createdAt: 'desc' },
    })

    const total = await db.purchase.count({ where })

    return NextResponse.json({
      purchases,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error('Error fetching purchases:', error)
    return NextResponse.json(
      { error: 'Failed to fetch purchases' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const validatedData = createPurchaseSchema.parse(body)

    // Get the item and user
    const [item, user] = await Promise.all([
      db.shopItem.findUnique({
        where: { id: validatedData.itemId },
      }),
      db.user.findUnique({
        where: { id: validatedData.userId },
      }),
    ])

    if (!item || !user) {
      return NextResponse.json(
        { error: 'Item or user not found' },
        { status: 404 }
      )
    }

    // Check if user has enough credits
    const totalPrice = item.price * validatedData.quantity
    if (user.credits < totalPrice) {
      return NextResponse.json(
        { error: 'Insufficient credits' },
        { status: 400 }
      )
    }

    // Check if item is in stock
    if (item.stock !== -1 && item.stock < validatedData.quantity) {
      return NextResponse.json(
        { error: 'Insufficient stock' },
        { status: 400 }
      )
    }

    // Create purchase and update user credits and item stock in a transaction
    const result = await db.$transaction(async (tx) => {
      const purchase = await tx.purchase.create({
        data: {
          userId: validatedData.userId,
          itemId: validatedData.itemId,
          quantity: validatedData.quantity,
          totalPrice,
        },
        include: {
          user: {
            select: {
              id: true,
              name: true,
              credits: true,
            },
          },
          item: {
            select: {
              id: true,
              name: true,
              price: true,
            },
          },
        },
      })

      // Update user credits
      await tx.user.update({
        where: { id: validatedData.userId },
        data: {
          credits: {
            decrement: totalPrice,
          },
        },
      })

      // Update item stock if not unlimited
      if (item.stock !== -1) {
        await tx.shopItem.update({
          where: { id: validatedData.itemId },
          data: {
            stock: {
              decrement: validatedData.quantity,
            },
          },
        })
      }

      return purchase
    })

    return NextResponse.json(result, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Validation failed', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Error creating purchase:', error)
    return NextResponse.json(
      { error: 'Failed to create purchase' },
      { status: 500 }
    )
  }
}