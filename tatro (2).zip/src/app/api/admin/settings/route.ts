import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin } from '@/lib/auth'
import { z } from 'zod'

const currencySettingsSchema = z.object({
  exchangeRate: z.number().min(0.01),
  taxRate: z.number().min(0).max(1),
  minPurchaseAmount: z.number().min(1),
  maxPurchaseAmount: z.number().min(1),
})

const notificationSettingsSchema = z.object({
  emailNotifications: z.boolean(),
  pushNotifications: z.boolean(),
  questReminders: z.boolean(),
  friendRequests: z.boolean(),
  systemUpdates: z.boolean(),
})

const generalSettingsSchema = z.object({
  siteName: z.string().optional(),
  siteDescription: z.string().optional(),
  maintenanceMode: z.boolean().optional(),
  allowRegistrations: z.boolean().optional(),
})

export async function GET(request: NextRequest) {
  try {
    // Check if user is admin
    requireAdmin(request)
    
    // Get system settings from database
    const settings = await db.systemSettings.findFirst({
      orderBy: { createdAt: 'desc' }
    })

    if (!settings) {
      // Return default settings if none exist
      return NextResponse.json({
        currency: {
          exchangeRate: 1.0,
          taxRate: 0.05,
          minPurchaseAmount: 1,
          maxPurchaseAmount: 10000,
        },
        notifications: {
          emailNotifications: true,
          pushNotifications: true,
          questReminders: true,
          friendRequests: true,
          systemUpdates: true,
        },
        general: {
          siteName: 'Adventure Guild',
          siteDescription: 'A platform for adventurers to connect, quest, and grow',
          maintenanceMode: false,
          allowRegistrations: true,
        }
      })
    }

    return NextResponse.json({
      currency: settings.currencySettings,
      notifications: settings.notificationSettings,
      general: settings.generalSettings,
    })
  } catch (error) {
    console.error('Error fetching system settings:', error)
    return NextResponse.json(
      { error: 'Failed to fetch system settings' },
      { status: 500 }
    )
  }
}

export async function PUT(request: NextRequest) {
  try {
    // Check if user is admin
    requireAdmin(request)
    
    const body = await request.json()
    const { settingType, ...data } = body

    if (!settingType || !['currency', 'notifications', 'general'].includes(settingType)) {
      return NextResponse.json(
        { error: 'Invalid setting type' },
        { status: 400 }
      )
    }

    let validatedData
    switch (settingType) {
      case 'currency':
        validatedData = currencySettingsSchema.parse(data)
        break
      case 'notifications':
        validatedData = notificationSettingsSchema.parse(data)
        break
      case 'general':
        validatedData = generalSettingsSchema.parse(data)
        break
      default:
        return NextResponse.json(
          { error: 'Invalid setting type' },
          { status: 400 }
        )
    }

    // Get current settings
    const currentSettings = await db.systemSettings.findFirst({
      orderBy: { createdAt: 'desc' }
    })

    let updateData: any = {}
    
    switch (settingType) {
      case 'currency':
        updateData = {
          currencySettings: currentSettings ? 
            { ...currentSettings.currencySettings, ...validatedData } : 
            validatedData
        }
        break
      case 'notifications':
        updateData = {
          notificationSettings: currentSettings ? 
            { ...currentSettings.notificationSettings, ...validatedData } : 
            validatedData
        }
        break
      case 'general':
        updateData = {
          generalSettings: currentSettings ? 
            { ...currentSettings.generalSettings, ...validatedData } : 
            validatedData
        }
        break
    }

    // Update or create settings
    const updatedSettings = await db.systemSettings.upsert({
      where: { id: currentSettings?.id || 'default' },
      update: updateData,
      create: {
        id: 'default',
        ...updateData
      }
    })

    return NextResponse.json({
      message: 'Settings updated successfully',
      settings: {
        currency: updatedSettings.currencySettings,
        notifications: updatedSettings.notificationSettings,
        general: updatedSettings.generalSettings,
      }
    })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Validation failed', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Error updating system settings:', error)
    return NextResponse.json(
      { error: 'Failed to update system settings' },
      { status: 500 }
    )
  }
}