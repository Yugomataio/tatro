import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/admin/analytics - Get revenue analytics data
export async function GET(request: NextRequest) {
  try {
    const authHeader = request.headers.get('authorization')
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json({ error: 'No valid token provided' }, { status: 401 })
    }

    const userHeader = request.headers.get('x-user-data')
    if (!userHeader) {
      return NextResponse.json({ error: 'User data not provided' }, { status: 400 })
    }

    let userData
    try {
      userData = JSON.parse(userHeader)
    } catch (error) {
      return NextResponse.json({ error: 'Invalid user data' }, { status: 400 })
    }

    if (userData.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Unauthorized: Admin access required' }, { status: 403 })
    }

    const { searchParams } = new URL(request.url)
    const period = searchParams.get('period') || '30' // Default to 30 days

    const days = parseInt(period)
    const startDate = new Date()
    startDate.setDate(startDate.getDate() - days)

    // Get revenue data by day
    const dailyRevenue = await db.purchase.groupBy({
      by: ['createdAt'],
      where: {
        createdAt: {
          gte: startDate
        }
      },
      _sum: {
        totalPrice: true
      },
      _count: {
        _all: true
      },
      orderBy: {
        createdAt: 'asc'
      }
    })

    // Process daily data for chart
    const chartData = []
    const currentDate = new Date(startDate)
    
    while (currentDate <= new Date()) {
      const dateStr = currentDate.toISOString().split('T')[0]
      const dayData = dailyRevenue.find(d => 
        d.createdAt.toISOString().split('T')[0] === dateStr
      )
      
      chartData.push({
        date: dateStr,
        revenue: dayData?._sum.totalPrice || 0,
        transactions: dayData?._count._all || 0
      })
      
      currentDate.setDate(currentDate.getDate() + 1)
    }

    // Get revenue by item type
    const revenueByType = await db.purchase.groupBy({
      by: ['item'],
      where: {
        createdAt: {
          gte: startDate
        }
      },
      _sum: {
        totalPrice: true
      },
      _count: {
        _all: true
      }
    })

    // Process type data
    const typeData = await Promise.all(
      revenueByType.map(async (data) => {
        const item = await db.shopItem.findUnique({
          where: { id: data.item },
          select: { type: true, name: true }
        })
        return {
          type: item?.type || 'UNKNOWN',
          name: item?.name || 'Unknown',
          revenue: data._sum.totalPrice || 0,
          transactions: data._count._all || 0
        }
      })
    )

    // Group by type
    const groupedByType = typeData.reduce((acc, item) => {
      if (!acc[item.type]) {
        acc[item.type] = {
          type: item.type,
          revenue: 0,
          transactions: 0,
          items: []
        }
      }
      acc[item.type].revenue += item.revenue
      acc[item.type].transactions += item.transactions
      acc[item.type].items.push(item)
      return acc
    }, {} as any)

    const finalTypeData = Object.values(groupedByByType)

    // Get top customers
    const topCustomers = await db.purchase.groupBy({
      by: ['userId'],
      where: {
        createdAt: {
          gte: startDate
        }
      },
      _sum: {
        totalPrice: true
      },
      _count: {
        _all: true
      },
      orderBy: {
        _sum: {
          totalPrice: 'desc'
        }
      },
      take: 10
    })

    const customerData = await Promise.all(
      topCustomers.map(async (data) => {
        const user = await db.user.findUnique({
          where: { id: data.userId },
          select: { name: true, email: true, avatar: true }
        })
        return {
          user: user || { name: 'Unknown', email: 'unknown' },
          totalSpent: data._sum.totalPrice || 0,
          transactionCount: data._count._all || 0
        }
      })
    )

    // Get overall stats
    const overallStats = await db.purchase.aggregate({
      where: {
        createdAt: {
          gte: startDate
        }
      },
      _sum: {
        totalPrice: true
      },
      _count: {
        _all: true
      },
      _avg: {
        totalPrice: true
      }
    })

    // Get previous period stats for comparison
    const previousStartDate = new Date(startDate)
    previousStartDate.setDate(previousStartDate.getDate() - days)
    
    const previousStats = await db.purchase.aggregate({
      where: {
        createdAt: {
          gte: previousStartDate,
          lt: startDate
        }
      },
      _sum: {
        totalPrice: true
      },
      _count: {
        _all: true
      }
    })

    const revenueGrowth = previousStats._sum.totalPrice 
      ? ((overallStats._sum.totalPrice - previousStats._sum.totalPrice) / previousStats._sum.totalPrice) * 100
      : 0

    return NextResponse.json({
      chartData,
      typeData: finalTypeData,
      topCustomers: customerData,
      overallStats: {
        totalRevenue: overallStats._sum.totalPrice || 0,
        totalTransactions: overallStats._count._all || 0,
        averageTransaction: overallStats._avg.totalPrice || 0,
        revenueGrowth: revenueGrowth
      },
      previousStats: {
        totalRevenue: previousStats._sum.totalPrice || 0,
        totalTransactions: previousStats._count._all || 0
      }
    })
  } catch (error) {
    console.error('Error fetching analytics:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}