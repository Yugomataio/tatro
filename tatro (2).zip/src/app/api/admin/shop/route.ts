import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/admin/shop - Get all shop items with pagination and filters
export async function GET(request: NextRequest) {
  try {
    const authHeader = request.headers.get('authorization')
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json({ error: 'No valid token provided' }, { status: 401 })
    }

    const userHeader = request.headers.get('x-user-data')
    if (!userHeader) {
      return NextResponse.json({ error: 'User data not provided' }, { status: 400 })
    }

    let userData
    try {
      userData = JSON.parse(userHeader)
    } catch (error) {
      return NextResponse.json({ error: 'Invalid user data' }, { status: 400 })
    }

    if (userData.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Unauthorized: Admin access required' }, { status: 403 })
    }

    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '10')
    const search = searchParams.get('search') || ''
    const type = searchParams.get('type') || ''

    const skip = (page - 1) * limit

    // Build where clause
    const where: any = {}
    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } }
      ]
    }
    if (type && type !== 'ALL') {
      where.type = type
    }

    const [shopItems, total] = await Promise.all([
      db.shopItem.findMany({
        where,
        include: {
          creator: {
            select: {
              id: true,
              name: true,
              email: true,
              avatar: true
            }
          },
          _count: {
            select: {
              purchases: true
            }
          }
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit
      }),
      db.shopItem.count({ where })
    ])

    return NextResponse.json({
      shopItems,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    })
  } catch (error) {
    console.error('Error fetching shop items:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

// PATCH /api/admin/shop - Update shop item
export async function PATCH(request: NextRequest) {
  try {
    const authHeader = request.headers.get('authorization')
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json({ error: 'No valid token provided' }, { status: 401 })
    }

    const userHeader = request.headers.get('x-user-data')
    if (!userHeader) {
      return NextResponse.json({ error: 'User data not provided' }, { status: 400 })
    }

    let userData
    try {
      userData = JSON.parse(userHeader)
    } catch (error) {
      return NextResponse.json({ error: 'Invalid user data' }, { status: 400 })
    }

    if (userData.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Unauthorized: Admin access required' }, { status: 403 })
    }

    const { itemId, name, description, price, type, stock, location } = await request.json()

    if (!itemId) {
      return NextResponse.json({ error: 'Item ID is required' }, { status: 400 })
    }

    const updateData: any = {}
    if (name) updateData.name = name
    if (description) updateData.description = description
    if (price !== undefined) updateData.price = price
    if (type) updateData.type = type
    if (stock !== undefined) updateData.stock = stock
    if (location !== undefined) updateData.location = location

    const updatedItem = await db.shopItem.update({
      where: { id: itemId },
      data: updateData,
      include: {
        creator: {
          select: {
            id: true,
            name: true,
            email: true
          }
        }
      }
    })

    return NextResponse.json({ shopItem: updatedItem })
  } catch (error) {
    console.error('Error updating shop item:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

// DELETE /api/admin/shop - Delete a shop item
export async function DELETE(request: NextRequest) {
  try {
    const authHeader = request.headers.get('authorization')
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json({ error: 'No valid token provided' }, { status: 401 })
    }

    const userHeader = request.headers.get('x-user-data')
    if (!userHeader) {
      return NextResponse.json({ error: 'User data not provided' }, { status: 400 })
    }

    let userData
    try {
      userData = JSON.parse(userHeader)
    } catch (error) {
      return NextResponse.json({ error: 'Invalid user data' }, { status: 400 })
    }

    if (userData.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Unauthorized: Admin access required' }, { status: 403 })
    }

    const { searchParams } = new URL(request.url)
    const itemId = searchParams.get('itemId')

    if (!itemId) {
      return NextResponse.json({ error: 'Item ID is required' }, { status: 400 })
    }

    await db.shopItem.delete({
      where: { id: itemId }
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting shop item:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}