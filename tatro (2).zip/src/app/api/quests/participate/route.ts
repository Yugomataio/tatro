import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { z } from 'zod'

const participateSchema = z.object({
  questId: z.string(),
  userId: z.string(),
})

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { questId, userId } = participateSchema.parse(body)

    // Check if quest exists and is open
    const quest = await db.quest.findUnique({
      where: { id: questId },
    })

    if (!quest) {
      return NextResponse.json(
        { error: 'Quest not found' },
        { status: 404 }
      )
    }

    if (quest.status !== 'OPEN') {
      return NextResponse.json(
        { error: 'Quest is not open for participation' },
        { status: 400 }
      )
    }

    // Check if user is already participating
    const existingParticipation = await db.questParticipant.findUnique({
      where: {
        userId_questId: {
          userId,
          questId,
        },
      },
    })

    if (existingParticipation) {
      return NextResponse.json(
        { error: 'User is already participating in this quest' },
        { status: 400 }
      )
    }

    // Add participation
    const participation = await db.questParticipant.create({
      data: {
        userId,
        questId,
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            avatar: true,
          },
        },
        quest: {
          select: {
            id: true,
            title: true,
            difficulty: true,
            reward: true,
          },
        },
      },
    })

    // Update quest status if needed
    await db.quest.update({
      where: { id: questId },
      data: { status: 'IN_PROGRESS' },
    })

    return NextResponse.json(participation, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Validation failed', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Error joining quest:', error)
    return NextResponse.json(
      { error: 'Failed to join quest' },
      { status: 500 }
    )
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const questId = searchParams.get('questId')
    const userId = searchParams.get('userId')

    if (!questId || !userId) {
      return NextResponse.json(
        { error: 'Quest ID and User ID are required' },
        { status: 400 }
      )
    }

    // Remove participation
    const participation = await db.questParticipant.delete({
      where: {
        userId_questId: {
          userId,
          questId,
        },
      },
    })

    // Check if quest has any remaining participants
    const remainingParticipants = await db.questParticipant.count({
      where: { questId },
    })

    if (remainingParticipants === 0) {
      await db.quest.update({
        where: { id: questId },
        data: { status: 'OPEN' },
      })
    }

    return NextResponse.json({ message: 'Left quest successfully' })
  } catch (error) {
    console.error('Error leaving quest:', error)
    return NextResponse.json(
      { error: 'Failed to leave quest' },
      { status: 500 }
    )
  }
}