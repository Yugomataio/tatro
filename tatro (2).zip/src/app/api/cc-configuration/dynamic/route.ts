import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { z } from 'zod'

const dynamicUpdateSchema = z.object({
  currentValue: z.number().min(0),
  source: z.string().optional(), // e.g., 'market_data', 'api_feed', 'manual_override'
  metadata: z.object({}).optional(),
})

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const validatedData = dynamicUpdateSchema.parse(body)

    // Get the latest configuration to check if dynamic pricing is enabled
    const latestConfig = await db.cCConfiguration.findFirst({
      orderBy: { createdAt: 'desc' },
    })

    if (!latestConfig) {
      // Create default configuration if none exists
      const config = await db.cCConfiguration.create({
        data: {
          currentValue: validatedData.currentValue,
          dynamicPricing: true, // Enable dynamic pricing by default for dynamic updates
          updatedBy: 'system',
        },
      })
      return NextResponse.json(config, { status: 201 })
    }

    // Only update if dynamic pricing is enabled
    if (!latestConfig.dynamicPricing) {
      return NextResponse.json(
        { error: 'Dynamic pricing is disabled' },
        { status: 400 }
      )
    }

    // Update the configuration with the new dynamic value
    const config = await db.cCConfiguration.update({
      where: { id: latestConfig.id },
      data: {
        currentValue: validatedData.currentValue,
        lastUpdated: new Date(),
        updatedBy: validatedData.source || 'system',
      },
    })

    // Log the dynamic update (optional)
    console.log(`Dynamic CC value updated: ${validatedData.currentValue} from ${validatedData.source}`)

    return NextResponse.json({
      success: true,
      config,
      message: 'Dynamic CC value updated successfully',
    })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Validation failed', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Error updating dynamic CC configuration:', error)
    return NextResponse.json(
      { error: 'Failed to update dynamic CC configuration' },
      { status: 500 }
    )
  }
}

// Endpoint to simulate dynamic pricing updates (for testing)
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const simulate = searchParams.get('simulate')

    if (simulate === 'true') {
      // Get current configuration
      const latestConfig = await db.cCConfiguration.findFirst({
        orderBy: { createdAt: 'desc' },
      })

      if (!latestConfig || !latestConfig.dynamicPricing) {
        return NextResponse.json(
          { error: 'Dynamic pricing not enabled or no configuration found' },
          { status: 400 }
        )
      }

      // Simulate market fluctuation (±5% random change)
      const fluctuation = (Math.random() - 0.5) * 0.1 // -0.05 to +0.05
      const newValue = Math.max(0.01, latestConfig.currentValue * (1 + fluctuation))

      // Update with simulated value
      const updatedConfig = await db.cCConfiguration.update({
        where: { id: latestConfig.id },
        data: {
          currentValue: newValue,
          lastUpdated: new Date(),
          updatedBy: 'simulated_market',
        },
      })

      return NextResponse.json({
        success: true,
        config: updatedConfig,
        previousValue: latestConfig.currentValue,
        newValue: newValue,
        change: newValue - latestConfig.currentValue,
        message: 'Simulated dynamic pricing update completed',
      })
    }

    return NextResponse.json({
      message: 'Dynamic pricing endpoint available. Use ?simulate=true to test.',
    })
  } catch (error) {
    console.error('Error in dynamic pricing endpoint:', error)
    return NextResponse.json(
      { error: 'Failed to process dynamic pricing request' },
      { status: 500 }
    )
  }
}