"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useToast } from "@/hooks/use-toast"
import { 
  Upload, 
  TrendingUp, 
  Clock, 
  CheckCircle, 
  XCircle, 
  MessageSquare,
  ThumbsUp,
  ThumbsDown
} from "lucide-react"

interface QuestProgress {
  id: string
  questId: string
  userId: string
  progress: number
  description?: string
  evidence?: string
  status: 'PENDING' | 'APPROVED' | 'REJECTED'
  createdAt: string
  feedback?: string
  approvedBy?: string
  approvedAt?: string
  user: {
    id: string
    name: string
    avatar?: string
  }
}

interface QuestProgressTrackerProps {
  questId: string
  questTitle: string
  questCreator: string
  currentUserId: string
  maxProgress: number
  isQuestCreator: boolean
  onProgressUpdate?: () => void
}

export default function QuestProgressTracker({ 
  questId, 
  questTitle, 
  questCreator, 
  currentUserId, 
  maxProgress, 
  isQuestCreator,
  onProgressUpdate 
}: QuestProgressTrackerProps) {
  const [submissions, setSubmissions] = useState<QuestProgress[]>([])
  const [loading, setLoading] = useState(true)
  const [showSubmitDialog, setShowSubmitDialog] = useState(false)
  const [showApprovalDialog, setShowApprovalDialog] = useState(false)
  const [selectedSubmission, setSelectedSubmission] = useState<QuestProgress | null>(null)
  const [newProgress, setNewProgress] = useState({
    progress: 0,
    description: '',
    evidence: ''
  })
  const [approvalData, setApprovalData] = useState({
    approved: true,
    feedback: ''
  })
  const [submitting, setSubmitting] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    fetchSubmissions()
  }, [questId])

  const fetchSubmissions = async () => {
    try {
      const token = localStorage.getItem('adventure_guild_token')
      if (!token) return

      const response = await fetch(`/api/quests/submit?questId=${questId}`, {
        headers: { 'Authorization': `Bearer ${token}` }
      })

      if (response.ok) {
        const data = await response.json()
        setSubmissions(data.submissions || [])
      }
    } catch (error) {
      console.error('Error fetching submissions:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmitProgress = async () => {
    setSubmitting(true)
    try {
      const token = localStorage.getItem('adventure_guild_token')
      if (!token) return

      const response = await fetch('/api/quests/submit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          questId,
          userId: currentUserId,
          progress: newProgress.progress,
          description: newProgress.description,
          evidence: newProgress.evidence
        })
      })

      if (response.ok) {
        toast({
          title: "Progress submitted",
          description: "Your progress has been submitted for approval",
        })
        setShowSubmitDialog(false)
        setNewProgress({ progress: 0, description: '', evidence: '' })
        fetchSubmissions()
        onProgressUpdate?.()
      } else {
        const errorData = await response.json()
        toast({
          title: "Submission failed",
          description: errorData.error || "Failed to submit progress",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error('Error submitting progress:', error)
      toast({
        title: "Submission failed",
        description: "Failed to submit progress",
        variant: "destructive",
      })
    } finally {
      setSubmitting(false)
    }
  }

  const handleApproveProgress = async () => {
    setSubmitting(true)
    try {
      const token = localStorage.getItem('adventure_guild_token')
      if (!token) return

      const response = await fetch('/api/quests/submit', {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          submissionId: selectedSubmission!.id,
          approvedBy: currentUserId,
          approved: approvalData.approved,
          feedback: approvalData.feedback
        })
      })

      if (response.ok) {
        toast({
          title: approvalData.approved ? "Progress approved" : "Progress rejected",
          description: approvalData.feedback || "Your decision has been recorded",
        })
        setShowApprovalDialog(false)
        setSelectedSubmission(null)
        setApprovalData({ approved: true, feedback: '' })
        fetchSubmissions()
        onProgressUpdate?.()
      } else {
        const errorData = await response.json()
        toast({
          title: "Action failed",
          description: errorData.error || "Failed to process submission",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error('Error approving progress:', error)
      toast({
        title: "Action failed",
        description: "Failed to process submission",
        variant: "destructive",
      })
    } finally {
      setSubmitting(false)
    }
  }

  const openApprovalDialog = (submission: QuestProgress) => {
    setSelectedSubmission(submission)
    setApprovalData({
      approved: submission.status === 'PENDING',
      feedback: submission.feedback || ''
    })
    setShowApprovalDialog(true)
  }

  const getTotalProgress = () => {
    const approvedSubmissions = submissions.filter(s => s.status === 'APPROVED')
    return approvedSubmissions.reduce((sum, s) => sum + s.progress, 0)
  }

  const getProgressPercentage = () => {
    return Math.min((getTotalProgress() / maxProgress) * 100, 100)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'APPROVED':
        return 'text-green-600 bg-green-50'
      case 'REJECTED':
        return 'text-red-600 bg-red-50'
      default:
        return 'text-yellow-600 bg-yellow-50'
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'APPROVED':
        return <CheckCircle className="h-4 w-4" />
      case 'REJECTED':
        return <XCircle className="h-4 w-4" />
      default:
        return <Clock className="h-4 w-4" />
    }
  }

  if (loading) {
    return <div className="text-center py-4">Loading progress...</div>
  }

  return (
    <div className="space-y-4">
      {/* Progress Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <TrendingUp className="h-5 w-5" />
            <span>Quest Progress</span>
          </CardTitle>
          <CardDescription>
            Track the overall progress of this quest
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span>Total Progress</span>
                <span>{getTotalProgress()} / {maxProgress} ({getProgressPercentage().toFixed(1)}%)</span>
              </div>
              <Progress value={getProgressPercentage()} className="h-2" />
            </div>
            
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">
                {submissions.filter(s => s.status === 'APPROVED').length} approved submissions
              </span>
              {!isQuestCreator && (
                <Button 
                  size="sm" 
                  onClick={() => setShowSubmitDialog(true)}
                >
                  Submit Progress
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Progress Submissions */}
      <Card>
        <CardHeader>
          <CardTitle>Progress Submissions</CardTitle>
          <CardDescription>
            View and manage progress submissions from quest participants
          </CardDescription>
        </CardHeader>
        <CardContent>
          {submissions.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No progress submissions yet
            </div>
          ) : (
            <div className="space-y-4">
              {submissions.map((submission) => (
                <div key={submission.id} className="border rounded-lg p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-3">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={submission.user.avatar} alt={submission.user.name} />
                        <AvatarFallback>{submission.user.name?.charAt(0) || 'U'}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-1">
                          <span className="font-medium">{submission.user.name}</span>
                          <Badge className={getStatusColor(submission.status)}>
                            {getStatusIcon(submission.status)}
                            <span className="ml-1">{submission.status}</span>
                          </Badge>
                        </div>
                        
                        <div className="space-y-2">
                          <div className="flex items-center space-x-4 text-sm">
                            <span>Progress: {submission.progress}%</span>
                            <span>Submitted: {new Date(submission.createdAt).toLocaleDateString()}</span>
                          </div>
                          
                          {submission.description && (
                            <p className="text-sm text-muted-foreground">{submission.description}</p>
                          )}
                          
                          {submission.evidence && (
                            <div className="flex items-center space-x-2">
                              <Upload className="h-4 w-4 text-muted-foreground" />
                              <a 
                                href={submission.evidence} 
                                target="_blank" 
                                rel="noopener noreferrer"
                                className="text-sm text-blue-600 hover:underline"
                              >
                                View Evidence
                              </a>
                            </div>
                          )}
                          
                          {submission.feedback && (
                            <Alert>
                              <MessageSquare className="h-4 w-4" />
                              <AlertDescription>
                                <strong>Feedback:</strong> {submission.feedback}
                              </AlertDescription>
                            </Alert>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    {isQuestCreator && submission.status === 'PENDING' && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => openApprovalDialog(submission)}
                      >
                        Review
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Submit Progress Dialog */}
      <Dialog open={showSubmitDialog} onOpenChange={setShowSubmitDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Submit Progress</DialogTitle>
            <DialogDescription>
              Submit your progress for "{questTitle}"
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="progress">Progress ({newProgress.progress}%)</Label>
              <Input
                id="progress"
                type="range"
                min="0"
                max="100"
                value={newProgress.progress}
                onChange={(e) => setNewProgress(prev => ({ ...prev, progress: parseInt(e.target.value) }))}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>0%</span>
                <span>100%</span>
              </div>
            </div>
            
            <div>
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                placeholder="Describe what you've accomplished..."
                value={newProgress.description}
                onChange={(e) => setNewProgress(prev => ({ ...prev, description: e.target.value }))}
                rows={3}
              />
            </div>
            
            <div>
              <Label htmlFor="evidence">Evidence URL (optional)</Label>
              <Input
                id="evidence"
                placeholder="Link to photos, documents, or other evidence..."
                value={newProgress.evidence}
                onChange={(e) => setNewProgress(prev => ({ ...prev, evidence: e.target.value }))}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowSubmitDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleSubmitProgress} disabled={submitting}>
              {submitting ? "Submitting..." : "Submit Progress"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Approval Dialog */}
      <Dialog open={showApprovalDialog} onOpenChange={setShowApprovalDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Review Progress Submission</DialogTitle>
            <DialogDescription>
              Review the progress submission from {selectedSubmission?.user.name}
            </DialogDescription>
          </DialogHeader>
          {selectedSubmission && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="font-medium">Progress:</span> {selectedSubmission.progress}%
                </div>
                <div>
                  <span className="font-medium">Submitted:</span> {new Date(selectedSubmission.createdAt).toLocaleDateString()}
                </div>
              </div>
              
              {selectedSubmission.description && (
                <div>
                  <Label>Description</Label>
                  <p className="text-sm text-muted-foreground mt-1">{selectedSubmission.description}</p>
                </div>
              )}
              
              {selectedSubmission.evidence && (
                <div>
                  <Label>Evidence</Label>
                  <a 
                    href={selectedSubmission.evidence} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-sm text-blue-600 hover:underline block mt-1"
                  >
                    View Evidence
                  </a>
                </div>
              )}
              
              <div>
                <Label>Decision</Label>
                <div className="flex space-x-2 mt-2">
                  <Button
                    type="button"
                    variant={approvalData.approved ? "default" : "outline"}
                    size="sm"
                    onClick={() => setApprovalData(prev => ({ ...prev, approved: true }))}
                  >
                    <ThumbsUp className="h-4 w-4 mr-1" />
                    Approve
                  </Button>
                  <Button
                    type="button"
                    variant={!approvalData.approved ? "default" : "outline"}
                    size="sm"
                    onClick={() => setApprovalData(prev => ({ ...prev, approved: false }))}
                  >
                    <ThumbsDown className="h-4 w-4 mr-1" />
                    Reject
                  </Button>
                </div>
              </div>
              
              <div>
                <Label htmlFor="feedback">Feedback (optional)</Label>
                <Textarea
                  id="feedback"
                  placeholder="Provide feedback to the participant..."
                  value={approvalData.feedback}
                  onChange={(e) => setApprovalData(prev => ({ ...prev, feedback: e.target.value }))}
                  rows={3}
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowApprovalDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleApproveProgress} disabled={submitting}>
              {submitting ? "Processing..." : approvalData.approved ? "Approve" : "Reject"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}