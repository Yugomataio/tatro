'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Crown, Shield } from 'lucide-react'
import { useAuth } from '@/contexts/AuthContext'

interface AdminEnableModalProps {
  isOpen: boolean
  onClose: () => void
  onSuccess: () => void
}

export default function AdminEnableModal({ isOpen, onClose, onSuccess }: AdminEnableModalProps) {
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const { user } = useAuth()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')

    try {
      const token = localStorage.getItem('adventure_guild_token')
      if (!token) {
        setError('No authentication token found')
        return
      }

      const response = await fetch('/api/auth/enable-admin', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({ 
          password,
          userData: user 
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        setError(data.error || 'Failed to enable admin access')
        return
      }

      // Update user in localStorage
      localStorage.setItem('adventure_guild_user', JSON.stringify(data.user))
      
      // Call success callback
      onSuccess()
      onClose()
    } catch (error) {
      console.error('Error enabling admin:', error)
      setError('An error occurred while enabling admin access')
    } finally {
      setLoading(false)
    }
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4">
            <div className="bg-gradient-to-r from-yellow-400 to-orange-500 p-3 rounded-full">
              <Crown className="h-8 w-8 text-white" />
            </div>
          </div>
          <CardTitle className="text-2xl">Enable Admin Access</CardTitle>
          <CardDescription>
            Enter the admin password to unlock administrative privileges
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="password">Admin Password</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter admin password"
                required
              />
            </div>

            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <div className="flex space-x-2">
              <Button type="submit" className="flex-1" disabled={loading}>
                {loading ? 'Enabling...' : 'Enable Admin'}
              </Button>
              <Button type="button" variant="outline" onClick={onClose}>
                Cancel
              </Button>
            </div>
          </form>

          <div className="mt-6 p-4 bg-blue-50 rounded-lg">
            <div className="flex items-center space-x-2 mb-2">
              <Shield className="h-4 w-4 text-blue-600" />
              <span className="text-sm font-medium text-blue-900">Admin Privileges</span>
            </div>
            <ul className="text-xs text-blue-700 space-y-1">
              <li>• Manage all users and permissions</li>
              <li>• Create and edit quests</li>
              <li>• Manage shop items and inventory</li>
              <li>• View system analytics</li>
              <li>• Access admin dashboard</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}