"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useAuth } from "@/contexts/AuthContext"
import { 
  User, 
  Mail, 
  Calendar, 
  CreditCard, 
  MapPin, 
  Edit,
  Save,
  X,
  Shield,
  Key,
  Activity
} from "lucide-react"

interface AccountInfo {
  id: string
  accountNumber: string
  email: string
  name: string
  bio?: string
  location?: string
  rank: string
  level: number
  experience: number
  credits: number
  createdAt: string
  lastLogin?: string
  isVerified: boolean
  twoFactorEnabled: boolean
}

export default function AccountTab() {
  const { user, updateUser } = useAuth()
  const [accountInfo, setAccountInfo] = useState<AccountInfo | null>(null)
  const [loading, setLoading] = useState(true)
  const [editing, setEditing] = useState(false)
  const [editForm, setEditForm] = useState({
    name: '',
    bio: '',
    location: ''
  })

  useEffect(() => {
    if (user) {
      fetchAccountInfo()
    }
  }, [user])

  const fetchAccountInfo = async () => {
    if (!user) return
    
    try {
      const token = localStorage.getItem('adventure_guild_token')
      if (!token) return

      const headers = {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      }

      const response = await fetch(`/api/users/${user.id}/account`, { headers })
      const data = await response.json()
      setAccountInfo(data.account)
      
      // Initialize edit form
      setEditForm({
        name: data.account.name,
        bio: data.account.bio || '',
        location: data.account.location || ''
      })
    } catch (error) {
      console.error('Error fetching account info:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSave = async () => {
    if (!user || !accountInfo) return

    try {
      const token = localStorage.getItem('adventure_guild_token')
      if (!token) return

      const response = await fetch(`/api/users/${user.id}/account`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(editForm)
      })

      if (response.ok) {
        const data = await response.json()
        setAccountInfo(data.account)
        setEditing(false)
        
        // Update user context
        if (updateUser) {
          updateUser({ 
            name: data.account.name,
            bio: data.account.bio,
            location: data.account.location
          })
        }
      }
    } catch (error) {
      console.error('Error updating account info:', error)
    }
  }

  const handleCancel = () => {
    if (accountInfo) {
      setEditForm({
        name: accountInfo.name,
        bio: accountInfo.bio || '',
        location: accountInfo.location || ''
      })
    }
    setEditing(false)
  }

  const generateAccountNumber = (id: string) => {
    // Generate a formatted account number from user ID
    const cleanId = id.replace(/[^a-zA-Z0-9]/g, '')
    const prefix = 'AG' // Adventure Guild
    const middle = cleanId.substring(0, 8).toUpperCase()
    const suffix = cleanId.substring(8, 12).toUpperCase()
    return `${prefix}-${middle}-${suffix}`
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    )
  }

  if (!accountInfo) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        Unable to load account information.
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Account Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Avatar className="h-16 w-16">
                <AvatarImage src={user?.avatar} alt={user?.name} />
                <AvatarFallback className="text-lg">{user?.name?.charAt(0) || 'U'}</AvatarFallback>
              </Avatar>
              <div>
                <h2 className="text-2xl font-bold">Account Information</h2>
                <p className="text-muted-foreground">Private account details and settings</p>
              </div>
            </div>
            {!editing && (
              <Button onClick={() => setEditing(true)}>
                <Edit className="h-4 w-4 mr-2" />
                Edit Profile
              </Button>
            )}
          </div>
        </CardHeader>
      </Card>

      {/* Account Details */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <User className="h-5 w-5" />
            <span>Account Details</span>
          </CardTitle>
          <CardDescription>Your unique account information</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Account Number */}
          <div className="flex items-center space-x-3">
            <CreditCard className="h-5 w-5 text-muted-foreground" />
            <div className="flex-1">
              <Label className="text-sm font-medium">Account Number</Label>
              <div className="flex items-center space-x-2">
                <code className="bg-muted px-2 py-1 rounded text-sm font-mono">
                  {generateAccountNumber(accountInfo.id)}
                </code>
                <Badge variant="outline" className="text-xs">
                  UNIQUE ID
                </Badge>
              </div>
            </div>
          </div>

          {/* Email */}
          <div className="flex items-center space-x-3">
            <Mail className="h-5 w-5 text-muted-foreground" />
            <div className="flex-1">
              <Label className="text-sm font-medium">Email Address</Label>
              <p className="text-sm">{accountInfo.email}</p>
              {accountInfo.isVerified && (
                <Badge variant="secondary" className="text-xs mt-1">
                  Verified
                </Badge>
              )}
            </div>
          </div>

          {/* Member Since */}
          <div className="flex items-center space-x-3">
            <Calendar className="h-5 w-5 text-muted-foreground" />
            <div className="flex-1">
              <Label className="text-sm font-medium">Member Since</Label>
              <p className="text-sm">{new Date(accountInfo.createdAt).toLocaleDateString()}</p>
            </div>
          </div>

          {/* Last Login */}
          {accountInfo.lastLogin && (
            <div className="flex items-center space-x-3">
              <Activity className="h-5 w-5 text-muted-foreground" />
              <div className="flex-1">
                <Label className="text-sm font-medium">Last Login</Label>
                <p className="text-sm">{new Date(accountInfo.lastLogin).toLocaleString()}</p>
              </div>
            </div>
          )}

          {/* Account Status */}
          <div className="flex items-center space-x-3">
            <Shield className="h-5 w-5 text-muted-foreground" />
            <div className="flex-1">
              <Label className="text-sm font-medium">Security Status</Label>
              <div className="flex items-center space-x-2 mt-1">
                <Badge variant={accountInfo.twoFactorEnabled ? "default" : "secondary"}>
                  2FA {accountInfo.twoFactorEnabled ? "Enabled" : "Disabled"}
                </Badge>
                <Badge variant="outline">
                  {accountInfo.isVerified ? "Verified" : "Unverified"}
                </Badge>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Editable Profile Information */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <User className="h-5 w-5" />
            <span>Profile Information</span>
          </CardTitle>
          <CardDescription>Basic information about you</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {editing ? (
            <div className="space-y-4">
              <div>
                <Label htmlFor="name">Display Name</Label>
                <Input
                  id="name"
                  value={editForm.name}
                  onChange={(e) => setEditForm({...editForm, name: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="bio">Bio</Label>
                <Textarea
                  id="bio"
                  value={editForm.bio}
                  onChange={(e) => setEditForm({...editForm, bio: e.target.value})}
                  placeholder="Tell us about yourself..."
                  rows={3}
                />
              </div>
              <div>
                <Label htmlFor="location">Location</Label>
                <Input
                  id="location"
                  value={editForm.location}
                  onChange={(e) => setEditForm({...editForm, location: e.target.value})}
                  placeholder="Your location"
                />
              </div>
              <div className="flex space-x-2">
                <Button onClick={handleSave}>
                  <Save className="h-4 w-4 mr-2" />
                  Save Changes
                </Button>
                <Button variant="outline" onClick={handleCancel}>
                  <X className="h-4 w-4 mr-2" />
                  Cancel
                </Button>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div>
                <Label className="text-sm font-medium">Display Name</Label>
                <p className="text-sm text-muted-foreground">{accountInfo.name}</p>
              </div>
              <div>
                <Label className="text-sm font-medium">Bio</Label>
                <p className="text-sm text-muted-foreground">
                  {accountInfo.bio || "No bio set"}
                </p>
              </div>
              <div className="flex items-center space-x-3">
                <MapPin className="h-4 w-4 text-muted-foreground" />
                <div>
                  <Label className="text-sm font-medium">Location</Label>
                  <p className="text-sm text-muted-foreground">
                    {accountInfo.location || "No location set"}
                  </p>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Account Statistics */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Activity className="h-5 w-5" />
            <span>Account Statistics</span>
          </CardTitle>
          <CardDescription>Your activity and progress metrics</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-4 border rounded-lg">
              <div className="text-2xl font-bold text-primary">{accountInfo.level}</div>
              <div className="text-sm text-muted-foreground">Level</div>
            </div>
            <div className="text-center p-4 border rounded-lg">
              <div className="text-2xl font-bold text-primary">{accountInfo.experience}</div>
              <div className="text-sm text-muted-foreground">Experience</div>
            </div>
            <div className="text-center p-4 border rounded-lg">
              <div className="text-2xl font-bold text-primary">{accountInfo.credits}</div>
              <div className="text-sm text-muted-foreground">Credits</div>
            </div>
            <div className="text-center p-4 border rounded-lg">
              <div className="text-2xl font-bold text-primary">{accountInfo.rank}</div>
              <div className="text-sm text-muted-foreground">Rank</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}