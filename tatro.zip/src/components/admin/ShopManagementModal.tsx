'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { ShoppingCart, Coins, Map, Edit, Trash2, Search, Package } from 'lucide-react'
import { useAuth } from '@/contexts/AuthContext'

interface ShopItem {
  id: string
  name: string
  description: string
  price: number
  type: 'TOOLS' | 'EQUIPMENT' | 'SERVICES' | 'EDUCATION' | 'TRANSPORTATION' | 'HOUSING' | 'FOOD' | 'MISCELLANEOUS'
  location?: string
  imageUrl?: string
  stock: number
  createdAt: string
  updatedAt: string
  createdBy: string
  creator: {
    id: string
    name: string
    email: string
    avatar?: string
  }
  _count: {
    purchases: number
  }
}

interface ShopManagementModalProps {
  isOpen: boolean
  onClose: () => void
}

export default function ShopManagementModal({ isOpen, onClose }: ShopManagementModalProps) {
  const [shopItems, setShopItems] = useState<ShopItem[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [searchTerm, setSearchTerm] = useState('')
  const [typeFilter, setTypeFilter] = useState('ALL')
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [selectedItem, setSelectedItem] = useState<ShopItem | null>(null)
  const [showEditDialog, setShowEditDialog] = useState(false)
  const [editForm, setEditForm] = useState({
    name: '',
    description: '',
    price: 0,
    type: 'TOOLS' as ShopItem['type'],
    stock: -1,
    location: ''
  })
  const { user } = useAuth()

  useEffect(() => {
    if (isOpen) {
      fetchShopItems()
    }
  }, [isOpen, currentPage, searchTerm, typeFilter])

  const fetchShopItems = async () => {
    try {
      setLoading(true)
      const token = localStorage.getItem('adventure_guild_token')
      if (!token) return

      const params = new URLSearchParams({
        page: currentPage.toString(),
        limit: '10',
        search: searchTerm,
        type: typeFilter
      })

      const response = await fetch(`/api/admin/shop?${params}`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'x-user-data': JSON.stringify(user),
        },
      })

      if (response.ok) {
        const data = await response.json()
        setShopItems(data.shopItems)
        setTotalPages(data.pagination.pages)
      } else {
        const errorData = await response.json()
        setError(errorData.error || 'Failed to fetch shop items')
      }
    } catch (error) {
      console.error('Error fetching shop items:', error)
      setError('An error occurred while fetching shop items')
    } finally {
      setLoading(false)
    }
  }

  const handleEditItem = (item: ShopItem) => {
    setSelectedItem(item)
    setEditForm({
      name: item.name,
      description: item.description,
      price: item.price,
      type: item.type,
      stock: item.stock,
      location: item.location || ''
    })
    setShowEditDialog(true)
  }

  const handleSaveItem = async () => {
    try {
      const token = localStorage.getItem('adventure_guild_token')
      if (!token || !selectedItem) return

      const response = await fetch('/api/admin/shop', {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
          'x-user-data': JSON.stringify(user),
        },
        body: JSON.stringify({
          itemId: selectedItem.id,
          ...editForm
        }),
      })

      if (response.ok) {
        setShowEditDialog(false)
        fetchShopItems()
      } else {
        const errorData = await response.json()
        setError(errorData.error || 'Failed to update shop item')
      }
    } catch (error) {
      console.error('Error updating shop item:', error)
      setError('An error occurred while updating shop item')
    }
  }

  const handleDeleteItem = async (itemId: string) => {
    if (!confirm('Are you sure you want to delete this shop item? This action cannot be undone.')) {
      return
    }

    try {
      const token = localStorage.getItem('adventure_guild_token')
      if (!token) return

      const response = await fetch(`/api/admin/shop?itemId=${itemId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`,
          'x-user-data': JSON.stringify(user),
        },
      })

      if (response.ok) {
        fetchShopItems()
      } else {
        const errorData = await response.json()
        setError(errorData.error || 'Failed to delete shop item')
      }
    } catch (error) {
      console.error('Error deleting shop item:', error)
      setError('An error occurred while deleting shop item')
    }
  }

  const getTypeBadgeColor = (type: string) => {
    const colors: { [key: string]: string } = {
      'TOOLS': 'bg-blue-100 text-blue-800',
      'EQUIPMENT': 'bg-green-100 text-green-800',
      'SERVICES': 'bg-purple-100 text-purple-800',
      'EDUCATION': 'bg-yellow-100 text-yellow-800',
      'TRANSPORTATION': 'bg-red-100 text-red-800',
      'HOUSING': 'bg-indigo-100 text-indigo-800',
      'FOOD': 'bg-orange-100 text-orange-800',
      'MISCELLANEOUS': 'bg-gray-100 text-gray-800'
    }
    return colors[type] || 'bg-gray-100 text-gray-800'
  }

  const formatStock = (stock: number) => {
    if (stock === -1) return 'Unlimited'
    if (stock === 0) return 'Out of Stock'
    return stock.toString()
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <Card className="w-full max-w-6xl max-h-[90vh] overflow-hidden">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <ShoppingCart className="h-5 w-5" />
            <span>Shop Management</span>
          </CardTitle>
          <CardDescription>
            Manage shop items, inventory, and pricing
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {/* Search and Filter */}
          <div className="flex space-x-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search shop items by name or description..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Filter by type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All Types</SelectItem>
                <SelectItem value="TOOLS">Tools</SelectItem>
                <SelectItem value="EQUIPMENT">Equipment</SelectItem>
                <SelectItem value="SERVICES">Services</SelectItem>
                <SelectItem value="EDUCATION">Education</SelectItem>
                <SelectItem value="TRANSPORTATION">Transportation</SelectItem>
                <SelectItem value="HOUSING">Housing</SelectItem>
                <SelectItem value="FOOD">Food</SelectItem>
                <SelectItem value="MISCELLANEOUS">Miscellaneous</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Shop Items Table */}
          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Item</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Price</TableHead>
                  <TableHead>Stock</TableHead>
                  <TableHead>Purchases</TableHead>
                  <TableHead>Creator</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-8">
                      Loading shop items...
                    </TableCell>
                  </TableRow>
                ) : shopItems.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-8">
                      No shop items found
                    </TableCell>
                  </TableRow>
                ) : (
                  shopItems.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell>
                        <div className="flex items-center space-x-3">
                          <div className="w-10 h-10 bg-gray-200 rounded-lg flex items-center justify-center">
                            <Package className="h-6 w-6 text-gray-500" />
                          </div>
                          <div>
                            <div className="font-medium">{item.name}</div>
                            <div className="text-sm text-gray-500 truncate max-w-xs">
                              {item.description}
                            </div>
                            {item.location && (
                              <div className="text-xs text-gray-400 flex items-center">
                                <Map className="h-3 w-3 mr-1" />
                                {item.location}
                              </div>
                            )}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className={getTypeBadgeColor(item.type)}>
                          {item.type}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-1">
                          <Coins className="h-4 w-4 text-yellow-500" />
                          <span>{item.price} CC</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={item.stock === 0 ? "destructive" : item.stock > 10 ? "default" : "secondary"}>
                          {formatStock(item.stock)}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-1">
                          <ShoppingCart className="h-4 w-4 text-gray-400" />
                          <span>{item._count.purchases}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="text-sm">
                          <div>{item.creator.name || 'Unknown'}</div>
                          <div className="text-gray-500">{item.creator.email}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        {new Date(item.createdAt).toLocaleDateString()}
                      </TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleEditItem(item)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleDeleteItem(item.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex justify-center space-x-2">
              <Button
                variant="outline"
                onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                disabled={currentPage === 1}
              >
                Previous
              </Button>
              <span className="flex items-center px-4">
                Page {currentPage} of {totalPages}
              </span>
              <Button
                variant="outline"
                onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                disabled={currentPage === totalPages}
              >
                Next
              </Button>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex justify-end space-x-2">
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Edit Shop Item Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Shop Item</DialogTitle>
            <DialogDescription>
              Modify shop item details and inventory
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Name</Label>
              <Input
                id="name"
                value={editForm.name}
                onChange={(e) => setEditForm({...editForm, name: e.target.value})}
                placeholder="Enter item name"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Input
                id="description"
                value={editForm.description}
                onChange={(e) => setEditForm({...editForm, description: e.target.value})}
                placeholder="Enter item description"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="price">Price (CC)</Label>
              <Input
                id="price"
                type="number"
                value={editForm.price}
                onChange={(e) => setEditForm({...editForm, price: parseInt(e.target.value) || 0})}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="type">Type</Label>
              <Select value={editForm.type} onValueChange={(value) => setEditForm({...editForm, type: value as any})}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="TOOLS">Tools</SelectItem>
                  <SelectItem value="EQUIPMENT">Equipment</SelectItem>
                  <SelectItem value="SERVICES">Services</SelectItem>
                  <SelectItem value="EDUCATION">Education</SelectItem>
                  <SelectItem value="TRANSPORTATION">Transportation</SelectItem>
                  <SelectItem value="HOUSING">Housing</SelectItem>
                  <SelectItem value="FOOD">Food</SelectItem>
                  <SelectItem value="MISCELLANEOUS">Miscellaneous</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="stock">Stock (-1 for unlimited)</Label>
              <Input
                id="stock"
                type="number"
                value={editForm.stock}
                onChange={(e) => setEditForm({...editForm, stock: parseInt(e.target.value) || -1})}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="location">Location (optional)</Label>
              <Input
                id="location"
                value={editForm.location}
                onChange={(e) => setEditForm({...editForm, location: e.target.value})}
                placeholder="Enter item location"
              />
            </div>
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setShowEditDialog(false)}>
                Cancel
              </Button>
              <Button onClick={handleSaveItem}>
                Save Changes
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}