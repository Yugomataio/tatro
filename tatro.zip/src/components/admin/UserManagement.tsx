'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Users, 
  Settings, 
  TrendingUp, 
  Search, 
  Edit, 
  Trash2, 
  Plus,
  Shield,
  Star,
  Coins
} from 'lucide-react'

interface User {
  id: string
  email: string
  name?: string
  avatar?: string
  bio?: string
  role: 'USER' | 'MODERATOR' | 'ADMIN'
  rank: string
  level: number
  experience: number
  credits: number
  createdAt: string
  updatedAt: string
  _count: {
    createdQuests: number
    participations: number
    submissions: number
    feedPosts: number
  }
}

interface UserFormData {
  id?: string
  email: string
  name: string
  role: 'USER' | 'MODERATOR' | 'ADMIN'
  rank: string
  level: number
  experience: number
  credits: number
  bio?: string
}

export default function UserManagement() {
  const [users, setUsers] = useState<User[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedUser, setSelectedUser] = useState<User | null>(null)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isSkillDialogOpen, setIsSkillDialogOpen] = useState(false)
  const [formData, setFormData] = useState<UserFormData>({
    email: '',
    name: '',
    role: 'USER',
    rank: 'Novice',
    level: 1,
    experience: 0,
    credits: 100,
    bio: '',
  })
  const [skillForm, setSkillForm] = useState({
    skillName: '',
    level: 1,
    experience: 0,
  })
  const [addAdminForm, setAddAdminForm] = useState({
    email: '',
    name: '',
  })
  const [isAddAdminDialogOpen, setIsAddAdminDialogOpen] = useState(false)

  useEffect(() => {
    fetchUsers()
  }, [])

  const fetchUsers = async () => {
    try {
      setLoading(true)
      const token = localStorage.getItem('adventure_guild_token')
      if (!token) return

      const response = await fetch('/api/admin/users', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'x-user-data': JSON.stringify({ role: 'ADMIN', id: 'admin' })
        }
      })
      if (response.ok) {
        const data = await response.json()
        setUsers(data.users)
      }
    } catch (error) {
      console.error('Error fetching users:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleEditUser = (user: User) => {
    setSelectedUser(user)
    setFormData({
      id: user.id,
      email: user.email,
      name: user.name || '',
      role: user.role,
      rank: user.rank,
      level: user.level,
      experience: user.experience,
      credits: user.credits,
      bio: user.bio || '',
    })
    setIsEditDialogOpen(true)
  }

  const handleUpdateUser = async () => {
    if (!selectedUser) return

    try {
      const token = localStorage.getItem('adventure_guild_token')
      if (!token) return

      const response = await fetch(`/api/admin/users?userId=${selectedUser.id}&action=update`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
          'x-user-data': JSON.stringify({ role: 'ADMIN', id: selectedUser.id })
        },
        body: JSON.stringify(formData),
      })

      if (response.ok) {
        await fetchUsers()
        setIsEditDialogOpen(false)
        setSelectedUser(null)
      } else {
        const errorData = await response.json()
        console.error('Failed to update user:', errorData.error)
      }
    } catch (error) {
      console.error('Error updating user:', error)
    }
  }

  const handleDeleteUser = async (userId: string) => {
    if (!confirm('Are you sure you want to delete this user? This action cannot be undone.')) {
      return
    }

    try {
      const token = localStorage.getItem('adventure_guild_token')
      if (!token) return

      const response = await fetch(`/api/admin/users?userId=${userId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`,
          'x-user-data': JSON.stringify({ role: 'ADMIN', id: 'admin' })
        },
      })

      if (response.ok) {
        await fetchUsers()
      }
    } catch (error) {
      console.error('Error deleting user:', error)
    }
  }

  const handleAddSkill = async () => {
    if (!selectedUser) return

    try {
      const token = localStorage.getItem('adventure_guild_token')
      if (!token) return

      const response = await fetch(`/api/admin/users?userId=${selectedUser.id}&action=addSkill`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
          'x-user-data': JSON.stringify({ role: 'ADMIN', id: 'admin' })
        },
        body: JSON.stringify(skillForm),
      })

      if (response.ok) {
        await fetchUsers()
        setIsSkillDialogOpen(false)
        setSkillForm({ skillName: '', level: 1, experience: 0 })
      }
    } catch (error) {
      console.error('Error adding skill:', error)
    }
  }

  const handleAddAdmin = async () => {
    try {
      const token = localStorage.getItem('adventure_guild_token')
      if (!token) return

      // First, check if user exists
      const searchResponse = await fetch(`/api/users/search?query=${addAdminForm.email}`, {
        headers: { 'Authorization': `Bearer ${token}` }
      })
      const searchData = await searchResponse.json()

      if (searchData.users && searchData.users.length > 0) {
        // User exists, update their role
        const user = searchData.users[0]
        const updateResponse = await fetch(`/api/admin/users?userId=${user.id}&action=update`, {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`,
            'x-user-data': JSON.stringify({ role: 'ADMIN', id: 'admin' })
          },
          body: JSON.stringify({
            ...user,
            role: 'ADMIN',
            name: addAdminForm.name || user.name,
          }),
        })

        if (updateResponse.ok) {
          await fetchUsers()
          setIsAddAdminDialogOpen(false)
          setAddAdminForm({ email: '', name: '' })
        }
      } else {
        // User doesn't exist, create new admin user
        const createResponse = await fetch('/api/admin/users?action=create', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`,
            'x-user-data': JSON.stringify({ role: 'ADMIN', id: 'admin' })
          },
          body: JSON.stringify({
            email: addAdminForm.email,
            name: addAdminForm.name,
            role: 'ADMIN',
            rank: 'Administrator',
            level: 10,
            experience: 0,
            credits: 1000,
          }),
        })

        if (createResponse.ok) {
          await fetchUsers()
          setIsAddAdminDialogOpen(false)
          setAddAdminForm({ email: '', name: '' })
        }
      }
    } catch (error) {
      console.error('Error adding admin:', error)
    }
  }

  const filteredUsers = users.filter(user =>
    user.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.email.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case 'ADMIN':
        return 'destructive'
      case 'MODERATOR':
        return 'default'
      default:
        return 'secondary'
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">User Management</h2>
          <p className="text-muted-foreground">
            Manage user accounts, roles, and permissions
          </p>
        </div>
        <Button onClick={() => setIsAddAdminDialogOpen(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Add Admin
        </Button>
      </div>

      <div className="flex items-center space-x-2">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search users..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-8"
          />
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Users</CardTitle>
          <CardDescription>
            All registered users in the Adventure Guild
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8">Loading users...</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>User</TableHead>
                  <TableHead>Role</TableHead>
                  <TableHead>Rank & Level</TableHead>
                  <TableHead>Credits</TableHead>
                  <TableHead>Stats</TableHead>
                  <TableHead>Joined</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredUsers.map((user) => (
                  <TableRow key={user.id}>
                    <TableCell>
                      <div className="flex items-center space-x-3">
                        <Avatar className="h-8 w-8">
                          <AvatarImage src={user.avatar} alt={user.name} />
                          <AvatarFallback>{user.name?.charAt(0) || user.email.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">{user.name || 'Unknown'}</p>
                          <p className="text-sm text-muted-foreground">{user.email}</p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={getRoleBadgeColor(user.role)}>
                        {user.role}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <Star className="h-4 w-4 text-yellow-500" />
                        <span className="font-medium">{user.rank}</span>
                        <span className="text-sm text-muted-foreground">(Lvl {user.level})</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-1">
                        <Coins className="h-4 w-4 text-yellow-500" />
                        <span className="font-medium">{user.credits}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">
                        <div>{user._count.createdQuests} quests</div>
                        <div>{user._count.participations} participations</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm text-muted-foreground">
                        {new Date(user.createdAt).toLocaleDateString()}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleEditUser(user)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDeleteUser(user.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Edit User Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Edit User</DialogTitle>
            <DialogDescription>
              Update user information and settings
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="name">Name</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="role">Role</Label>
              <Select value={formData.role} onValueChange={(value) => setFormData({ ...formData, role: value as any })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="USER">User</SelectItem>
                  <SelectItem value="MODERATOR">Moderator</SelectItem>
                  <SelectItem value="ADMIN">Admin</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="rank">Rank</Label>
              <Input
                id="rank"
                value={formData.rank}
                onChange={(e) => setFormData({ ...formData, rank: e.target.value })}
              />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <Label htmlFor="level">Level</Label>
                <Input
                  id="level"
                  type="number"
                  value={formData.level}
                  onChange={(e) => setFormData({ ...formData, level: parseInt(e.target.value) || 1 })}
                />
              </div>
              <div>
                <Label htmlFor="credits">Credits</Label>
                <Input
                  id="credits"
                  type="number"
                  value={formData.credits}
                  onChange={(e) => setFormData({ ...formData, credits: parseInt(e.target.value) || 0 })}
                />
              </div>
            </div>
            <div>
              <Label htmlFor="bio">Bio</Label>
              <Textarea
                id="bio"
                value={formData.bio}
                onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
              />
            </div>
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleUpdateUser}>
                Update User
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Add Skill Dialog */}
      <Dialog open={isSkillDialogOpen} onOpenChange={setIsSkillDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Add Skill</DialogTitle>
            <DialogDescription>
              Add a new skill to {selectedUser?.name}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="skillName">Skill Name</Label>
              <Input
                id="skillName"
                value={skillForm.skillName}
                onChange={(e) => setSkillForm({ ...skillForm, skillName: e.target.value })}
              />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <Label htmlFor="skillLevel">Level</Label>
                <Input
                  id="skillLevel"
                  type="number"
                  min="1"
                  max="100"
                  value={skillForm.level}
                  onChange={(e) => setSkillForm({ ...skillForm, level: parseInt(e.target.value) || 1 })}
                />
              </div>
              <div>
                <Label htmlFor="skillExperience">Experience</Label>
                <Input
                  id="skillExperience"
                  type="number"
                  min="0"
                  value={skillForm.experience}
                  onChange={(e) => setSkillForm({ ...skillForm, experience: parseInt(e.target.value) || 0 })}
                />
              </div>
            </div>
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setIsSkillDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleAddSkill}>
                Add Skill
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Add Admin Dialog */}
      <Dialog open={isAddAdminDialogOpen} onOpenChange={setIsAddAdminDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Add Administrator</DialogTitle>
            <DialogDescription>
              Add a new administrator by email or create a new admin account
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="adminEmail">Email Address</Label>
              <Input
                id="adminEmail"
                type="email"
                placeholder="admin@example.com"
                value={addAdminForm.email}
                onChange={(e) => setAddAdminForm({ ...addAdminForm, email: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="adminName">Full Name (Optional)</Label>
              <Input
                id="adminName"
                placeholder="John Doe"
                value={addAdminForm.name}
                onChange={(e) => setAddAdminForm({ ...addAdminForm, name: e.target.value })}
              />
            </div>
            <div className="text-sm text-muted-foreground">
              <p>If the user exists, they will be promoted to admin.</p>
              <p>If the user doesn't exist, a new admin account will be created.</p>
            </div>
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setIsAddAdminDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleAddAdmin}>
                Add Admin
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}