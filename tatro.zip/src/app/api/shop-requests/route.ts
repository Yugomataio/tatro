import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { z } from 'zod'

const createShopItemRequestSchema = z.object({
  itemId: z.string(),
  userId: z.string(),
  title: z.string().min(1),
  description: z.string().min(1),
  price: z.number().min(0),
  location: z.string().optional(),
  latitude: z.number().optional(),
  longitude: z.number().optional(),
  imageUrl: z.string().optional(),
})

const updateShopItemRequestSchema = z.object({
  requestId: z.string(),
  status: z.enum(['APPROVED', 'REJECTED', 'FULFILLED']),
  feedback: z.string().optional(),
})

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId') || ''
    const status = searchParams.get('status') || ''
    const itemId = searchParams.get('itemId') || ''

    const where: any = {}
    
    if (userId) {
      where.userId = userId
    }
    
    if (status) {
      where.status = status
    }
    
    if (itemId) {
      where.itemId = itemId
    }

    const requests = await db.shopItemRequest.findMany({
      where,
      include: {
        user: {
          select: {
            id: true,
            name: true,
            avatar: true,
            rank: true,
          },
        },
        item: {
          select: {
            id: true,
            name: true,
            description: true,
            price: true,
            type: true,
            imageUrl: true,
            creator: {
              select: {
                id: true,
                name: true,
              },
            },
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    })

    return NextResponse.json({ requests })
  } catch (error) {
    console.error('Error fetching shop item requests:', error)
    return NextResponse.json(
      { error: 'Failed to fetch shop item requests' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { itemId, userId, title, description, price, location, latitude, longitude, imageUrl } = createShopItemRequestSchema.parse(body)

    // Check if item exists
    const item = await db.shopItem.findUnique({
      where: { id: itemId },
    })

    if (!item) {
      return NextResponse.json(
        { error: 'Shop item not found' },
        { status: 404 }
      )
    }

    // Check if user exists
    const user = await db.user.findUnique({
      where: { id: userId },
    })

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      )
    }

    // Create shop item request
    const shopItemRequest = await db.shopItemRequest.create({
      data: {
        itemId,
        userId,
        title,
        description,
        price,
        location,
        latitude,
        longitude,
        imageUrl,
        status: 'PENDING',
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            avatar: true,
            rank: true,
          },
        },
        item: {
          select: {
            id: true,
            name: true,
            description: true,
            price: true,
            type: true,
            imageUrl: true,
            creator: {
              select: {
                id: true,
                name: true,
              },
            },
          },
        },
      },
    })

    return NextResponse.json(shopItemRequest, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Validation failed', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Error creating shop item request:', error)
    return NextResponse.json(
      { error: 'Failed to create shop item request' },
      { status: 500 }
    )
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json()
    const { requestId, status, feedback } = updateShopItemRequestSchema.parse(body)

    // Get the request
    const shopItemRequest = await db.shopItemRequest.findUnique({
      where: { id: requestId },
      include: {
        item: true,
        user: true,
      },
    })

    if (!shopItemRequest) {
      return NextResponse.json(
        { error: 'Shop item request not found' },
        { status: 404 }
      )
    }

    // Update request
    const updatedRequest = await db.shopItemRequest.update({
      where: { id: requestId },
      data: {
        status,
        updatedAt: new Date(),
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            avatar: true,
            rank: true,
          },
        },
        item: {
          select: {
            id: true,
            name: true,
            description: true,
            price: true,
            type: true,
            imageUrl: true,
            creator: {
              select: {
                id: true,
                name: true,
              },
            },
          },
        },
      },
    })

    return NextResponse.json(updatedRequest)
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Validation failed', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Error updating shop item request:', error)
    return NextResponse.json(
      { error: 'Failed to update shop item request' },
      { status: 500 }
    )
  }
}