import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { z } from 'zod'

const joinPartySchema = z.object({
  userId: z.string(),
})

const updatePartySchema = z.object({
  name: z.string().min(1).optional(),
  description: z.string().optional(),
  maxMembers: z.number().min(1).max(20).optional(),
  status: z.enum(['ACTIVE', 'INACTIVE', 'DISBANDED']).optional(),
})

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const party = await db.party.findUnique({
      where: { id: params.id },
      include: {
        leader: {
          select: {
            id: true,
            name: true,
            avatar: true,
            rank: true,
            level: true,
          },
        },
        members: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                avatar: true,
                rank: true,
                level: true,
              },
            },
          },
        },
        _count: {
          select: {
            members: true,
          },
        },
      },
    })

    if (!party) {
      return NextResponse.json(
        { error: 'Party not found' },
        { status: 404 }
      )
    }

    return NextResponse.json(party)
  } catch (error) {
    console.error('Error fetching party:', error)
    return NextResponse.json(
      { error: 'Failed to fetch party' },
      { status: 500 }
    )
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const body = await request.json()
    const validatedData = updatePartySchema.parse(body)

    // Check if party exists
    const existingParty = await db.party.findUnique({
      where: { id: params.id },
    })

    if (!existingParty) {
      return NextResponse.json(
        { error: 'Party not found' },
        { status: 404 }
      )
    }

    // Update party
    const party = await db.party.update({
      where: { id: params.id },
      data: validatedData,
      include: {
        leader: {
          select: {
            id: true,
            name: true,
            avatar: true,
            rank: true,
            level: true,
          },
        },
        members: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                avatar: true,
                rank: true,
                level: true,
              },
            },
          },
        },
      },
    })

    return NextResponse.json(party)
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Validation failed', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Error updating party:', error)
    return NextResponse.json(
      { error: 'Failed to update party' },
      { status: 500 }
    )
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    // Check if party exists
    const existingParty = await db.party.findUnique({
      where: { id: params.id },
    })

    if (!existingParty) {
      return NextResponse.json(
        { error: 'Party not found' },
        { status: 404 }
      )
    }

    // Delete party and all members in a transaction
    await db.$transaction(async (tx) => {
      // Delete all party members
      await tx.partyMember.deleteMany({
        where: { partyId: params.id },
      })

      // Delete the party
      await tx.party.delete({
        where: { id: params.id },
      })
    })

    return NextResponse.json({ message: 'Party deleted successfully' })
  } catch (error) {
    console.error('Error deleting party:', error)
    return NextResponse.json(
      { error: 'Failed to delete party' },
      { status: 500 }
    )
  }
}

// Join party endpoint
export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const body = await request.json()
    const validatedData = joinPartySchema.parse(body)

    // Check if party exists
    const party = await db.party.findUnique({
      where: { id: params.id },
      include: {
        members: true,
        _count: {
          select: {
            members: true,
          },
        },
      },
    })

    if (!party) {
      return NextResponse.json(
        { error: 'Party not found' },
        { status: 404 }
      )
    }

    // Check if party is active
    if (party.status !== 'ACTIVE') {
      return NextResponse.json(
        { error: 'Party is not active' },
        { status: 400 }
      )
    }

    // Check if party is full
    if (party._count.members >= party.maxMembers) {
      return NextResponse.json(
        { error: 'Party is full' },
        { status: 400 }
      )
    }

    // Check if user is already a member
    const existingMember = party.members.find(member => member.userId === validatedData.userId)
    if (existingMember) {
      return NextResponse.json(
        { error: 'User is already a member of this party' },
        { status: 400 }
      )
    }

    // Check if user exists
    const user = await db.user.findUnique({
      where: { id: validatedData.userId },
    })

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      )
    }

    // Add user to party
    const partyMember = await db.partyMember.create({
      data: {
        partyId: params.id,
        userId: validatedData.userId,
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            avatar: true,
            rank: true,
            level: true,
          },
        },
      },
    })

    return NextResponse.json(partyMember, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Validation failed', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Error joining party:', error)
    return NextResponse.json(
      { error: 'Failed to join party' },
      { status: 500 }
    )
  }
}