import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { z } from 'zod'

const createPartySchema = z.object({
  name: z.string().min(1),
  description: z.string().optional(),
  leaderId: z.string(),
  maxMembers: z.number().min(1).max(20).default(5),
})

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '10')
    const userId = searchParams.get('userId') || ''
    const status = searchParams.get('status') || ''

    const skip = (page - 1) * limit

    const where: any = {}
    
    if (status) {
      where.status = status
    }

    const parties = await db.party.findMany({
      where,
      include: {
        leader: {
          select: {
            id: true,
            name: true,
            avatar: true,
            rank: true,
            level: true,
          },
        },
        members: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                avatar: true,
                rank: true,
                level: true,
              },
            },
          },
        },
        _count: {
          select: {
            members: true,
          },
        },
      },
      skip,
      take: limit,
      orderBy: { createdAt: 'desc' },
    })

    // If userId is provided, filter for user's parties
    let filteredParties = parties
    if (userId) {
      filteredParties = parties.filter(party => 
        party.leaderId === userId || 
        party.members.some(m => m.userId === userId)
      )
    }

    const total = await db.party.count({ where })

    return NextResponse.json({
      parties: filteredParties,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error('Error fetching parties:', error)
    return NextResponse.json(
      { error: 'Failed to fetch parties' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const validatedData = createPartySchema.parse(body)

    // Check if leader exists
    const leader = await db.user.findUnique({
      where: { id: validatedData.leaderId },
    })

    if (!leader) {
      return NextResponse.json(
        { error: 'Leader not found' },
        { status: 404 }
      )
    }

    const party = await db.party.create({
      data: {
        name: validatedData.name,
        description: validatedData.description,
        leaderId: validatedData.leaderId,
        maxMembers: validatedData.maxMembers,
        status: 'ACTIVE',
      },
      include: {
        leader: {
          select: {
            id: true,
            name: true,
            avatar: true,
            rank: true,
            level: true,
          },
        },
        members: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                avatar: true,
                rank: true,
                level: true,
              },
            },
          },
        },
      },
    })

    return NextResponse.json(party, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Validation failed', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Error creating party:', error)
    return NextResponse.json(
      { error: 'Failed to create party' },
      { status: 500 }
    )
  }
}