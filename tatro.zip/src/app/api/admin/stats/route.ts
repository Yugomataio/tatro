import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin } from '@/lib/auth'

export async function GET(request: NextRequest) {
  try {
    // Check if user is admin
    requireAdmin(request)
    
    // Get system statistics
    const [
      totalUsers,
      totalQuests,
      totalShopItems,
      totalPosts,
      totalCredits,
      activeUsers,
      totalFriendships,
      totalParticipations,
      totalSubmissions,
      totalPurchases
    ] = await Promise.all([
      // Total users
      db.user.count(),
      
      // Total quests
      db.quest.count(),
      
      // Total shop items
      db.shopItem.count(),
      
      // Total feed posts
      db.feedPost.count(),
      
      // Total credits in circulation
      db.user.aggregate({
        _sum: {
          credits: true
        }
      }),
      
      // Active users (users who logged in within the last 30 days)
      db.user.count({
        where: {
          updatedAt: {
            gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) // 30 days ago
          }
        }
      }),
      
      // Total friendships
      db.friendship.count({
        where: {
          status: 'ACCEPTED'
        }
      }),
      
      // Total quest participations
      db.questParticipant.count(),
      
      // Total progress submissions
      db.progressSubmission.count(),
      
      // Total purchases
      db.purchase.count()
    ])

    // Get recent activity stats (last 7 days)
    const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
    
    const [
      newUsersLast7Days,
      newQuestsLast7Days,
      newPostsLast7Days,
      newPurchasesLast7Days
    ] = await Promise.all([
      // New users in last 7 days
      db.user.count({
        where: {
          createdAt: {
            gte: sevenDaysAgo
          }
        }
      }),
      
      // New quests in last 7 days
      db.quest.count({
        where: {
          createdAt: {
            gte: sevenDaysAgo
          }
        }
      }),
      
      // New posts in last 7 days
      db.feedPost.count({
        where: {
          createdAt: {
            gte: sevenDaysAgo
          }
        }
      }),
      
      // New purchases in last 7 days
      db.purchase.count({
        where: {
          createdAt: {
            gte: sevenDaysAgo
          }
        }
      })
    ])

    // Get user distribution by role
    const userRoleDistribution = await db.user.groupBy({
      by: ['role'],
      _count: {
        role: true
      }
    })

    // Get quest status distribution
    const questStatusDistribution = await db.quest.groupBy({
      by: ['status'],
      _count: {
        status: true
      }
    })

    // Get top users by credits
    const topUsersByCredits = await db.user.findMany({
      select: {
        id: true,
        name: true,
        email: true,
        credits: true,
        level: true,
        rank: true
      },
      orderBy: {
        credits: 'desc'
      },
      take: 10
    })

    // Get most active users (by participations)
    const mostActiveUsers = await db.user.findMany({
      select: {
        id: true,
        name: true,
        email: true,
        _count: {
          select: {
            participations: true,
            createdQuests: true,
            feedPosts: true
          }
        }
      },
      orderBy: {
        participations: {
          _count: 'desc'
        }
      },
      take: 10
    })

    const systemStats = {
      totals: {
        users: totalUsers,
        quests: totalQuests,
        shopItems: totalShopItems,
        posts: totalPosts,
        credits: totalCredits._sum.credits || 0,
        friendships: totalFriendships,
        participations: totalParticipations,
        submissions: totalSubmissions,
        purchases: totalPurchases
      },
      active: {
        users: activeUsers
      },
      recentActivity: {
        last7Days: {
          newUsers: newUsersLast7Days,
          newQuests: newQuestsLast7Days,
          newPosts: newPostsLast7Days,
          newPurchases: newPurchasesLast7Days
        }
      },
      distributions: {
        userRoles: userRoleDistribution,
        questStatuses: questStatusDistribution
      },
      topUsers: {
        byCredits: topUsersByCredits,
        byActivity: mostActiveUsers
      }
    }

    return NextResponse.json(systemStats)
  } catch (error) {
    console.error('Error fetching system stats:', error)
    return NextResponse.json(
      { error: 'Failed to fetch system statistics' },
      { status: 500 }
    )
  }
}