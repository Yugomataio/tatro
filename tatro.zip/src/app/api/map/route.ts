import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId') || ''
    const bounds = searchParams.get('bounds') // Optional: "lat1,lng1,lat2,lng2"

    let friendsWhere: any = {}
    let questsWhere: any = {}
    let shopItemsWhere: any = {}

    // Filter by bounds if provided
    if (bounds) {
      const [lat1, lng1, lat2, lng2] = bounds.split(',').map(Number)
      
      friendsWhere = {
        AND: [
          { latitude: { gte: Math.min(lat1, lat2) } },
          { latitude: { lte: Math.max(lat1, lat2) } },
          { longitude: { gte: Math.min(lng1, lng2) } },
          { longitude: { lte: Math.max(lng1, lng2) } },
        ],
      }

      questsWhere = {
        AND: [
          { latitude: { gte: Math.min(lat1, lat2) } },
          { latitude: { lte: Math.max(lat1, lat2) } },
          { longitude: { gte: Math.min(lng1, lng2) } },
          { longitude: { lte: Math.max(lng1, lng2) } },
        ],
      }

      shopItemsWhere = {
        AND: [
          { latitude: { gte: Math.min(lat1, lat2) } },
          { latitude: { lte: Math.max(lat1, lat2) } },
          { longitude: { gte: Math.min(lng1, lng2) } },
          { longitude: { lte: Math.max(lng1, lng2) } },
        ],
      }
    }

    // Get friends with locations
    let friends = []
    if (userId) {
      const friendships = await db.friendship.findMany({
        where: {
          OR: [
            { user1Id: userId, status: 'ACCEPTED' },
            { user2Id: userId, status: 'ACCEPTED' },
          ],
        },
      })

      const friendIds = friendships.map(f => 
        f.user1Id === userId ? f.user2Id : f.user1Id
      )

      friends = await db.user.findMany({
        where: {
          id: { in: friendIds },
          latitude: { not: null },
          longitude: { not: null },
          showLocation: true, // Only show friends who want their location shown
          ...friendsWhere,
        },
        select: {
          id: true,
          name: true,
          avatar: true,
          location: true,
          latitude: true,
          longitude: true,
          rank: true,
          level: true,
        },
      })
    }

    // Get quests with locations
    const quests = await db.quest.findMany({
      where: {
        latitude: { not: null },
        longitude: { not: null },
        status: { in: ['OPEN', 'IN_PROGRESS'] },
        ...questsWhere,
      },
      select: {
        id: true,
        title: true,
        description: true,
        difficulty: true,
        category: true,
        reward: true,
        status: true,
        location: true,
        latitude: true,
        longitude: true,
        creator: {
          select: {
            id: true,
            name: true,
          },
        },
        _count: {
          select: {
            participants: true,
          },
        },
      },
    })

    // Get shop items with locations
    const shopItems = await db.shopItem.findMany({
      where: {
        latitude: { not: null },
        longitude: { not: null },
        stock: {
          gt: 0, // Only show items in stock
        },
        ...shopItemsWhere,
      },
      select: {
        id: true,
        name: true,
        description: true,
        price: true,
        type: true,
        location: true,
        latitude: true,
        longitude: true,
        imageUrl: true,
        stock: true,
        creator: {
          select: {
            id: true,
            name: true,
          },
        },
      },
    })

    return NextResponse.json({
      friends,
      quests,
      shopItems,
      bounds: bounds ? bounds.split(',').map(Number) : null,
    })
  } catch (error) {
    console.error('Error fetching map data:', error)
    return NextResponse.json(
      { error: 'Failed to fetch map data' },
      { status: 500 }
    )
  }
}