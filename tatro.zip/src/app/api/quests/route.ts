import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { z } from 'zod'

const createQuestSchema = z.object({
  title: z.string().min(1),
  description: z.string().min(1),
  difficulty: z.enum(['EASY', 'MEDIUM', 'HARD', 'EXPERT']),
  category: z.string().min(1),
  reward: z.number().min(0),
  xpReward: z.number().min(0).default(0),
  maxProgress: z.number().min(1),
  location: z.string().optional(),
  latitude: z.number().optional(),
  longitude: z.number().optional(),
  imageUrl: z.string().optional(),
  createdBy: z.string(),
})

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '10')
    const status = searchParams.get('status') || ''
    const difficulty = searchParams.get('difficulty') || ''
    const category = searchParams.get('category') || ''
    const userId = searchParams.get('userId') || ''

    const skip = (page - 1) * limit

    const where: any = {}
    
    if (status) {
      where.status = status
    }
    
    if (difficulty) {
      where.difficulty = difficulty
    }
    
    if (category) {
      where.category = { contains: category, mode: 'insensitive' }
    }

    const quests = await db.quest.findMany({
      where,
      include: {
        creator: {
          select: {
            id: true,
            name: true,
            avatar: true,
            rank: true,
          },
        },
        participants: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                avatar: true,
              },
            },
          },
        },
        _count: {
          select: {
            participants: true,
            submissions: true,
          },
        },
      },
      skip,
      take: limit,
      orderBy: { createdAt: 'desc' },
    })

    // If userId is provided, filter for user's quests
    let filteredQuests = quests
    if (userId) {
      filteredQuests = quests.filter(quest => 
        quest.createdBy === userId || 
        quest.participants.some(p => p.userId === userId)
      )
    }

    const total = await db.quest.count({ where })

    return NextResponse.json({
      quests: filteredQuests,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error('Error fetching quests:', error)
    return NextResponse.json(
      { error: 'Failed to fetch quests' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const validatedData = createQuestSchema.parse(body)

    // Check if creator has enough credits
    const creator = await db.user.findUnique({
      where: { id: validatedData.createdBy },
    })

    if (!creator) {
      return NextResponse.json(
        { error: 'Creator not found' },
        { status: 404 }
      )
    }

    if (creator.credits < validatedData.reward) {
      return NextResponse.json(
        { error: 'Insufficient credits to create quest' },
        { status: 400 }
      )
    }

    // Deduct rewards from creator's credits and create quest in a transaction
    const result = await db.$transaction(async (tx) => {
      // Deduct credits from creator
      await tx.user.update({
        where: { id: validatedData.createdBy },
        data: {
          credits: {
            decrement: validatedData.reward,
          },
        },
      })

      // Create the quest
      const quest = await tx.quest.create({
        data: {
          title: validatedData.title,
          description: validatedData.description,
          difficulty: validatedData.difficulty,
          category: validatedData.category,
          reward: validatedData.reward,
          xpReward: validatedData.xpReward,
          maxProgress: validatedData.maxProgress,
          location: validatedData.location,
          latitude: validatedData.latitude,
          longitude: validatedData.longitude,
          imageUrl: validatedData.imageUrl,
          createdBy: validatedData.createdBy,
          status: 'OPEN',
        },
        include: {
          creator: {
            select: {
              id: true,
              name: true,
              avatar: true,
              rank: true,
            },
          },
        },
      })

      return quest
    })

    return NextResponse.json(result, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Validation failed', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Error creating quest:', error)
    return NextResponse.json(
      { error: 'Failed to create quest' },
      { status: 500 }
    )
  }
}