import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { z } from 'zod'

const submitProgressSchema = z.object({
  questId: z.string(),
  userId: z.string(),
  progress: z.number().min(0).max(100),
  description: z.string().optional(),
  evidence: z.string().optional(),
})

const approveProgressSchema = z.object({
  submissionId: z.string(),
  approvedBy: z.string(),
  approved: z.boolean(),
  feedback: z.string().optional(),
})

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { questId, userId, progress, description, evidence } = submitProgressSchema.parse(body)

    // Check if user is participating in the quest
    const participation = await db.questParticipant.findUnique({
      where: {
        userId_questId: {
          userId,
          questId,
        },
      },
    })

    if (!participation) {
      return NextResponse.json(
        { error: 'User is not participating in this quest' },
        { status: 400 }
      )
    }

    // Check if quest exists
    const quest = await db.quest.findUnique({
      where: { id: questId },
    })

    if (!quest) {
      return NextResponse.json(
        { error: 'Quest not found' },
        { status: 404 }
      )
    }

    // Create progress submission
    const submission = await db.progressSubmission.create({
      data: {
        questId,
        userId,
        progress,
        description,
        evidence,
        status: 'PENDING',
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            avatar: true,
          },
        },
        quest: {
          select: {
            id: true,
            title: true,
            maxProgress: true,
            reward: true,
          },
        },
      },
    })

    return NextResponse.json(submission, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Validation failed', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Error submitting progress:', error)
    return NextResponse.json(
      { error: 'Failed to submit progress' },
      { status: 500 }
    )
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json()
    const { submissionId, approvedBy, approved, feedback } = approveProgressSchema.parse(body)

    // Get the submission with quest details
    const submission = await db.progressSubmission.findUnique({
      where: { id: submissionId },
      include: {
        quest: true,
        user: true,
      },
    })

    if (!submission) {
      return NextResponse.json(
        { error: 'Submission not found' },
        { status: 404 }
      )
    }

    if (submission.status !== 'PENDING') {
      return NextResponse.json(
        { error: 'Submission has already been processed' },
        { status: 400 }
      )
    }

    // Check if the approver is the quest creator
    if (submission.quest.createdBy !== approvedBy) {
      return NextResponse.json(
        { error: 'Only the quest creator can approve progress submissions' },
        { status: 403 }
      )
    }

    // Update submission
    const updatedSubmission = await db.progressSubmission.update({
      where: { id: submissionId },
      data: {
        status: approved ? 'APPROVED' : 'REJECTED',
        approvedBy,
        approvedAt: new Date(),
        feedback,
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            avatar: true,
          },
        },
        quest: {
          select: {
            id: true,
            title: true,
            maxProgress: true,
            reward: true,
            xpReward: true,
            createdBy: true,
          },
        },
      },
    })

    // If approved, update user credits and experience
    if (approved) {
      const creditReward = Math.floor((submission.progress / 100) * submission.quest.reward)
      const xpReward = Math.floor((submission.progress / 100) * submission.quest.xpReward)
      
      await db.user.update({
        where: { id: submission.userId },
        data: {
          credits: {
            increment: creditReward,
          },
          experience: {
            increment: xpReward,
          },
        },
      })

      // Check if quest is completed (total progress reaches 100%)
      const allSubmissions = await db.progressSubmission.findMany({
        where: {
          questId: submission.questId,
          status: 'APPROVED',
        },
      })

      const totalProgress = allSubmissions.reduce((sum, s) => sum + s.progress, 0)
      
      if (totalProgress >= submission.quest.maxProgress) {
        // Mark quest as completed
        await db.quest.update({
          where: { id: submission.questId },
          data: { status: 'COMPLETED' },
        })

        // Distribute remaining rewards based on progress contribution
        const totalApprovedProgress = allSubmissions.reduce((sum, s) => sum + s.progress, 0)
        
        for (const sub of allSubmissions) {
          const progressPercentage = sub.progress / totalApprovedProgress
          const remainingCreditReward = Math.floor(progressPercentage * submission.quest.reward)
          const remainingXpReward = Math.floor(progressPercentage * submission.quest.xpReward)
          
          await db.user.update({
            where: { id: sub.userId },
            data: {
              credits: {
                increment: remainingCreditReward,
              },
              experience: {
                increment: remainingXpReward,
              },
            },
          })
        }
      }
    }

    return NextResponse.json(updatedSubmission)
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Validation failed', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Error approving progress:', error)
    return NextResponse.json(
      { error: 'Failed to approve progress' },
      { status: 500 }
    )
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const questId = searchParams.get('questId')
    const userId = searchParams.get('userId')
    const status = searchParams.get('status') || ''

    const where: any = {}
    
    if (questId) {
      where.questId = questId
    }
    
    if (userId) {
      where.userId = userId
    }
    
    if (status) {
      where.status = status
    }

    const submissions = await db.progressSubmission.findMany({
      where,
      include: {
        user: {
          select: {
            id: true,
            name: true,
            avatar: true,
          },
        },
        quest: {
          select: {
            id: true,
            title: true,
            maxProgress: true,
            reward: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    })

    return NextResponse.json({ submissions })
  } catch (error) {
    console.error('Error fetching submissions:', error)
    return NextResponse.json(
      { error: 'Failed to fetch submissions' },
      { status: 500 }
    )
  }
}