import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { z } from 'zod'

const updateCCConfigSchema = z.object({
  currentValue: z.number().min(0),
  dynamicPricing: z.boolean().optional(),
})

export async function GET(request: NextRequest) {
  try {
    // Get the latest CC configuration
    const config = await db.cCConfiguration.findFirst({
      orderBy: { createdAt: 'desc' },
    })

    if (!config) {
      // Create default configuration if none exists
      const defaultConfig = await db.cCConfiguration.create({
        data: {
          currentValue: 1.0, // Default value: 1 CC = 1 base currency unit
          dynamicPricing: false,
        },
      })
      return NextResponse.json(defaultConfig)
    }

    return NextResponse.json(config)
  } catch (error) {
    console.error('Error fetching CC configuration:', error)
    return NextResponse.json(
      { error: 'Failed to fetch CC configuration' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const validatedData = updateCCConfigSchema.parse(body)

    // Create new configuration (keeping history)
    const config = await db.cCConfiguration.create({
      data: {
        currentValue: validatedData.currentValue,
        dynamicPricing: validatedData.dynamicPricing ?? false,
        updatedBy: body.updatedBy, // Optional: track who made the change
      },
    })

    return NextResponse.json(config, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Validation failed', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Error creating CC configuration:', error)
    return NextResponse.json(
      { error: 'Failed to create CC configuration' },
      { status: 500 }
    )
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json()
    const validatedData = updateCCConfigSchema.parse(body)

    // Get the latest configuration
    const latestConfig = await db.cCConfiguration.findFirst({
      orderBy: { createdAt: 'desc' },
    })

    if (!latestConfig) {
      // Create if none exists
      const config = await db.cCConfiguration.create({
        data: {
          currentValue: validatedData.currentValue,
          dynamicPricing: validatedData.dynamicPricing ?? false,
          updatedBy: body.updatedBy,
        },
      })
      return NextResponse.json(config)
    }

    // Update existing configuration
    const config = await db.cCConfiguration.update({
      where: { id: latestConfig.id },
      data: {
        currentValue: validatedData.currentValue,
        dynamicPricing: validatedData.dynamicPricing,
        updatedBy: body.updatedBy,
        lastUpdated: new Date(),
      },
    })

    return NextResponse.json(config)
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Validation failed', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Error updating CC configuration:', error)
    return NextResponse.json(
      { error: 'Failed to update CC configuration' },
      { status: 500 }
    )
  }
}