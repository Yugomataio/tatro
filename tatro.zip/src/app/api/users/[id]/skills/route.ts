import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const userId = params.id

    // Check if user exists
    const user = await db.user.findUnique({
      where: { id: userId }
    })

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    // Get user skills
    const skills = await db.userSkill.findMany({
      where: { userId },
      include: {
        skill: true
      },
      orderBy: {
        level: 'desc'
      }
    })

    const formattedSkills = skills.map(userSkill => ({
      id: userSkill.skill.id,
      name: userSkill.skill.name,
      level: userSkill.level,
      description: userSkill.skill.description,
      category: userSkill.skill.category
    }))

    return NextResponse.json({ skills: formattedSkills })
  } catch (error) {
    console.error('Error fetching user skills:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}