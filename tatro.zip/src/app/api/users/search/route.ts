import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const query = searchParams.get('q') || ''
    const currentUserId = searchParams.get('currentUserId') || ''
    const limit = parseInt(searchParams.get('limit') || '10')

    if (!query.trim()) {
      return NextResponse.json({ users: [] })
    }

    const users = await db.user.findMany({
      where: {
        OR: [
          { name: { contains: query, mode: 'insensitive' } },
          { email: { contains: query, mode: 'insensitive' } },
        ],
        NOT: {
          id: currentUserId // Exclude current user
        }
      },
      select: {
        id: true,
        name: true,
        email: true,
        avatar: true,
        rank: true,
        level: true,
        createdAt: true,
      },
      take: limit,
      orderBy: { name: 'asc' },
    })

    // If currentUserId is provided, check friendship status for each user
    let usersWithFriendshipStatus = users
    
    if (currentUserId) {
      usersWithFriendshipStatus = await Promise.all(
        users.map(async (user) => {
          const friendship = await db.friendship.findFirst({
            where: {
              OR: [
                { user1Id: currentUserId, user2Id: user.id },
                { user1Id: user.id, user2Id: currentUserId },
              ],
            },
          })

          return {
            ...user,
            friendshipStatus: friendship ? friendship.status : 'NONE',
          }
        })
      )
    }

    return NextResponse.json({ users: usersWithFriendshipStatus })
  } catch (error) {
    console.error('Error searching users:', error)
    return NextResponse.json(
      { error: 'Failed to search users' },
      { status: 500 }
    )
  }
}