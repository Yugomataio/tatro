import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { z } from 'zod'

interface ActivityItem {
  id: string
  type: 'feed_post' | 'quest_created' | 'quest_joined' | 'quest_completed' | 'shop_item_created' | 'shop_item_purchased' | 'friendship_created' | 'level_up' | 'achievement'
  userId: string
  user: {
    id: string
    name: string
    avatar?: string
    rank: string
    level: number
  }
  content: string
  createdAt: string
  metadata?: any
}

const getActivitySchema = z.object({
  userId: z.string(),
  friendsOnly: z.boolean().default(false),
  limit: z.number().min(1).max(100).default(20),
  offset: z.number().min(0).default(0),
})

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const validatedParams = getActivitySchema.parse({
      userId: searchParams.get('userId') || '',
      friendsOnly: searchParams.get('friendsOnly') === 'true',
      limit: parseInt(searchParams.get('limit') || '20'),
      offset: parseInt(searchParams.get('offset') || '0'),
    })

    if (!validatedParams.userId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      )
    }

    const activities: ActivityItem[] = []

    // Get friend IDs if friendsOnly is true
    let friendIds: string[] = []
    if (validatedParams.friendsOnly) {
      const friendships = await db.friendship.findMany({
        where: {
          OR: [
            { user1Id: validatedParams.userId, status: 'ACCEPTED' },
            { user2Id: validatedParams.userId, status: 'ACCEPTED' },
          ],
        },
      })

      friendIds = friendships.map(f => 
        f.user1Id === validatedParams.userId ? f.user2Id : f.user1Id
      )
    }

    const targetUserIds = validatedParams.friendsOnly 
      ? [...friendIds, validatedParams.userId] 
      : [validatedParams.userId]

    // Fetch feed posts
    const feedPosts = await db.feedPost.findMany({
      where: {
        userId: { in: targetUserIds },
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            avatar: true,
            rank: true,
            level: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
      take: validatedParams.limit,
      skip: validatedParams.offset,
    })

    feedPosts.forEach(post => {
      activities.push({
        id: `feed_${post.id}`,
        type: 'feed_post',
        userId: post.userId,
        user: post.user,
        content: post.content,
        createdAt: post.createdAt.toISOString(),
        metadata: {
          imageUrl: post.imageUrl,
          type: post.type,
        },
      })
    })

    // Fetch quest activities
    const quests = await db.quest.findMany({
      where: {
        createdBy: { in: targetUserIds },
      },
      include: {
        creator: {
          select: {
            id: true,
            name: true,
            avatar: true,
            rank: true,
            level: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
      take: validatedParams.limit,
      skip: validatedParams.offset,
    })

    quests.forEach(quest => {
      activities.push({
        id: `quest_created_${quest.id}`,
        type: 'quest_created',
        userId: quest.createdBy,
        user: quest.creator,
        content: `Created a new quest: ${quest.title}`,
        createdAt: quest.createdAt.toISOString(),
        metadata: {
          questId: quest.id,
          title: quest.title,
          difficulty: quest.difficulty,
          reward: quest.reward,
          xpReward: quest.xpReward,
        },
      })
    })

    // Fetch quest participations
    const participations = await db.questParticipant.findMany({
      where: {
        userId: { in: targetUserIds },
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            avatar: true,
            rank: true,
            level: true,
          },
        },
        quest: {
          select: {
            id: true,
            title: true,
            difficulty: true,
            reward: true,
          },
        },
      },
      orderBy: { joinedAt: 'desc' },
      take: validatedParams.limit,
      skip: validatedParams.offset,
    })

    participations.forEach(participation => {
      activities.push({
        id: `quest_joined_${participation.id}`,
        type: 'quest_joined',
        userId: participation.userId,
        user: participation.user,
        content: `Joined quest: ${participation.quest.title}`,
        createdAt: participation.joinedAt.toISOString(),
        metadata: {
          questId: participation.quest.id,
          title: participation.quest.title,
          difficulty: participation.quest.difficulty,
        },
      })
    })

    // Fetch shop items created
    const shopItems = await db.shopItem.findMany({
      where: {
        createdBy: { in: targetUserIds },
      },
      include: {
        creator: {
          select: {
            id: true,
            name: true,
            avatar: true,
            rank: true,
            level: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
      take: validatedParams.limit,
      skip: validatedParams.offset,
    })

    shopItems.forEach(item => {
      activities.push({
        id: `shop_item_created_${item.id}`,
        type: 'shop_item_created',
        userId: item.createdBy,
        user: item.creator,
        content: `Added new item to shop: ${item.name}`,
        createdAt: item.createdAt.toISOString(),
        metadata: {
          itemId: item.id,
          name: item.name,
          price: item.price,
          type: item.type,
        },
      })
    })

    // Fetch purchases
    const purchases = await db.purchase.findMany({
      where: {
        userId: { in: targetUserIds },
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            avatar: true,
            rank: true,
            level: true,
          },
        },
        item: {
          select: {
            id: true,
            name: true,
            price: true,
            type: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
      take: validatedParams.limit,
      skip: validatedParams.offset,
    })

    purchases.forEach(purchase => {
      activities.push({
        id: `shop_item_purchased_${purchase.id}`,
        type: 'shop_item_purchased',
        userId: purchase.userId,
        user: purchase.user,
        content: `Purchased ${purchase.quantity}x ${purchase.item.name} for ${purchase.totalPrice} CC`,
        createdAt: purchase.createdAt.toISOString(),
        metadata: {
          itemId: purchase.item.id,
          name: purchase.item.name,
          price: purchase.item.price,
          quantity: purchase.quantity,
          totalPrice: purchase.totalPrice,
        },
      })
    })

    // Fetch new friendships
    const newFriendships = await db.friendship.findMany({
      where: {
        OR: [
          { user1Id: { in: targetUserIds }, status: 'ACCEPTED' },
          { user2Id: { in: targetUserIds }, status: 'ACCEPTED' },
        ],
      },
      include: {
        user1: {
          select: {
            id: true,
            name: true,
            avatar: true,
            rank: true,
            level: true,
          },
        },
        user2: {
          select: {
            id: true,
            name: true,
            avatar: true,
            rank: true,
            level: true,
          },
        },
      },
      orderBy: { updatedAt: 'desc' },
      take: validatedParams.limit,
      skip: validatedParams.offset,
    })

    newFriendships.forEach(friendship => {
      const user = friendship.user1Id === friendship.user1.id ? friendship.user1 : friendship.user2
      const friend = friendship.user1Id === friendship.user1.id ? friendship.user2 : friendship.user1
      
      activities.push({
        id: `friendship_created_${friendship.id}`,
        type: 'friendship_created',
        userId: user.id,
        user: user,
        content: `Became friends with ${friend.name}`,
        createdAt: friendship.updatedAt.toISOString(),
        metadata: {
          friendId: friend.id,
          friendName: friend.name,
        },
      })
    })

    // Sort all activities by creation date (most recent first)
    activities.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())

    // Apply limit and offset after sorting
    const paginatedActivities = activities.slice(
      validatedParams.offset,
      validatedParams.offset + validatedParams.limit
    )

    return NextResponse.json({
      activities: paginatedActivities,
      pagination: {
        offset: validatedParams.offset,
        limit: validatedParams.limit,
        total: activities.length,
      },
    })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Validation failed', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Error fetching activities:', error)
    return NextResponse.json(
      { error: 'Failed to fetch activities' },
      { status: 500 }
    )
  }
}