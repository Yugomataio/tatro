"use client"

import { useState, useEffect } from "react"
import { useParams } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { 
  User, 
  Target, 
  ShoppingCart, 
  TrendingUp, 
  Star,
  Map,
  Coins,
  Calendar,
  MessageCircle,
  Heart,
  Share2,
  Edit,
  Settings,
  Award
} from "lucide-react"

interface UserProfile {
  id: string
  name: string
  email: string
  avatar?: string
  bio?: string
  rank: string
  level: number
  experience: number
  credits: number
  createdAt: string
}

interface UserSkill {
  id: string
  skill: {
    id: string
    name: string
    description?: string
    category: string
  }
  level: number
  experience: number
}

interface FeedPost {
  id: string
  content: string
  imageUrl?: string
  createdAt: string
  user: {
    id: string
    name: string
    avatar?: string
  }
}

interface UserQuest {
  id: string
  title: string
  description: string
  difficulty: string
  reward: number
  status: string
  maxProgress: number
  participants: Array<{
    user: {
      id: string
      name: string
      avatar?: string
    }
  }>
}

export default function ProfilePage() {
  const params = useParams()
  const userId = params.id as string
  const [activeTab, setActiveTab] = useState("overview")
  const [user, setUser] = useState<UserProfile | null>(null)
  const [skills, setSkills] = useState<UserSkill[]>([])
  const [feedPosts, setFeedPosts] = useState<FeedPost[]>([])
  const [quests, setQuests] = useState<UserQuest[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch user data
        const userResponse = await fetch(`/api/users?userId=${userId}`)
        const userData = await userResponse.json()
        
        if (userData.users?.[0]) {
          setUser(userData.users[0])
        }

        // Fetch user skills
        const skillsResponse = await fetch(`/api/skills?userId=${userId}`)
        const skillsData = await skillsResponse.json()
        setSkills(skillsData.userSkills || [])

        // Fetch user's feed posts
        const feedResponse = await fetch(`/api/feed-posts?userId=${userId}`)
        const feedData = await feedResponse.json()
        setFeedPosts(feedData.feedPosts || [])

        // Fetch user's quests
        const questsResponse = await fetch(`/api/quests?userId=${userId}`)
        const questsData = await questsResponse.json()
        setQuests(questsData.quests || [])
      } catch (error) {
        console.error('Error fetching profile data:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [userId])

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">Loading profile...</p>
        </div>
      </div>
    )
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <User className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
          <h2 className="text-xl font-semibold mb-2">User not found</h2>
          <p className="text-muted-foreground">The user you're looking for doesn't exist.</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
      {/* Header */}
      <div className="bg-white/80 backdrop-blur-sm dark:bg-slate-900/80 border-b">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row items-start md:items-center space-y-4 md:space-y-0 md:space-x-6">
            <Avatar className="h-24 w-24">
              <AvatarImage src={user.avatar} alt={user.name} />
              <AvatarFallback className="text-2xl">{user.name?.charAt(0) || 'U'}</AvatarFallback>
            </Avatar>
            
            <div className="flex-1">
              <div className="flex items-center space-x-2 mb-2">
                <h1 className="text-3xl font-bold">{user.name}</h1>
                <Badge variant="secondary">{user.rank}</Badge>
              </div>
              <p className="text-muted-foreground mb-3">{user.bio}</p>
              
              <div className="flex flex-wrap items-center gap-4 text-sm">
                <div className="flex items-center space-x-1">
                  <Star className="h-4 w-4 text-yellow-500" />
                  <span>Level {user.level}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <TrendingUp className="h-4 w-4 text-blue-500" />
                  <span>{user.experience} XP</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Coins className="h-4 w-4 text-yellow-500" />
                  <span>{user.credits} CC</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Calendar className="h-4 w-4 text-green-500" />
                  <span>Joined {new Date(user.createdAt).toLocaleDateString()}</span>
                </div>
              </div>
            </div>
            
            <div className="flex space-x-2">
              <Button variant="outline">
                <MessageCircle className="h-4 w-4 mr-2" />
                Message
              </Button>
              <Button variant="outline">
                <User className="h-4 w-4 mr-2" />
                Add Friend
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="quests">Quests</TabsTrigger>
            <TabsTrigger value="skills">Skills</TabsTrigger>
            <TabsTrigger value="activity">Activity</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Level</CardTitle>
                  <Star className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{user.level}</div>
                  <p className="text-xs text-muted-foreground">
                    {user.experience} XP
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Rank</CardTitle>
                  <Award className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{user.rank}</div>
                  <p className="text-xs text-muted-foreground">
                    Guild Member
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Credits</CardTitle>
                  <Coins className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{user.credits}</div>
                  <p className="text-xs text-muted-foreground">
                    Company Credits
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Quests</CardTitle>
                  <Target className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{quests.length}</div>
                  <p className="text-xs text-muted-foreground">
                    Active Quests
                  </p>
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                  <CardDescription>Latest updates and achievements</CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[300px]">
                    <div className="space-y-4">
                      {feedPosts.slice(0, 3).map((post) => (
                        <div key={post.id} className="border rounded-lg p-4">
                          <p className="text-sm mb-2">{post.content}</p>
                          <p className="text-xs text-muted-foreground">
                            {new Date(post.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Top Skills</CardTitle>
                  <CardDescription>Your most developed abilities</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {skills.slice(0, 3).map((userSkill) => (
                      <div key={userSkill.id} className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">{userSkill.skill.name}</p>
                          <p className="text-sm text-muted-foreground">
                            {userSkill.skill.category}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold">Level {userSkill.level}</p>
                          <p className="text-sm text-muted-foreground">
                            {userSkill.experience} XP
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Quests Tab */}
          <TabsContent value="quests" className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold tracking-tight">Quest History</h2>
              <p className="text-muted-foreground">
                Quests you've participated in and completed
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {quests.map((quest) => (
                <Card key={quest.id}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{quest.title}</CardTitle>
                      <Badge variant={quest.difficulty === 'EASY' ? 'default' : 'secondary'}>
                        {quest.difficulty}
                      </Badge>
                    </div>
                    <CardDescription>{quest.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Status:</span>
                        <Badge variant={quest.status === 'COMPLETED' ? 'default' : 'outline'}>
                          {quest.status.replace('_', ' ')}
                        </Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Reward:</span>
                        <span className="font-semibold">{quest.reward} CC</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Participants:</span>
                        <span className="font-semibold">{quest.participants.length}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Skills Tab */}
          <TabsContent value="skills" className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold tracking-tight">Skills & Abilities</h2>
              <p className="text-muted-foreground">
                Your developed skills and expertise
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {skills.map((userSkill) => (
                <Card key={userSkill.id}>
                  <CardHeader>
                    <CardTitle className="text-lg">{userSkill.skill.name}</CardTitle>
                    <CardDescription>{userSkill.skill.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Level:</span>
                        <span className="font-semibold">{userSkill.level}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Experience:</span>
                        <span className="font-semibold">{userSkill.experience} XP</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Category:</span>
                        <Badge variant="outline">{userSkill.skill.category}</Badge>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-blue-600 h-2 rounded-full" 
                          style={{ width: `${(userSkill.experience % 1000) / 10}%` }}
                        ></div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Activity Tab */}
          <TabsContent value="activity" className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold tracking-tight">Activity Feed</h2>
              <p className="text-muted-foreground">
                Your recent posts and updates
              </p>
            </div>

            <div className="space-y-4">
              {feedPosts.map((post) => (
                <Card key={post.id}>
                  <CardHeader>
                    <div className="flex items-start space-x-3">
                      <Avatar>
                        <AvatarImage src={post.user.avatar} alt={post.user.name} />
                        <AvatarFallback>{post.user.name?.charAt(0) || 'U'}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex items-center space-x-2">
                          <span className="font-semibold">{post.user.name}</span>
                          <span className="text-sm text-muted-foreground">
                            {new Date(post.createdAt).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm mb-4">{post.content}</p>
                    {post.imageUrl && (
                      <div className="aspect-video bg-muted rounded-lg mb-4"></div>
                    )}
                    <div className="flex items-center space-x-4">
                      <Button variant="ghost" size="sm">
                        <Heart className="h-4 w-4 mr-1" />
                        12
                      </Button>
                      <Button variant="ghost" size="sm">
                        <MessageCircle className="h-4 w-4 mr-1" />
                        3
                      </Button>
                      <Button variant="ghost" size="sm">
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}