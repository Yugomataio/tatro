import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "next-themes";
import { AuthProvider } from "@/contexts/AuthContext";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Adventure Guild - Epic Quests & Social Adventures",
  description: "Join the Adventure Guild! Complete quests, earn rewards, and connect with fellow adventurers in this epic social gaming experience.",
  keywords: ["Adventure Guild", "Quests", "Social Gaming", "RPG", "Fantasy", "Multiplayer"],
  authors: [{ name: "Adventure Guild Team" }],
  openGraph: {
    title: "Adventure Guild",
    description: "Join the Adventure Guild! Complete quests, earn rewards, and connect with fellow adventurers.",
    url: "https://adventure-guild.com",
    siteName: "Adventure Guild",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Adventure Guild",
    description: "Join the Adventure Guild! Complete quests, earn rewards, and connect with fellow adventurers.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          <AuthProvider>
            {children}
            <Toaster />
          </AuthProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
