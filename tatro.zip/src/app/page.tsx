"use client"

import { useState, useEffect } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { ScrollArea } from "@/components/ui/scroll-area"
import { useAuth } from "@/contexts/AuthContext"
import AuthModal from "@/components/auth/AuthModal"
import PasswordChangeModal from "@/components/auth/PasswordChangeModal"
import QuestCreationModal from "@/components/quests/QuestCreationModal"
import ShopItemCreationModal from "@/components/shop/ShopItemCreationModal"
import FindFriendsModal from "@/components/social/FindFriendsModal"
import BuyCreditsModal from "@/components/shop/BuyCreditsModal"
import AdminEnableModal from "@/components/auth/AdminEnableModal"
import PaymentSettingsModal from "@/components/admin/PaymentSettingsModal"
import UserManagementModal from "@/components/admin/UserManagementModal"
import QuestManagementModal from "@/components/admin/QuestManagementModal"
import ShopManagementModal from "@/components/admin/ShopManagementModal"
import TransactionHistoryModal from "@/components/admin/TransactionHistoryModal"
import RevenueAnalyticsModal from "@/components/admin/RevenueAnalyticsModal"
import UserProfileTab from "@/components/profile/UserProfileTab"
import AccountTab from "@/components/profile/AccountTab"
import AdventureMap from "@/components/maps/AdventureMap"
import { 
  Users, 
  Target, 
  ShoppingCart, 
  TrendingUp, 
  Settings, 
  Map,
  MapPin,
  Bell,
  Search,
  Plus,
  Coins,
  Star,
  MessageCircle,
  Heart,
  Share2,
  Edit,
  Calendar,
  Crown,
  CreditCard,
  DollarSign
} from "lucide-react"

interface User {
  id: string
  name: string
  email: string
  avatar?: string
  bio?: string
  rank: string
  level: number
  experience: number
  credits: number
  location?: string
}

interface Quest {
  id: string
  title: string
  description: string
  difficulty: string
  category: string
  reward: number
  xpReward: number
  status: string
  location?: string
  creator: {
    id: string
    name: string
    avatar?: string
  }
  _count: {
    participants: number
  }
}

interface ShopItem {
  id: string
  name: string
  description: string
  price: number
  type: string
  location?: string
  stock: number
  creator: {
    id: string
    name: string
  }
}

interface Friend {
  id: string
  name: string
  avatar?: string
  rank: string
  level: number
  location?: string
}

interface ActivityItem {
  id: string
  type: 'feed_post' | 'quest_created' | 'quest_joined' | 'quest_completed' | 'shop_item_created' | 'shop_item_purchased' | 'friendship_created' | 'level_up' | 'achievement'
  userId: string
  user: {
    id: string
    name: string
    avatar?: string
    rank: string
    level: number
  }
  content: string
  createdAt: string
  metadata?: any
}

interface Ranking {
  id: string
  rank: number
  score: number
  period: string
  user: {
    id: string
    name: string
    avatar?: string
    rank: string
    level: number
  }
}


export default function Dashboard() {
  const { user, loading: authLoading, login, logout, register } = useAuth()
  const [activeTab, setActiveTab] = useState("overview")
  const [quests, setQuests] = useState<Quest[]>([])
  const [shopItems, setShopItems] = useState<ShopItem[]>([])
  const [friends, setFriends] = useState<Friend[]>([])
  const [activities, setActivities] = useState<ActivityItem[]>([])
  const [rankings, setRankings] = useState<Ranking[]>([])
  const [loading, setLoading] = useState(true)
  const [showAuthModal, setShowAuthModal] = useState(false)
  const [showPasswordChangeModal, setShowPasswordChangeModal] = useState(false)
  const [showQuestCreationModal, setShowQuestCreationModal] = useState(false)
  const [showShopItemCreationModal, setShowShopItemCreationModal] = useState(false)
  const [showFindFriendsModal, setShowFindFriendsModal] = useState(false)
  const [showBuyCreditsModal, setShowBuyCreditsModal] = useState(false)
  const [showAdminEnableModal, setShowAdminEnableModal] = useState(false)
  const [showPaymentSettingsModal, setShowPaymentSettingsModal] = useState(false)
  const [showUserManagementModal, setShowUserManagementModal] = useState(false)
  const [showQuestManagementModal, setShowQuestManagementModal] = useState(false)
  const [showShopManagementModal, setShowShopManagementModal] = useState(false)
  const [showTransactionHistoryModal, setShowTransactionHistoryModal] = useState(false)
  const [showRevenueAnalyticsModal, setShowRevenueAnalyticsModal] = useState(false)
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login')

  useEffect(() => {
    if (user) {
      fetchData()
    } else {
      setLoading(false)
    }
  }, [user])

  const fetchData = async () => {
    if (!user) return
    
    try {
      // Get token from localStorage
      const token = localStorage.getItem('adventure_guild_token')
      if (!token) return

      const headers = {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      }

      // Fetch quests
      const questsResponse = await fetch('/api/quests?limit=6', { headers })
      const questsData = await questsResponse.json()
      setQuests(questsData.quests || [])

      // Fetch shop items
      const shopResponse = await fetch('/api/shop?limit=8', { headers })
      const shopData = await shopResponse.json()
      setShopItems(shopData.shopItems || [])

      // Fetch friends
      const friendsResponse = await fetch(`/api/friendships?userId=${user.id}&status=ACCEPTED`, { headers })
      const friendsData = await friendsResponse.json()
      setFriends(friendsData.friendships || [])

      // Fetch activities
      const activityResponse = await fetch(`/api/activity?friendsOnly=true&userId=${user.id}&limit=10`, { headers })
      const activityData = await activityResponse.json()
      setActivities(activityData.activities || [])

      // Fetch rankings
      const rankingsResponse = await fetch('/api/rankings?period=weekly&limit=10', { headers })
      const rankingsData = await rankingsResponse.json()
      setRankings(rankingsData.rankings || [])
    } catch (error) {
      console.error('Error fetching data:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleLogin = async (email: string, password: string) => {
    const result = await login(email, password)
    
    if (result && typeof result === 'object' && result.forcePasswordChange) {
      setShowAuthModal(false)
      setShowPasswordChangeModal(true)
    } else if (result) {
      setShowAuthModal(false)
    }
  }

  const handleRegister = async (email: string, name: string, password: string) => {
    const result = await register(email, name, password)
    
    if (result) {
      setShowAuthModal(false)
    }
  }

  const getActivityDescription = (activity: ActivityItem) => {
    switch (activity.type) {
      case 'feed_post':
        return 'posted an update'
      case 'quest_created':
        return 'created a new quest'
      case 'quest_joined':
        return 'joined a quest'
      case 'quest_completed':
        return 'completed a quest'
      case 'shop_item_created':
        return 'added a new item to the shop'
      case 'shop_item_purchased':
        return 'purchased an item'
      case 'friendship_created':
        return 'made a new friend'
      case 'level_up':
        return 'leveled up'
      case 'achievement':
        return 'earned an achievement'
      default:
        return 'performed an action'
    }
  }

  const getActivityDetails = (activity: ActivityItem) => {
    if (!activity.metadata) return null

    switch (activity.type) {
      case 'feed_post':
        return (
          <div className="mt-2">
            <p className="text-sm text-muted-foreground">{activity.content}</p>
            {activity.metadata.imageUrl && (
              <img 
                src={activity.metadata.imageUrl} 
                alt="Activity" 
                className="mt-2 rounded-md max-w-full h-auto"
                style={{ maxHeight: '200px' }}
              />
            )}
          </div>
        )
      case 'quest_created':
        return (
          <div className="mt-2">
            <p className="text-sm font-medium">{activity.metadata.title}</p>
            <div className="flex items-center space-x-2 mt-1">
              <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">
                {activity.metadata.difficulty}
              </span>
              <span className="text-xs text-muted-foreground">
                {activity.metadata.reward} CC + {activity.metadata.xpReward} XP
              </span>
            </div>
          </div>
        )
      case 'quest_joined':
        return (
          <div className="mt-2">
            <p className="text-sm font-medium">{activity.metadata.title}</p>
            <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">
              {activity.metadata.difficulty}
            </span>
          </div>
        )
      case 'shop_item_created':
        return (
          <div className="mt-2">
            <p className="text-sm font-medium">{activity.metadata.name}</p>
            <div className="flex items-center space-x-2 mt-1">
              <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">
                {activity.metadata.type}
              </span>
              <span className="text-xs text-muted-foreground">
                {activity.metadata.price} CC
              </span>
            </div>
          </div>
        )
      case 'shop_item_purchased':
        return (
          <div className="mt-2">
            <p className="text-sm font-medium">{activity.metadata.quantity}x {activity.metadata.name}</p>
            <span className="text-xs text-muted-foreground">
              {activity.metadata.totalPrice} CC total
            </span>
          </div>
        )
      case 'friendship_created':
        return (
          <div className="mt-2">
            <p className="text-sm text-muted-foreground">
              Now friends with {activity.metadata.friendName}
            </p>
          </div>
        )
      default:
        return (
          <div className="mt-2">
            <p className="text-sm text-muted-foreground">{activity.content}</p>
          </div>
        )
    }
  }

  const handleBuyCredits = async (amount: number) => {
    if (!user) return

    try {
      const token = localStorage.getItem('adventure_guild_token')
      if (!token) return

      const response = await fetch('/api/currency', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          action: 'buy',
          userId: user.id,
          amount: amount
        })
      })

      if (response.ok) {
        const data = await response.json()
        // Update user credits in the context
        if (updateUser) {
          updateUser({ credits: data.user.credits })
        }
        setShowBuyCreditsModal(false)
      } else {
        console.error('Failed to buy credits')
      }
    } catch (error) {
      console.error('Error buying credits:', error)
    }
  }

  const handleJoinQuest = async (questId: string) => {
    if (!user) return

    try {
      const token = localStorage.getItem('adventure_guild_token')
      if (!token) return

      const response = await fetch('/api/quests/participate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          questId,
          userId: user.id
        })
      })

      if (response.ok) {
        // Refresh quests to update participation status
        fetchData()
      } else {
        const errorData = await response.json()
        console.error('Failed to join quest:', errorData.error)
      }
    } catch (error) {
      console.error('Error joining quest:', error)
    }
  }

  // Show auth modal if user is not logged in
  if (!user && !authLoading) {
    return (
      <>
        <AuthModal 
          onLoginSuccess={(result) => {
            if (result && typeof result === 'object' && result.forcePasswordChange) {
              setShowPasswordChangeModal(true)
            }
          }}
          onRegisterSuccess={() => {
            // Registration successful, modal will be closed
          }}
        />
        {showPasswordChangeModal && (
          <PasswordChangeModal 
            isOpen={showPasswordChangeModal}
            onClose={() => setShowPasswordChangeModal(false)}
            isForced={true}
          />
        )}
      </>
    )
  }

  // Show password change modal if required after login
  if (user && showPasswordChangeModal) {
    return (
      <PasswordChangeModal 
        isOpen={showPasswordChangeModal}
        onClose={() => setShowPasswordChangeModal(false)}
        isForced={true}
      />
    )
  }

  // Show loading state
  if (authLoading || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">Loading dashboard...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Target className="h-8 w-8 text-primary" />
              <h1 className="text-2xl font-bold">Adventurer's Guild</h1>
            </div>
            <Badge variant="secondary">Beta</Badge>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Coins className="h-5 w-5 text-yellow-500" />
              <span className="font-semibold">{user?.credits || 0} CC</span>
            </div>
            <Button variant="outline" size="sm">
              <Bell className="h-4 w-4 mr-2" />
              Notifications
            </Button>
            <div className="flex items-center space-x-2">
              <Avatar>
                <AvatarImage src={user?.avatar} alt={user?.name} />
                <AvatarFallback>{user?.name?.charAt(0) || 'U'}</AvatarFallback>
              </Avatar>
              <Button variant="ghost" size="sm" onClick={logout}>
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-9">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="profile">Profile</TabsTrigger>
            <TabsTrigger value="account">Account</TabsTrigger>
            <TabsTrigger value="quests">Quests</TabsTrigger>
            <TabsTrigger value="shop">Shop</TabsTrigger>
            <TabsTrigger value="social">Social</TabsTrigger>
            <TabsTrigger value="rankings">Rankings</TabsTrigger>
            <TabsTrigger value="maps">Maps</TabsTrigger>
            {user?.role === 'ADMIN' && (
              <TabsTrigger value="admin">Admin</TabsTrigger>
            )}
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {user && (
              <>
                {/* User Stats */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Level</CardTitle>
                      <Star className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{user.level}</div>
                      <p className="text-xs text-muted-foreground">
                        {user.experience} XP
                      </p>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Rank</CardTitle>
                      <TrendingUp className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{user.rank}</div>
                      <p className="text-xs text-muted-foreground">
                        Guild Member
                      </p>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Credits</CardTitle>
                      <Coins className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{user.credits}</div>
                      <p className="text-xs text-muted-foreground">
                        Company Credits
                      </p>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Friends</CardTitle>
                      <Users className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{friends.length}</div>
                      <p className="text-xs text-muted-foreground">
                        Connections
                      </p>
                    </CardContent>
                  </Card>
                </div>

                {/* Guild Overview */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Crown className="h-5 w-5 text-yellow-500" />
                      <span>Guild Overview</span>
                    </CardTitle>
                    <CardDescription>
                      Your position and contributions within the Adventure Guild
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      <div className="text-center">
                        <div className="text-3xl font-bold text-blue-600">
                          {quests.filter(q => q.createdBy === user.id).length}
                        </div>
                        <div className="text-sm text-muted-foreground">Quests Created</div>
                        <div className="text-xs text-muted-foreground">
                          Contributing to guild growth
                        </div>
                      </div>
                      <div className="text-center">
                        <div className="text-3xl font-bold text-green-600">
                          {quests.filter(q => q.status === 'COMPLETED').length}
                        </div>
                        <div className="text-sm text-muted-foreground">Quests Completed</div>
                        <div className="text-xs text-muted-foreground">
                          Across all difficulties
                        </div>
                      </div>
                      <div className="text-center">
                        <div className="text-3xl font-bold text-purple-600">
                          {shopItems.filter(item => item.createdBy === user.id).length}
                        </div>
                        <div className="text-sm text-muted-foreground">Shop Items</div>
                        <div className="text-xs text-muted-foreground">
                          Added to marketplace
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Admin Enable Card - Only shown for specific email */}
                {user?.email === 'yugomatio@yahoo.com' && user?.role !== 'ADMIN' && (
                  <Card className="border-2 border-yellow-200 bg-yellow-50">
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2 text-yellow-800">
                        <Crown className="h-5 w-5 text-yellow-600" />
                        <span>Admin Access Available</span>
                      </CardTitle>
                      <CardDescription className="text-yellow-700">
                        You have been granted permission to enable administrative privileges
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center justify-between">
                        <div className="text-sm text-yellow-700">
                          <p>Unlock full administrative control over the Adventure Guild platform.</p>
                          <p className="text-xs mt-1">Requires admin password to activate.</p>
                        </div>
                        <Button 
                          onClick={() => setShowAdminEnableModal(true)}
                          className="bg-yellow-600 hover:bg-yellow-700 text-white"
                        >
                          Enable Admin
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                )}

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Available Quests</CardTitle>
                      <CardDescription>Quests you can join right now</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ScrollArea className="h-[300px]">
                        <div className="space-y-4">
                          {quests.slice(0, 3).map((quest) => (
                            <div key={quest.id} className="border rounded-lg p-4">
                              <div className="flex items-center justify-between mb-2">
                                <h4 className="font-medium">{quest.title}</h4>
                                <Badge variant={quest.difficulty === 'EASY' ? 'default' : 'secondary'}>
                                  {quest.difficulty}
                                </Badge>
                              </div>
                              <p className="text-sm text-muted-foreground mb-3">{quest.description}</p>
                              <div className="flex items-center justify-between">
                                <div className="text-sm">
                                  <span className="text-muted-foreground">Reward:</span> {quest.reward} CC
                                  {quest.xpReward > 0 && (
                                    <span className="text-muted-foreground"> + {quest.xpReward} XP</span>
                                  )}
                                </div>
                                <Button 
                                  size="sm" 
                                  onClick={() => handleJoinQuest(quest.id)}
                                  disabled={quest.participants.some((p: any) => p.userId === user.id)}
                                >
                                  {quest.participants.some((p: any) => p.userId === user.id) ? 'Joined' : 'Join Quest'}
                                </Button>
                              </div>
                            </div>
                          ))}
                        </div>
                      </ScrollArea>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>Recent Activity</CardTitle>
                      <CardDescription>Latest updates from your network</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ScrollArea className="h-[300px]">
                        <div className="space-y-4">
                          {activities.slice(0, 3).map((activity) => (
                            <div key={activity.id} className="flex items-start space-x-3 p-3 border rounded-lg">
                              <Avatar>
                                <AvatarImage src={activity.user.avatar} alt={activity.user.name} />
                                <AvatarFallback>{activity.user.name.charAt(0)}</AvatarFallback>
                              </Avatar>
                              <div className="flex-1">
                                <p className="text-sm">
                                  <span className="font-medium">{activity.user.name}</span> {getActivityDescription(activity)}
                                </p>
                                <p className="text-xs text-muted-foreground">
                                  {new Date(activity.createdAt).toLocaleDateString()}
                                </p>
                                {activity.metadata && getActivityDetails(activity)}
                              </div>
                            </div>
                          ))}
                        </div>
                      </ScrollArea>
                    </CardContent>
                  </Card>
                </div>

                {/* Guild Activity Summary */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Target className="h-5 w-5 text-red-500" />
                      <span>Guild Activity Summary</span>
                    </CardTitle>
                    <CardDescription>
                      Recent guild-wide activities and achievements
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="text-center p-4 bg-blue-50 rounded-lg">
                        <div className="text-2xl font-bold text-blue-600">{quests.length}</div>
                        <div className="text-sm text-blue-800">Active Quests</div>
                      </div>
                      <div className="text-center p-4 bg-green-50 rounded-lg">
                        <div className="text-2xl font-bold text-green-600">{shopItems.length}</div>
                        <div className="text-sm text-green-800">Shop Items</div>
                      </div>
                      <div className="text-center p-4 bg-purple-50 rounded-lg">
                        <div className="text-2xl font-bold text-purple-600">{friends.length}</div>
                        <div className="text-sm text-purple-800">Guild Friends</div>
                      </div>
                      <div className="text-center p-4 bg-yellow-50 rounded-lg">
                        <div className="text-2xl font-bold text-yellow-600">
                          {activities.filter(a => a.type === 'achievement').length}
                        </div>
                        <div className="text-sm text-yellow-800">Achievements</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </>
            )}
          </TabsContent>

          {/* Profile Tab */}
          <TabsContent value="profile" className="space-y-6">
            <UserProfileTab />
          </TabsContent>

          {/* Account Tab */}
          <TabsContent value="account" className="space-y-6">
            <AccountTab />
          </TabsContent>

          {/* Quests Tab */}
          <TabsContent value="quests" className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold">Quest Board</h2>
                <p className="text-muted-foreground">
                  Available opportunities and your current projects
                </p>
              </div>
              <Button onClick={() => setShowQuestCreationModal(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Create Quest
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {quests.map((quest) => (
                <Card key={quest.id} className="cursor-pointer hover:shadow-md transition-shadow">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{quest.title}</CardTitle>
                      <Badge variant={quest.difficulty === 'EASY' ? 'default' : 'secondary'}>
                        {quest.difficulty}
                      </Badge>
                    </div>
                    <CardDescription>{quest.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between text-sm">
                        <span>Category:</span>
                        <span className="font-medium">{quest.category}</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span>Reward:</span>
                        <span className="font-semibold">
                          {quest.reward} CC
                          {quest.xpReward > 0 && (
                            <span className="text-muted-foreground"> + {quest.xpReward} XP</span>
                          )}
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span>Participants:</span>
                        <span className="font-semibold">{quest._count.participants}</span>
                      </div>
                      <Button 
                        className="w-full"
                        onClick={() => handleJoinQuest(quest.id)}
                        disabled={quest.participants.some((p: any) => p.userId === user.id)}
                      >
                        {quest.participants.some((p: any) => p.userId === user.id) ? 'Joined' : 'Join Quest'}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Shop Tab */}
          <TabsContent value="shop" className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold">Guild Shop</h2>
                <p className="text-muted-foreground">
                  Items and services from community members
                </p>
              </div>
              <div className="flex items-center space-x-2">
                <Button variant="outline" onClick={() => setShowBuyCreditsModal(true)}>
                  <Coins className="h-4 w-4 mr-2" />
                  Buy Credits
                </Button>
                <Button onClick={() => setShowShopItemCreationModal(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Item
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {shopItems.map((item) => (
                <Card key={item.id} className="cursor-pointer hover:shadow-md transition-shadow">
                  <CardHeader>
                    <div className="aspect-square bg-muted rounded-md flex items-center justify-center">
                      <ShoppingCart className="h-8 w-8 text-muted-foreground" />
                    </div>
                    <CardTitle className="text-lg">{item.name}</CardTitle>
                    <CardDescription>{item.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between text-sm">
                        <span>Type:</span>
                        <Badge variant="outline">{item.type}</Badge>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span>Stock:</span>
                        <span className="font-medium">{item.stock === -1 ? 'Unlimited' : item.stock}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="font-semibold">{item.price} CC</span>
                        <Button size="sm">Buy</Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Social Tab */}
          <TabsContent value="social" className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold">Social Hub</h2>
                <p className="text-muted-foreground">
                  Connect with other guild members
                </p>
              </div>
              <div className="flex items-center space-x-2">
                <Button variant="outline" onClick={() => setShowFindFriendsModal(true)}>
                  <Users className="h-4 w-4 mr-2" />
                  Find Friends
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle>Activity Feed</CardTitle>
                  <CardDescription>Latest updates from your connections</CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[400px]">
                    <div className="space-y-4">
                      {activities.map((activity) => (
                        <div key={activity.id} className="border rounded-lg p-4">
                          <div className="flex items-start space-x-3">
                            <Avatar>
                              <AvatarImage src={activity.user.avatar} alt={activity.user.name} />
                              <AvatarFallback>{activity.user.name.charAt(0)}</AvatarFallback>
                            </Avatar>
                            <div className="flex-1">
                              <div className="flex items-center space-x-2 mb-2">
                                <span className="font-semibold">{activity.user.name}</span>
                                <span className="text-sm text-muted-foreground">
                                  {new Date(activity.createdAt).toLocaleDateString()}
                                </span>
                              </div>
                              <p className="text-sm mb-3">{getActivityDescription(activity)}</p>
                              {getActivityDetails(activity)}
                              <div className="flex items-center space-x-4">
                                <Button variant="ghost" size="sm">
                                  <Heart className="h-4 w-4 mr-1" />
                                  Like
                                </Button>
                                <Button variant="ghost" size="sm">
                                  <MessageCircle className="h-4 w-4 mr-1" />
                                  Comment
                                </Button>
                                <Button variant="ghost" size="sm">
                                  <Share2 className="h-4 w-4 mr-1" />
                                  Share
                                </Button>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Connections</CardTitle>
                  <CardDescription>Your guild network</CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[400px]">
                    <div className="space-y-3">
                      {friends.map((friend) => (
                        <div key={friend.id} className="flex items-center space-x-3">
                          <Avatar>
                            <AvatarImage src={friend.avatar} alt={friend.name} />
                            <AvatarFallback>{friend.name.charAt(0)}</AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <p className="text-sm font-medium">{friend.name}</p>
                            <p className="text-xs text-muted-foreground">
                              {friend.rank} • Level {friend.level}
                            </p>
                            {friend.location && (
                              <p className="text-xs text-muted-foreground">{friend.location}</p>
                            )}
                          </div>
                          <Button variant="ghost" size="sm">
                            <MessageCircle className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Rankings Tab */}
          <TabsContent value="rankings" className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold">Leaderboards</h2>
              <p className="text-muted-foreground">
                Top performers in the adventure guild
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Weekly Rankings</CardTitle>
                  <CardDescription>This week's top performers</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {rankings.filter(r => r.period === 'weekly').slice(0, 5).map((ranking, index) => (
                      <div key={ranking.id} className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
                          {index + 1}
                        </div>
                        <Avatar>
                          <AvatarImage src={ranking.user.avatar} alt={ranking.user.name} />
                          <AvatarFallback>{ranking.user.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <p className="font-medium">{ranking.user.name}</p>
                          <p className="text-sm text-muted-foreground">{ranking.score} pts</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Monthly Rankings</CardTitle>
                  <CardDescription>This month's top performers</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {rankings.filter(r => r.period === 'monthly').slice(0, 5).map((ranking, index) => (
                      <div key={ranking.id} className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-gray-400 rounded-full flex items-center justify-center text-white font-bold text-sm">
                          {index + 1}
                        </div>
                        <Avatar>
                          <AvatarImage src={ranking.user.avatar} alt={ranking.user.name} />
                          <AvatarFallback>{ranking.user.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <p className="font-medium">{ranking.user.name}</p>
                          <p className="text-sm text-muted-foreground">{ranking.score} pts</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>All-Time Rankings</CardTitle>
                  <CardDescription>Greatest contributors of all time</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {rankings.filter(r => r.period === 'all_time').slice(0, 5).map((ranking, index) => (
                      <div key={ranking.id} className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-orange-600 rounded-full flex items-center justify-center text-white font-bold text-sm">
                          {index + 1}
                        </div>
                        <Avatar>
                          <AvatarImage src={ranking.user.avatar} alt={ranking.user.name} />
                          <AvatarFallback>{ranking.user.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <p className="font-medium">{ranking.user.name}</p>
                          <p className="text-sm text-muted-foreground">{ranking.score} pts</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Maps Tab */}
          <TabsContent value="maps" className="space-y-6">
            <AdventureMap />
          </TabsContent>

          {/* Admin Tab */}
          <TabsContent value="admin" className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold">Admin Panel</h2>
              <p className="text-muted-foreground">
                Manage users, quests, and system settings
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Users className="h-5 w-5" />
                    <span>User Management</span>
                  </CardTitle>
                  <CardDescription>Manage user accounts and permissions</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <Button className="w-full justify-start" onClick={() => setShowUserManagementModal(true)}>
                      <Users className="h-4 w-4 mr-2" />
                      Manage Users
                    </Button>
                    <Button variant="outline" className="w-full justify-start" onClick={() => setShowUserManagementModal(true)}>
                      <Settings className="h-4 w-4 mr-2" />
                      User Roles & Ranks
                    </Button>
                    <Button variant="outline" className="w-full justify-start" onClick={() => setShowUserManagementModal(true)}>
                      <TrendingUp className="h-4 w-4 mr-2" />
                      User Skills
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Target className="h-5 w-5" />
                    <span>Quest Management</span>
                  </CardTitle>
                  <CardDescription>Review and manage quests</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <Button className="w-full justify-start" onClick={() => setShowQuestManagementModal(true)}>
                      <Target className="h-4 w-4 mr-2" />
                      Manage Quests
                    </Button>
                    <Button variant="outline" className="w-full justify-start" onClick={() => setShowQuestManagementModal(true)}>
                      <Calendar className="h-4 w-4 mr-2" />
                      Progress Reviews
                    </Button>
                    <Button variant="outline" className="w-full justify-start" onClick={() => setShowQuestManagementModal(true)}>
                      <Edit className="h-4 w-4 mr-2" />
                      Remove Content
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <ShoppingCart className="h-5 w-5" />
                    <span>Shop Management</span>
                  </CardTitle>
                  <CardDescription>Manage shop items and inventory</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <Button className="w-full justify-start" onClick={() => setShowShopManagementModal(true)}>
                      <ShoppingCart className="h-4 w-4 mr-2" />
                      Manage Shop Items
                    </Button>
                    <Button variant="outline" className="w-full justify-start" onClick={() => setShowShopManagementModal(true)}>
                      <Coins className="h-4 w-4 mr-2" />
                      Currency Settings
                    </Button>
                    <Button variant="outline" className="w-full justify-start" onClick={() => setShowShopManagementModal(true)}>
                      <Map className="h-4 w-4 mr-2" />
                      Manage Locations
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <CreditCard className="h-5 w-5" />
                    <span>Payment Settings</span>
                  </CardTitle>
                  <CardDescription>Configure payment routing for CC purchases</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <Button className="w-full justify-start" onClick={() => setShowPaymentSettingsModal(true)}>
                      <CreditCard className="h-4 w-4 mr-2" />
                      Payment Configuration
                    </Button>
                    <Button variant="outline" className="w-full justify-start" onClick={() => setShowTransactionHistoryModal(true)}>
                      <DollarSign className="h-4 w-4 mr-2" />
                      Transaction History
                    </Button>
                    <Button variant="outline" className="w-full justify-start" onClick={() => setShowRevenueAnalyticsModal(true)}>
                      <TrendingUp className="h-4 w-4 mr-2" />
                      Revenue Analytics
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>System Statistics</CardTitle>
                <CardDescription>Overview of system performance and metrics</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold">-</div>
                    <div className="text-sm text-muted-foreground">Total Users</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">-</div>
                    <div className="text-sm text-muted-foreground">Active Quests</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">-</div>
                    <div className="text-sm text-muted-foreground">Shop Items</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">-</div>
                    <div className="text-sm text-muted-foreground">Active Connections</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Auth Modal */}
      {showAuthModal && (
        <AuthModal 
          onLogin={handleLogin}
          onRegister={() => setShowAuthModal(false)}
        />
      )}

      {/* Password Change Modal */}
      {showPasswordChangeModal && (
        <PasswordChangeModal
          isOpen={showPasswordChangeModal}
          onClose={() => setShowPasswordChangeModal(false)}
          isForced={true}
        />
      )}

      {/* Quest Creation Modal */}
      {showQuestCreationModal && (
        <QuestCreationModal
          isOpen={showQuestCreationModal}
          onClose={() => setShowQuestCreationModal(false)}
          onSuccess={() => {
            fetchData()
            setShowQuestCreationModal(false)
          }}
          user={user}
        />
      )}

      {/* Shop Item Creation Modal */}
      {showShopItemCreationModal && (
        <ShopItemCreationModal
          isOpen={showShopItemCreationModal}
          onClose={() => setShowShopItemCreationModal(false)}
          onSuccess={() => {
            fetchData()
            setShowShopItemCreationModal(false)
          }}
          user={user}
        />
      )}

      {/* Find Friends Modal */}
      {showFindFriendsModal && (
        <FindFriendsModal
          isOpen={showFindFriendsModal}
          onClose={() => setShowFindFriendsModal(false)}
          onSuccess={() => {
            fetchData()
            setShowFindFriendsModal(false)
          }}
          user={user}
        />
      )}

      {/* Buy Credits Modal */}
      {showBuyCreditsModal && (
        <BuyCreditsModal
          isOpen={showBuyCreditsModal}
          onClose={() => setShowBuyCreditsModal(false)}
          onBuyCredits={handleBuyCredits}
          currentCredits={user?.credits || 0}
        />
      )}

      {/* Admin Enable Modal */}
      {showAdminEnableModal && (
        <AdminEnableModal
          isOpen={showAdminEnableModal}
          onClose={() => setShowAdminEnableModal(false)}
          onSuccess={() => {
            // Refresh the page to update the UI with admin privileges
            window.location.reload()
          }}
        />
      )}

      {/* Payment Settings Modal */}
      {showPaymentSettingsModal && (
        <PaymentSettingsModal
          isOpen={showPaymentSettingsModal}
          onClose={() => setShowPaymentSettingsModal(false)}
        />
      )}

      {/* User Management Modal */}
      {showUserManagementModal && (
        <UserManagementModal
          isOpen={showUserManagementModal}
          onClose={() => setShowUserManagementModal(false)}
        />
      )}

      {/* Quest Management Modal */}
      {showQuestManagementModal && (
        <QuestManagementModal
          isOpen={showQuestManagementModal}
          onClose={() => setShowQuestManagementModal(false)}
        />
      )}

      {/* Shop Management Modal */}
      {showShopManagementModal && (
        <ShopManagementModal
          isOpen={showShopManagementModal}
          onClose={() => setShowShopManagementModal(false)}
        />
      )}

      {/* Transaction History Modal */}
      {showTransactionHistoryModal && (
        <TransactionHistoryModal
          isOpen={showTransactionHistoryModal}
          onClose={() => setShowTransactionHistoryModal(false)}
        />
      )}

      {/* Revenue Analytics Modal */}
      {showRevenueAnalyticsModal && (
        <RevenueAnalyticsModal
          isOpen={showRevenueAnalyticsModal}
          onClose={() => setShowRevenueAnalyticsModal(false)}
        />
      )}
    </div>
  )
}