'use client'

import { createContext, useContext, useState, useEffect, ReactNode } from 'react'

interface User {
  id: string
  email: string
  name?: string
  avatar?: string
  bio?: string
  role: 'USER' | 'MODERATOR' | 'ADMIN'
  rank: string
  level: number
  experience: number
  credits: number
  createdAt: string
  updatedAt: string
}

interface AuthContextType {
  user: User | null
  loading: boolean
  login: (email: string, password: string) => Promise<boolean | { success: boolean; forcePasswordChange: boolean }>
  register: (email: string, name: string, password: string) => Promise<boolean>
  logout: () => void
  updateUser: (userData: Partial<User>) => void
  changePassword: (currentPassword: string, newPassword: string) => Promise<boolean>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    // Check if user is logged in on mount
    const savedUser = localStorage.getItem('adventure_guild_user')
    const savedToken = localStorage.getItem('adventure_guild_token')
    
    if (savedUser && savedToken) {
      try {
        const parsedUser = JSON.parse(savedUser)
        setUser(parsedUser)
      } catch (error) {
        console.error('Error parsing saved user:', error)
        localStorage.removeItem('adventure_guild_user')
        localStorage.removeItem('adventure_guild_token')
      }
    }
    setLoading(false)
  }, [])

  const login = async (email: string, password: string): Promise<boolean> => {
    try {
      setLoading(true)
      
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        setError(errorData.error || 'Login failed')
        return false
      }

      const data = await response.json()
      setUser(data.user)
      
      // Store token in localStorage for API calls
      localStorage.setItem('adventure_guild_token', data.token)
      localStorage.setItem('adventure_guild_user', JSON.stringify(data.user))
      
      // If password change is required, redirect to change password
      if (data.forcePasswordChange) {
        // This will be handled by the component
        return { success: true, forcePasswordChange: true }
      }
      
      return { success: true, forcePasswordChange: false }
    } catch (error) {
      console.error('Login error:', error)
      setError('An error occurred during login')
      return false
    } finally {
      setLoading(false)
    }
  }

  const register = async (email: string, name: string, password: string): Promise<boolean> => {
    try {
      setLoading(true)
      
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, name, password }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        setError(errorData.error || 'Registration failed')
        return false
      }

      const data = await response.json()
      setUser(data.user)
      
      // Store token in localStorage for API calls
      localStorage.setItem('adventure_guild_token', data.token)
      localStorage.setItem('adventure_guild_user', JSON.stringify(data.user))
      
      return true
    } catch (error) {
      console.error('Registration error:', error)
      setError('An error occurred during registration')
      return false
    } finally {
      setLoading(false)
    }
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem('adventure_guild_user')
    localStorage.removeItem('adventure_guild_token')
  }

  const updateUser = (userData: Partial<User>) => {
    if (user) {
      const updatedUser = { ...user, ...userData }
      setUser(updatedUser)
      localStorage.setItem('adventure_guild_user', JSON.stringify(updatedUser))
    }
  }

  const changePassword = async (currentPassword: string, newPassword: string): Promise<boolean> => {
    try {
      setLoading(true)
      
      const token = localStorage.getItem('adventure_guild_token')
      if (!token) {
        setError('No authentication token found')
        return false
      }

      const response = await fetch('/api/auth/change-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({ currentPassword, newPassword }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        setError(errorData.error || 'Password change failed')
        return false
      }

      return true
    } catch (error) {
      console.error('Change password error:', error)
      setError('An error occurred while changing password')
      return false
    } finally {
      setLoading(false)
    }
  }

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout, updateUser, changePassword }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}