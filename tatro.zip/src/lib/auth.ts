import jwt from 'jsonwebtoken'
import { NextRequest } from 'next/server'

export interface DecodedToken {
  userId: string
  email: string
  role: string
  forcePasswordChange: boolean
  iat: number
  exp: number
}

export function verifyToken(request: NextRequest): DecodedToken | null {
  try {
    const authHeader = request.headers.get('authorization')
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return null
    }

    const token = authHeader.substring(7)
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'fallback-secret-for-development') as DecodedToken
    return decoded
  } catch (error) {
    return null
  }
}

export function requireAuth(request: NextRequest): DecodedToken {
  const decoded = verifyToken(request)
  if (!decoded) {
    throw new Error('Unauthorized')
  }
  return decoded
}

export function requireAdmin(request: NextRequest): DecodedToken {
  const decoded = requireAuth(request)
  if (decoded.role !== 'ADMIN') {
    throw new Error('Admin access required')
  }
  return decoded
}