import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

async function createAdminUser() {
  try {
    const email = 'yugomatio@yahoo.com'
    const name = 'FoundationalIkunami'
    const password = 'TheCompany24'

    // Check if admin user already exists
    const existingUser = await prisma.user.findUnique({
      where: { email },
    })

    if (existingUser) {
      console.log('Admin user already exists. Updating...')
      
      // Hash the password
      const passwordHash = await bcrypt.hash(password, 12)
      
      // Update the existing user
      const updatedUser = await prisma.user.update({
        where: { email },
        data: {
          name,
          passwordHash,
          role: 'ADMIN',
          forcePasswordChange: true, // Force password change on first login
          passwordChangedAt: null,
        },
      })
      
      console.log('Admin user updated successfully:', updatedUser.email)
    } else {
      console.log('Creating new admin user...')
      
      // Hash the password
      const passwordHash = await bcrypt.hash(password, 12)
      
      // Create the admin user
      const adminUser = await prisma.user.create({
        data: {
          email,
          name,
          passwordHash,
          role: 'ADMIN',
          rank: 'Administrator',
          level: 10,
          experience: 0,
          credits: 1000, // Admin gets starting credits
          forcePasswordChange: true, // Force password change on first login
        },
      })
      
      console.log('Admin user created successfully:', adminUser.email)
    }
  } catch (error) {
    console.error('Error creating admin user:', error)
  } finally {
    await prisma.$disconnect()
  }
}

createAdminUser()